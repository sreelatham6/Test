import { OnInit, Component } from "@angular/core";
import { ActivatedRoute, Router } from '@angular/router';
import { ProductService } from './product.service'

import { IProduct } from './product';
import { Observable } from "rxjs/Observable";

@Component({
    selector: 'pm-product-detail',
    templateUrl: './product-detail.component.html'
})

export class ProductDetailComponent implements OnInit{
    product : IProduct;
    private product$ : Observable<IProduct[]>
    private prod: IProduct[];

    pageTitle: string = 'Product Details of';
    constructor(private _route : ActivatedRoute,
                private _router: Router,
                private productService: ProductService){}

    ngOnInit(){
         let id = +this._route.snapshot.paramMap.get('id');
        this.pageTitle += `: ${id}`;
        this.product = {
            "productId": 1,
            "productName": "Leaf Rake",
            "productCode": "GDN-0011",
            "releaseDate": "March 19, 2016",
            "description": "Leaf rake with 48-inch wooden handle.",
            "price": 19.95,
            "starRating": 3.2,
            "imageUrl": "http://openclipart.org/image/300px/svg_to_png/26215/Anonymous_Leaf_Rake.png"
        }
        // this.product$ = this.productService.getProduct(id);
        // this.product$.subscribe(s => this.prod = s)
    }

    onBack() : void{
        this._router.navigate(['/products']);
    }
}