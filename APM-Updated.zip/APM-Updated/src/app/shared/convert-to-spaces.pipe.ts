import { Pipe, PipeTransform } from "@angular/core";
// import { Transform } from "stream";

@Pipe({
    name: 'ConvertToSpaces'
})

export class ConvertToSpace implements PipeTransform{
    transform(value: string, character: string): string{
        return value.replace(character, ' ');
    }
}