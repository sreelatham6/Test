import { Component, OnInit } from '@angular/core';
import { Store, select } from '@ngrx/store';
import { FlexLayoutModule } from '@angular/flex-layout';
import * as fromR from '../../participations/store/reducers/participations.reducer';
import * as fromApp from '../../store/actions/router.action';

@Component({
    selector: 'left-nav',
    templateUrl: './left-nav.component.html',
    styleUrls: ['./left-nav.component.scss']
})
export class LeftNavComponent implements OnInit {
    constructor(
        private store: Store<fromR.ParticipationState>
    ) { }

    ngOnInit(): void { }

    onParticipations() {
        this.store.dispatch(new fromApp.Go({ path: ['participations'] }));
    }

    onNew() {
        this.store.dispatch(new fromApp.Go({ path: ['participations', 0] }));
    }

    onGuidance() {
        this.store.dispatch(new fromApp.Go({ path: ['welcome'] }));
    }
}
