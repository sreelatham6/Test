import { Component, OnInit, ChangeDetectionStrategy, Input } from '@angular/core';
import { Store } from '@ngrx/store';
import { CommonModule } from '@angular/common';
import { Observable } from 'rxjs';
import * as svc from '../../services';

import { OrgTree, User } from '../../models';
import * as fromR from '../../store/reducers/participations.reducer';

@Component({
    selector: 'orgtree-item',
    templateUrl: './orgtree-item.component.html',
    styleUrls: ['./orgtree-item.component.html'],
    changeDetection: ChangeDetectionStrategy.OnPush
  })

  export class OrgTreeItemComponent implements OnInit{

    @Input() item: OrgTree;
    @Input() count: number;
    @Input() index: number;

    constructor(
    private store: Store<fromR.ParticipationState>,
    private svc: svc.ParticipationsService
    ){}

    private user: User;
    private user$: Observable<User>;

    ngOnInit(){
      if (this.count === this.index){
        this.user$ = this.store.select(fromR.getUser) as Observable<User>;
        this.user$.subscribe((u: User) => this.user = u);
        console.log(this.user);
      }

    }

    onPencil() {
      this.svc.changeSuperviser();
  }
  }