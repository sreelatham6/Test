import { Component, OnInit, ChangeDetectionStrategy, Input, Output, EventEmitter } from '@angular/core';
import { Store } from '@ngrx/store';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, FormGroupName, FormArray, FormControl, FormControlName, Validators } from '@angular/forms';
import { MatCard } from '@angular/material';

import { Subscription, Observable, Subject } from 'rxjs';
import { OrgTree, Participation, Taig } from '../../models';
import { ParticipationsService } from '../../services';
import { TaigTitlePipe } from '../../shared/pipes';
import * as fromA from '../../store/actions/participations.actions';
import * as fromR from '../../store/reducers/participations.reducer';
import * as fromApp from '../../../store';

@Component({
  selector: 'participation-view',
  templateUrl: './participation-view.component.html',
  styleUrls: ['./participation-view.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush

})
export class ParticipationViewComponent implements OnInit {

  private rightNavSub: Subscription;
  private orgTreeSource = new Subject<OrgTree[]>();
  private orgTreeEvent: Observable<OrgTree[]>;
  private orgTree: OrgTree[];
  private orgTree$: Observable<OrgTree[]>;
  private purposes$: Observable<string[]>;
  private roles$: Observable<string[]>;
  private taigs$: Observable<Taig[]>;
  private taig: Taig;
  private supervisor$: Observable<string>;
  private supervisor: string;
  private title: string;
  private lawContact: string;

  participationForm: FormGroup;
  roleCard: FormGroup;
  committeeCard: FormGroup;

  // Use with the generic validation message class
  displayMessage: { [key: string]: string } = {};
  private validationMessages: { [key: string]: { [key: string]: string } };
  // private genericValidator: GenericValidator;

  get roleCards(): FormArray {
    return <FormArray>this.participationForm.get('roleCards');
  }
  get committeeCards(): FormArray {
    return <FormArray>this.participationForm.get('committeeCards');
  }

  @Input() participation: Participation;
  @Output() submitted: EventEmitter<Participation>;

  constructor(
    private fb: FormBuilder,
    private svc: ParticipationsService,
    private store: Store<fromR.ParticipationState>,
  ) {
    this.rightNavSub = this.svc.rightNavEvent.subscribe(
      (pencil: string) => {
        // pop up superviser picker
        
        // get superviser from store that was loaded by supervisor picker process
        this.supervisor$ = this.store.select(fromR.getSupervisor);
        this.supervisor$.subscribe(s => this.supervisor = s);
        // load new organizational tree based on the new supervisor
        this.store.dispatch(new fromA.LoadOrgTree(this.supervisor))
        // get organizational tree from store
        this.orgTree$ = this.store.select(fromR.getOrgTree) as Observable<OrgTree[]>;
        this.orgTree$.subscribe(tree => this.orgTree = tree);
        // throw organizational tree to right nav to display
        this.svc.updateOrgTree(this.orgTree);
      }
    );
  }

  ngOnInit() {
    this.store.dispatch(new fromA.LoadOrgTree(this.participation.name));
    this.store.dispatch(new fromA.LoadTaigs());

    this.purposes$ = this.store.select(fromR.getPurposes) as Observable<string[]>;
    this.roles$ = this.store.select(fromR.getRoles) as Observable<string[]>;
    this.taigs$ = this.store.select(fromR.getTaigs) as Observable<Taig[]>;

    this.orgTree$ = this.store.select(fromR.getOrgTree) as Observable<OrgTree[]>;
    this.orgTree$.subscribe(tree => this.orgTree = tree);
    this.svc.updateOrgTree(this.orgTree);

    this.participationForm = this.fb.group({
      taig: ['', [Validators.required, Validators.minLength(3), Validators.maxLength(50)]],
      title: ['', []],
      lawContact: ['', [Validators.required]],
      roleCards: this.fb.array([]),
      committeeCards: this.fb.array([])
    });

  }

  onAddRoleCard() {
    this.roleCard = this.fb.group({
      role: ['', [Validators.required]],
      other: ['', [Validators.maxLength(35)]],
      lawContact: ['', [Validators.required]]
    });
    this.roleCards.push(this.roleCard);
  }

  deleteRoleCard(index: number): void {
    this.roleCards.removeAt(index);
  }

  onAddCommitteeCard() {
    this.committeeCard = this.fb.group({
      name: ['', [Validators.required]],
      purpose: ['', [Validators.required]],
      role: ['', [Validators.required]],
      lawContact: ['', [Validators.required]]
    });
    this.committeeCards.push(this.committeeCard);
  }

  deleteCommitteeCard(index: number): void {
    this.committeeCards.removeAt(index);
  }

  onSubmit(participation: Participation) {
    this.submitted.emit(participation);
  }

  onCancel() {
    this.store.dispatch(new fromApp.Go({ path: ['participations'] }));
  }

}
