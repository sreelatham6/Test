import { Component } from "@angular/core";

@Component({
    selector:'supervisor-view',
    templateUrl: './supervisor-view.component.html',
    styleUrls: ['./su[ervisor-view.component.scss']
})

export class SupervisorViewComponent{
    
    onSubmitSupervisor(){
        
    }
}