import { CommitteeCard, RoleCard } from './';

export interface Participation {
    id: number;
    name: string;
    description: string;
    purpose: string;
    supervisor: string;
    lawContact: string;
    roles: RoleCard[];
    committees: CommitteeCard[];
  }
