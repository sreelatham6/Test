import { TaigTitlePipe } from './taig.pipe';

export const pipes: any[] = [TaigTitlePipe];

export * from './taig.pipe';