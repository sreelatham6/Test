import { Component, OnInit, ChangeDetectionStrategy } from '@angular/core';
import { Store, select } from '@ngrx/store';

import { AuthService, ConfigService } from './services';
import { resource } from 'selenium-webdriver/http';
import { LeftNavComponent } from './components';
import { User } from './participations/models'
import * as fromR from './store/reducers';
import * as fromApp from './store/actions/router.action';
import * as fromPA from './participations/store/actions/participations.actions';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})

export class AppComponent implements OnInit {
  title = 'TAIG';

  constructor(
    private store: Store<fromR.State>,
    private cfg: ConfigService,
    private auth: AuthService
  ) { }

  ngOnInit() {
    // this.cfg.load();
    // this.auth.getUser();
    this.store.dispatch(new fromPA.SetUser(this.auth.user));
    this.store.dispatch(new fromPA.LoadSupervisor(this.auth.user));
    this.store.dispatch(new fromPA.LoadOrgTree(this.auth.user));

    this.store.dispatch(new fromPA.LoadSupervisors());
    this.store.dispatch(new fromPA.LoadLawContacts());
    this.store.dispatch(new fromPA.LoadPurposes());
    this.store.dispatch(new fromPA.LoadRoles());
    this.store.dispatch(new fromPA.LoadTaigs());
  }

  onParticipations() {
    this.store.dispatch(new fromApp.Go({ path: ['participations'] }));
  }

  onNew() {
    this.store.dispatch(new fromApp.Go({ path: ['participations', 0] }));
  }

  onGuidance() {
    this.store.dispatch(new fromApp.Go({ path: ['welcome'] }));
  }

}
