import { Component, OnInit, ChangeDetectionStrategy } from '@angular/core';
import { Store, select } from '@ngrx/store';

import { AuthService, ConfigService, Configuration } from './shared';
import { resource } from 'selenium-webdriver/http';
import { LeftNavComponent } from './components';

import * as fromR from './store/reducers';
import * as fromApp from './store/actions/router.action';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush

})
export class AppComponent implements OnInit {
  title = 'TAIG';
  user = '';

  constructor(
    private store: Store<fromR.State>,
    private cfg: ConfigService,
    private auth: AuthService
  ) { }

  ngOnInit() {
    // this.cfg.load();
    // this.auth.getUser();
    // this.auth.getEmployeeOrgTree(this.auth.lanId);
  }

  onParticipations() {
    this.store.dispatch(new fromApp.Go({ path: ['participations'] }));
  }

  onNew() {
    this.store.dispatch(new fromApp.Go({ path: ['participations', 0] }));
  }

  onGuidance() {
    this.store.dispatch(new fromApp.Go({ path: ['welcome'] }));
  }

}
