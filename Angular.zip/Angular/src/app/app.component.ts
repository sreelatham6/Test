import { Component, OnInit, ChangeDetectionStrategy } from '@angular/core';
import { AuthService, ConfigService, Configuration } from './shared/services';
import { resource } from 'selenium-webdriver/http';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush

})
export class AppComponent implements OnInit {
  title = 'TAIG';
  user = '';

  constructor(
    private cfg: ConfigService,
    private auth: AuthService ) { }

  ngOnInit() {
    // this.cfg.load();
    // this.auth.getUser();
    // this.auth.getEmployeeOrgTree(this.auth.lanId);
  }

}
