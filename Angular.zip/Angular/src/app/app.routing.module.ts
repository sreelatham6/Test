import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { WelcomeComponent } from './components/welcome/welcome.component';
import { ParticipationsModule } from './participations/participations.module';

const routes: Routes = [
      { path: 'participations', loadChildren: () => ParticipationsModule },
      // loadChildren: '../participations/participations.module#ParticipationsModule'
      { path: '', pathMatch: 'full', redirectTo: 'participations' },
      { path: '**', pathMatch: 'full', redirectTo: 'participations' }
];

@NgModule({
      imports: [RouterModule.forRoot(routes)],
      exports: [RouterModule]
})

export class AppRoutingModule { }
