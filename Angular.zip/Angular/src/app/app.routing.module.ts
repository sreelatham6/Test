import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { WelcomeComponent } from './home/welcome.component';
import { ParticipationsModule } from './participations/participations.module';

const routes: Routes = [
      { path: 'welcome', component: WelcomeComponent },
      { path: 'participations', loadChildren: () => ParticipationsModule },
      { path: '', pathMatch: 'full', redirectTo: 'welcome' },
      { path: '**', pathMatch: 'full', redirectTo: 'welcome' }
];

@NgModule({
      imports: [RouterModule.forRoot(routes)],
      exports: [RouterModule]
})

export class AppRoutingModule { }
