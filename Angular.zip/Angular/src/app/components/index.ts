import { LeftNavComponent } from './left-nav/left-nav.component';
import { WelcomeComponent } from './welcome/welcome.component';

export const components: any[] = [LeftNavComponent, WelcomeComponent];

export * from './left-nav/left-nav.component';
export * from './welcome/welcome.component';
