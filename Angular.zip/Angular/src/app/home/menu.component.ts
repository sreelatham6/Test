import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Store, select } from '@ngrx/store';
import * as fromApp from '../store';

// import { AuthService } from '../user/auth.service';

@Component({
  selector: 'pm-menu',
  templateUrl: './menu.component.html'
})
export class MenuComponent implements OnInit {
  pageTitle = 'TAIG Management';

  get isLoggedIn(): boolean {
    // return this.authService.isLoggedIn();
    return true;
  }

  // get userName(): string {
  //   if (this.authService.currentUser) {
  //     return this.authService.currentUser.userName;
  //   }
  //   return '';
  // }

  constructor(
    private store: Store<fromApp.RootState>,
    private router: Router
    // private authService: AuthService
  ) { }

  ngOnInit() {

  }

  onWelcome(): void {
    // this.router.navigate(['welcome']);
    this.store.dispatch(new fromApp.Go({ path: ['welcome'] }));
  }

  onParticipations(): void {
    // this.router.navigate(['participations']);
    this.store.dispatch(new fromApp.Go({ path: ['participations'] }));
  }

  onLogOut(): void {
    // this.router.navigate(['welcome']);
    // this.authService.logout();
    this.store.dispatch(new fromApp.Go({ path: ['welcome'] }));
  }
}
