import { Component, OnInit, Input, Output, EventEmitter, OnDestroy } from '@angular/core';
import { CommitteeCard, User, SubmitCommittee, Purpose } from '../../models'

@Component({
    selector: 'committee-card',
    templateUrl: './committeeCard.component.html',
    styleUrls: ['./committeeCard.component.scss']
})
export class CommitteeCardComponent implements OnInit, OnDestroy {

    lawContactsList: User[];
    parm: SubmitCommittee;
    name: string = '';
    purposeString: string = '';
    purposeWork: Purpose = null;
    role: string = '';
    committeeLawContact: string = '';
    committeeLawContactWork: User = null;

    @Input() c: number;
    @Input() committeeCard: CommitteeCard;
    @Input() roles: string[];
    @Input() purposes: Purpose[];
    @Input() lawContacts: User[];

    @Output() submit = new EventEmitter<SubmitCommittee>();
    @Output() delete = new EventEmitter<number>();

    constructor() { }

    ngOnInit(): void { }

    ngOnDestroy() { }

    onDelete() {
        this.delete.emit(this.c)
        this.ngOnDestroy();
    }

    onChange(comLawContact: string) {
        this.purposeWork = this.purposes.find(p => p.description === this.purposeString);
        this.committeeLawContactWork = this.lawContacts.find(lc => lc.name === comLawContact);
        this.parm.index = this.c;
        this.parm.committeeCard.name = this.name;
        this.parm.committeeCard.purpose = this.purposeWork;
        this.parm.committeeCard.role = this.role;
        this.parm.committeeCard.lawContact = this.committeeLawContactWork;
        this.submit.emit(this.parm)
    }

    onChangeCommitteeLawContact(lawcontact: string) {
        if (!lawcontact) {
            this.lawContactsList = this.lawContacts;
        } else {
            this.committeeCard.lawContact = this.lawContacts.find(value => value.name === lawcontact);
        }
    }

    onSetCommitteeLawContact(lawcontact: User) {
        this.committeeCard.lawContact = lawcontact;
        this.committeeCard.lawContact = this.lawContactsList.find(value => value.name === lawcontact.name);
        this.lawContactsList = [];
    }

}
