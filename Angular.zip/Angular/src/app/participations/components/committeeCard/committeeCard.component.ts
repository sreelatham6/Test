import { Component, OnInit, Input, Output, EventEmitter, OnDestroy } from '@angular/core';
import { CommitteeCard, User, SubmitCommittee, Purpose } from '../../models'

@Component({
    selector: 'committee-card',
    templateUrl: './committeeCard.component.html',
    styleUrls: ['./committeeCard.component.scss']
})
export class CommitteeCardComponent implements OnInit, OnDestroy {

    lawContact: string = '';
    lawContactWork: User;
    lawContactsList: User[] = [];
    name: string = '';
    parm: SubmitCommittee = { index: 0, committeeCard: { name: '',  purpose: { id: 0, description: ''}, role: '', lawContact: { 'lanId': '', 'domain': '', 'name': '', 'title': '', 'id': '0' } }} ;
    purposeString: string = '';
    purposeWork: Purpose;
    role: string = '';
    user: User;

    @Input() c: number;
    @Input() committeeCard: CommitteeCard;
    @Input() lawContacts: User[];
    @Input() purposes: Purpose[];
    @Input() roles: string[];

    @Output() xomdelete = new EventEmitter<number>();
    @Output() xomsubmit = new EventEmitter<SubmitCommittee>();

    constructor() { }

    ngOnInit(): void { 
        this.lawContactsList = this.lawContacts;
        console.log('Committee Card in ready.');
    }

    ngOnDestroy() { }

    onDelete() {
        this.xomdelete.emit(this.c)
        this.ngOnDestroy();
    }

    onChange() {
        this.user = this.lawContacts.find(lc => lc.name === this.lawContact);
        this.purposeWork = this.purposes.find(p => p.description === this.purposeString);

        this.parm.index = this.c;
        this.parm.committeeCard.name = this.name;
        this.parm.committeeCard.purpose = this.purposeWork;
        this.parm.committeeCard.role = this.role;
        this.parm.committeeCard.lawContact = this.user;
        
        this.xomsubmit.emit(this.parm);
    }

    onSetLawContact(lawcontact: User) {
        this.lawContact = lawcontact.name;
        this.committeeCard.lawContact = lawcontact;
        this.lawContactsList = [];
    }

}
