import { Component, OnInit, Input, Output, EventEmitter, OnDestroy } from '@angular/core';
import { CommitteeCard, User, SubmitCommittee, Purpose } from '../../models'

@Component({
    selector: 'committee-card',
    templateUrl: './committeeCard.component.html',
    styleUrls: ['./committeeCard.component.scss']
})
export class CommitteeCardComponent implements OnInit, OnDestroy {

    lawContact: string = '';
    lawContactWork: User;
    lawContactsList: User[] = [];
    name: string = '';
    parm: SubmitCommittee = { index: 0, committeeCard: { name: '',  purpose: { id: 0, description: ''}, role: '', lawContact: { 'lanId': '', 'domain': '', 'name': '', 'title': '', 'id': '0' } }} ;
    purposeString: string = '';
    purposeWork: Purpose;
    role: string = '';
    user: User;

    @Input() c: number;
    @Input() committeeCard: CommitteeCard;
    @Input() lawContacts: User[];
    @Input() purposes: Purpose[];
    @Input() roles: string[];

    @Output() delete = new EventEmitter<number>();
    @Output() submit = new EventEmitter<SubmitCommittee>();

    constructor() { }

    ngOnInit(): void { 
        this.lawContactsList = this.lawContacts;
        console.log('Committee Card in ready.');
    }

    ngOnDestroy() { }

    onDelete() {
        this.delete.emit(this.c)
        this.ngOnDestroy();
    }

    onChangeName(n: string, i: number) {
        this.parm.index = i;
        this.user = this.lawContacts.find(lc => lc.name === this.lawContact);
        this.purposeWork = this.purposes.find(p => p.description === this.purposeString);
        this.parm.committeeCard.role = this.role;
        this.parm.committeeCard.purpose = this.purposeWork;
        this.parm.committeeCard.lawContact = this.user;
        // this.submit.emit(this.parm);
    }

    onChangePurpose(p: string, i: number) {
        this.parm.index = i;
        this.user = this.lawContacts.find(lc => lc.name === this.lawContact);
        this.purposeWork = this.purposes.find(p => p.description === this.purposeString);
        this.parm.committeeCard.role = this.role;
        this.parm.committeeCard.purpose = this.purposeWork;
        this.parm.committeeCard.lawContact = this.user;
        // this.submit.emit(this.parm);
    }
    
    onChangeRole(r: string, i: number) {
        this.parm.index = i;
        this.user = this.lawContacts.find(lc => lc.name === this.lawContact);
        this.purposeWork = this.purposes.find(p => p.description === this.purposeString);
        this.parm.committeeCard.role = r;
        this.parm.committeeCard.purpose = this.purposeWork;
        this.parm.committeeCard.lawContact = this.user;
        // this.submit.emit(this.parm);
    }

    onChangeLawContact(lawcontact: string) {
        this.purposeWork = this.purposes.find(p => p.description === this.purposeString);
        this.lawContactWork = this.lawContacts.find(lc => lc.name === lawcontact);
        this.parm.index = this.c;
        this.parm.committeeCard.name = this.name;
        this.parm.committeeCard.purpose = this.purposeWork;
        this.parm.committeeCard.role = this.role;
        this.parm.committeeCard.lawContact = this.lawContactWork;
        // this.submit.emit(this.parm)
    }

    onSetLawContact(lawcontact: User) {
        this.lawContact = lawcontact.name;
        this.committeeCard.lawContact = lawcontact;
        this.committeeCard.lawContact = this.lawContactsList.find(value => value.name === lawcontact.name);
        this.lawContactsList = [];
    }

}
