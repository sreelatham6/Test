import { ParticipationViewComponent } from './participation-view/participation-view.component';
import { OrgTreeItemComponent } from './orgtree-item/orgtree-item.component';
import { RightNavComponent } from './right-nav/right-nav.component';
import { SupervisorViewComponent } from './supervisor-view/supervisor-view.component';

export const components: any[] = [ParticipationViewComponent,OrgTreeItemComponent,RightNavComponent,SupervisorViewComponent];

export * from './participation-view/participation-view.component';
export * from './orgtree-item/orgtree-item.component';
export * from './right-nav/right-nav.component';
export * from './supervisor-view/supervisor-view.component';