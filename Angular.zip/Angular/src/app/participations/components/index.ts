import { ParticipationViewComponent } from './participation-view/participation-view.component';

export const components: any[] = [ParticipationViewComponent];

export * from './participation-view/participation-view.component';