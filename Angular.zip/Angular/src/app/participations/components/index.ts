import { CommitteeCardComponent } from './committeeCard/committeeCard.component';
import { OrgTreeItemComponent } from './orgtree-item/orgtree-item.component';
import { ParticipationViewComponent } from './participation-view/participation-view.component';
import { RightNavComponent } from './right-nav/right-nav.component';
import { RoleCardComponent } from './roleCard/roleCard.component';
import { SupervisorViewComponent } from './supervisor-view/supervisor-view.component';

export const components: any[] = [
    CommitteeCardComponent,
    OrgTreeItemComponent,
    ParticipationViewComponent,
    RightNavComponent,
    RoleCardComponent,
    SupervisorViewComponent
];

export * from './committeeCard/committeeCard.component';
export * from './orgtree-item/orgtree-item.component';
export * from './participation-view/participation-view.component';
export * from './right-nav/right-nav.component';
export * from './roleCard/roleCard.component';
export * from './supervisor-view/supervisor-view.component';