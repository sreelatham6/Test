import { Component, OnInit, ChangeDetectionStrategy, Input } from '@angular/core';
import { Store } from '@ngrx/store';
import { CommonModule } from '@angular/common';
import { Observable } from 'rxjs';
import * as svc from '../../services';

import { User } from '../../models';
import * as fromStore from '../../store';

@Component({
  selector: 'orgtree-item',
  templateUrl: './orgtree-item.component.html',
  styleUrls: ['./orgtree-item.component.html'],
  changeDetection: ChangeDetectionStrategy.OnPush
})

export class OrgTreeItemComponent implements OnInit {

  @Input() item: User;
  @Input() count: number;
  @Input() index: number;

  constructor(
    private store: Store<fromStore.ParticipationState>,
    private svc: svc.ParticipationsService
  ) { }

  private user: User;
  private user$: Observable<User>;

  ngOnInit() {
    if (this.count === this.index) {
      this.user$ = this.store.select(fromStore.getUser) as Observable<User>;
      this.user$.subscribe((u: User) => this.user = u);
      console.log(this.user);
    }
  }

  onPencil() {
    this.svc.changeSuperviser();
  }
}