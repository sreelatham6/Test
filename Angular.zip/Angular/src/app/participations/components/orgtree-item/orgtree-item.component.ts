import { Component, OnInit, ChangeDetectionStrategy, Input } from '@angular/core';
import { Store } from '@ngrx/store';
import { CommonModule } from '@angular/common';
import { Observable } from 'rxjs';
import { AuthService } from '../../../shared/services/auth.service';
import { delay } from 'rxjs/operators';

import * as mdl from '../../models';
import * as fromR from '../../store/reducers/participations.reducer';

@Component({
    selector: 'orgtree-item',
    templateUrl: './orgtree-item.component.html',
    styleUrls: ['./orgtree-item.component.html'],
    changeDetection: ChangeDetectionStrategy.OnPush
  })

  export class OrgTreeItemComponent implements OnInit{

    @Input() item: mdl.OrgTree;
    @Input() count: number;
    @Input() index: number;

    constructor(
    private store: Store<fromR.ParticipationState>,
    ){}

    private lanID: string;
    private domain: string;
    private lanID$: Observable<string>;
    private domain$: Observable<string>;
    private name: string;
    private title: string;
    private name$: Observable<string>;
    private title$: Observable<string>;

    ngOnInit(){
      this.lanID$ = this.store.select(fromR.getLanId) as Observable<string>;
      this.domain$ = this.store.select(fromR.getDomain) as Observable<string>;
      this.name$ = this.store.select(fromR.getName) as Observable<string>;
      this.title$ = this.store.select(fromR.getTitle) as Observable<string>;

      this.lanID$.subscribe(id => this.lanID = id);
      this.domain$.subscribe(dom => this.domain = dom);
      this.name$.subscribe(username => this.name = username);
      this.domain$.subscribe(usertitle => this.title = usertitle);
      console.log(this.name);
      console.log(this.title);
    }
  }