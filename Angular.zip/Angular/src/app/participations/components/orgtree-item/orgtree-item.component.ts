import { Component, OnInit, ChangeDetectionStrategy, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { OrgTree } from '../../models';


@Component({
    selector: 'orgtree-item',
    templateUrl: './orgtree-item.component.html',
    styleUrls: ['./orgtree-item.component.html'],
    changeDetection: ChangeDetectionStrategy.OnPush
  })

  export class OrgTreeItemComponent implements OnInit{

    @Input() item: OrgTree;
    @Input() count: number;
    @Input() index: number;

    ngOnInit(){

    }

  }