import { Component, OnInit, ChangeDetectionStrategy, Input } from '@angular/core';
import { Store } from '@ngrx/store';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { Subscription, Observable, Subject } from 'rxjs';
import * as fromA from '../../store/actions/participations.actions';
import * as fromR from '../../store/reducers/participations.reducer';
import * as svc from '../../services';
import * as mdl from '../../models';

@Component({
  selector: 'participation-view',
  templateUrl: './participation-view.component.html',
  styleUrls: ['./participation-view.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush

})
export class ParticipationViewComponent implements OnInit {

  private rightNavSub: Subscription;
  private orgTreeSource = new Subject<mdl.OrgTree[]>();
  private orgTreeEvent: Observable<mdl.OrgTree[]>;
  private orgTree: mdl.OrgTree[];
  private orgTree$: Observable<mdl.OrgTree[]>;

  @Input() participation: mdl.Participation;

  constructor(
    private svc: svc.ParticipationsService,
    private store: Store<fromR.ParticipationState>,
    ) { 
    this.rightNavSub = this.svc.rightNavEvent.subscribe(
      (pencil: string) => {
        // pop up superviser lookup
        // update superviser
        // get org tree for superviser
        // throw org to right menu
        this.svc.updateOrgTree(this.orgTree);
      }
    );
  }

  ngOnInit() {
    this.store.dispatch(new fromA.LoadOrgTree(this.participation.name));

    this.orgTree$ = this.store.select(fromR.getOrgTree) as Observable<mdl.OrgTree[]>;
    this.orgTree$.subscribe(tree => this.orgTree = tree);

    this.svc.updateOrgTree(this.orgTree);
  }

}
