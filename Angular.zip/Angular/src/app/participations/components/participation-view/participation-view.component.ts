import { Component, OnInit, OnDestroy, ChangeDetectionStrategy, Input, Output, EventEmitter, OnChanges, SimpleChanges } from '@angular/core';
import { Store } from '@ngrx/store';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, FormGroupName, FormArray, FormControl, FormControlName, Validators } from '@angular/forms';
import { MatCard, MatDialog } from '@angular/material';

import { Subscription, Observable, Subject } from 'rxjs';
import { User, Participation, Purpose, Taig, RoleCard, CommitteeCard, SubmitCommittee, SubmitRole } from '../../models';
import { ParticipationsService } from '../../services';
import { SupervisorViewComponent } from '../supervisor-view/supervisor-view.component';
import { TaigTitlePipe, LawContactPipe, SupervisorPipe } from '../../shared/pipes';

import * as fromA from '../../store/actions/participations.actions';
import * as fromR from '../../store/reducers/participations.reducer';
import * as fromApp from '../../../store';
import { ValueTransformer } from '@angular/compiler/src/util';


@Component({
  selector: 'participation-view',
  templateUrl: './participation-view.component.html',
  styleUrls: ['./participation-view.component.scss'],
  // changeDetection: ChangeDetectionStrategy.OnPush
})

export class ParticipationViewComponent implements OnInit, OnDestroy {
  private rightNavSub: Subscription;
  private SubLawContacts: Subscription;
  private SubOrgTree: Subscription;
  private SubPurposes: Subscription;
  private SubRoles: Subscription;
  private SubSupervisors: Subscription;
  private SubTaigs: Subscription;
  private SubUsers: Subscription;

  private orgTreeSource = new Subject<User[]>();
  private orgTreeEvent: Observable<User[]>;
  private orgTree: User[];
  private orgTree$: Observable<User[]>;
  private purposes$: Observable<Purpose[]>;
  private purposes: Purpose[];
  private roles$: Observable<string[]>;
  private roles: string[];
  private taigs$: Observable<Taig[]>;
  private taigs: Taig[] = [];
  private taigsList: Taig[] = [];
  private taig: Taig;
  private user$: Observable<User>;
  private user: User;

  private lawContacts$: Observable<User[]>;
  private lawContacts: User[] = [];
  private lawContact: User;
  private lawContactsList: User[] = [];
  
  private c: number = 0;
  private r: number = 0;
  
  private supervisor$: Observable<User>;
  private supervisor: User;
  
  private blankCommitteeCard: CommitteeCard = { 'name': '', 'purpose': { 'id': 0, 'description': '' }, 'role': '', 'lawContact': { 'lanId': '', 'domain': '', 'name': '', 'title': '', 'id': '0' } };
  private blankRoleCard: RoleCard = { 'role': '', 'other': '', 'lawContact': { 'lanId': '', 'domain': '', 'name': '', 'title': '', 'id': '0' } };
  
  private showTaig = false;
  private showMbrLawContact = false;
  private no: boolean = false;
  private localParticipation: Participation | null;
  private mbrLawContact: string = '';
  private title: string = '';

  errorMessage: string = '';
  componentActive = true;
  roleCards: RoleCard[] = [];
  committeeCards: CommitteeCard[] = [];

  @Input() participation: Participation;
  @Output() submitted = new EventEmitter<Participation>();

  constructor(
    private fb: FormBuilder,
    private svc: ParticipationsService,
    private store: Store<fromR.ParticipationState>,
    private dialog: MatDialog,
  ) { }

  // displayParticipation(participation: Participation | null): void {
  //   // Set the local product property
  //   this.localParticipation = participation;

  //   if (this.localParticipation) {
  //     // Reset the form back to pristine
  //     this.participationForm.reset();

  //     // Update the data on the form
  //     this.participationForm.patchValue({
  //       lawContact: this.localParticipation.lawContact
  //     });
  //   }
  // }

  ngOnInit() {

    this.rightNavSub = this.svc.rightNavEvent.subscribe(
      (pencil: string) => {
        // pop up superviser picker
        this.dialog.open(SupervisorViewComponent, {
          height: '400px',
          width: '600px',
          hasBackdrop: false
        });

        // get superviser from store that was loaded by supervisor picker process
        this.supervisor$ = this.store.select(fromR.getSupervisor);
        this.SubSupervisors = this.supervisor$.subscribe(s => this.supervisor = s);
        // load new organizational tree based on the new supervisor
        this.store.dispatch(new fromA.LoadOrgTree(this.supervisor))
        // get organizational tree from store
        this.orgTree$ = this.store.select(fromR.getOrgTree) as Observable<User[]>;
        this.SubOrgTree = this.orgTree$.subscribe(tree => this.orgTree = tree);
        // throw organizational tree to right nav to display
        this.svc.updateOrgTree(this.orgTree);
      }
    );

    this.lawContacts$ = this.store.select(fromR.getLawContacts) as Observable<User[]>;
    this.purposes$ = this.store.select(fromR.getPurposes) as Observable<Purpose[]>;
    this.roles$ = this.store.select(fromR.getRoles) as Observable<string[]>;
    this.supervisor$ = this.store.select(fromR.getSupervisor);
    this.taigs$ = this.store.select(fromR.getTaigs) as Observable<Taig[]>;
    this.user$ = this.store.select(fromR.getUser) as Observable<User>;
    
    this.SubLawContacts = this.lawContacts$.subscribe(lm => this.lawContacts = lm);
    this.SubPurposes = this.purposes$.subscribe(p => this.purposes = p);
    this.SubRoles = this.roles$.subscribe(r => this.roles = r);
    this.SubSupervisors = this.supervisor$.subscribe(s => this.supervisor = s);
    this.SubTaigs = this.taigs$.subscribe(t => this.taigs = t);
    this.SubUsers = this.user$.subscribe(u => this.user = u);

    this.taigsList = this.taigs;
    this.lawContactsList = this.lawContacts;

    this.orgTree$ = this.store.select(fromR.getOrgTree) as Observable<User[]>;
    this.SubOrgTree = this.orgTree$.subscribe(tree => this.orgTree = tree);
    this.svc.updateOrgTree(this.orgTree);
  }

  ngOnDestroy() {
    this.rightNavSub.unsubscribe();
    this.SubLawContacts.unsubscribe();
    this.SubPurposes.unsubscribe();
    this.SubRoles.unsubscribe();
    this.SubSupervisors.unsubscribe();
    this.SubTaigs.unsubscribe();
    this.SubUsers.unsubscribe();
  }

  onChange(title: string) {
    if (!title) {
      this.taigsList = this.taigs;
      this.showTaig = false;
    } else {
      this.taig = this.taigs.find(t => t.title === title);
    }
  }
  
  onSetTaig(title: string) {
    this.title = title;
    this.taig = this.taigs.find(t => t.title === title);
    this.taigsList = [];
    this.showTaig = true;
  }
  
  onChangeMbrLawContact(lawcontact: string) {
    if (!lawcontact) {
      this.lawContactsList = this.lawContacts;
      this.showMbrLawContact = false;
    } else {
      this.lawContact = this.lawContacts.find(value => value.name === lawcontact);
      this.showMbrLawContact = true;
    }
  }
  
  onSetMbrLawContact(lawcontact: User) {
    this.mbrLawContact = lawcontact.name;
    this.lawContact = this.lawContacts.find(value => value.name === lawcontact.name);
    this.lawContactsList = [];
    this.showMbrLawContact = false;
  }

  onAddRoleCard() {
    this.lawContacts = this.lawContacts;
    this.roles = this.roles;
    this.roleCards.push(this.blankRoleCard);
  }
  
  onAddCommitteeCard() {
    this.lawContacts = this.lawContacts;
    this.purposes = this.purposes;
    this.roles = this.roles;
    this.committeeCards.push(this.blankCommitteeCard);
  }

  onComSubmit(card: SubmitCommittee) {
    this.committeeCards[card.index] = card.committeeCard;
  }

  onRoleSubmit(card: SubmitRole) {
    this.roleCards[card.index] = card.roleCard;
  }

  onComDelete(i:number) {
    this.committeeCards = this.committeeCards.splice(i, 1);
  }

  onRoleDelete(i:number) {
    this.roleCards = this.roleCards.splice(i, 1);
  }

  onSubmit(): void {

    this.localParticipation.taig = this.taig;
    this.localParticipation.user = this.user;
    this.localParticipation.supervisor = this.supervisor;
    this.localParticipation.lawContact = this.lawContact;
    this.localParticipation.roles = this.roleCards;
    this.localParticipation.committees = this.committeeCards;

    this.submitted.emit(this.localParticipation);
  }

  onCancel() {
    this.store.dispatch(new fromApp.Go({ path: ['participations'] }));
  }
}
