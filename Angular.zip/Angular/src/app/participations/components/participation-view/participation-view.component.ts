import { Component, OnInit, OnDestroy, ChangeDetectionStrategy, Input, Output, EventEmitter } from '@angular/core';
import { Store } from '@ngrx/store';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, FormGroupName, FormArray, FormControl, FormControlName, Validators } from '@angular/forms';
import { MatCard, MatDialog } from '@angular/material';

import { Subscription, Observable, Subject } from 'rxjs';
import { OrgTree, Participation, Taig } from '../../models';
import { ParticipationsService } from '../../services';
import { SupervisorViewComponent } from '../supervisor-view/supervisor-view.component';
import { TaigTitlePipe, LawContactPipe, comLawContactPipe, roleLawContactPipe } from '../../shared/pipes';
import * as fromA from '../../store/actions/participations.actions';
import * as fromR from '../../store/reducers/participations.reducer';
import * as fromApp from '../../../store';
import { ValueTransformer } from '@angular/compiler/src/util';

@Component({
  selector: 'participation-view',
  templateUrl: './participation-view.component.html',
  styleUrls: ['./participation-view.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})

export class ParticipationViewComponent implements OnInit, OnDestroy {
  private rightNavSub: Subscription;
  private orgTreeSource = new Subject<OrgTree[]>();
  private orgTreeEvent: Observable<OrgTree[]>;
  private orgTree: OrgTree[];
  private orgTree$: Observable<OrgTree[]>;
  private purposes$: Observable<string[]>;
  private purposes: string[];
  private roles$: Observable<string[]>;
  private roles: string[];
  private taigs$: Observable<Taig[]>;
  private taigs: Taig[] = [];
  private taigsList: Taig[] = [];
  private taig: Taig;
  private lawContactsMembership$: Observable<string[]>;
  private lawContactsMembership: string[] = [];
  private lawContactsMembershipList: string[] = [];
  private lawcontacts: string[];
  private lawcontactmember: string;
  private lawContactMembership: string;
  private comLawContacts: string[] = [];
  private comLawContactsList: string[] = [];
  private comlawcontactmember: string;
  private comLawContact: string;
  private roleLawContacts: string[] = [];
  private roleLawContactsList: string[] = [];
  private rolelawcontactmember: string;
  private roleLawContact: string;
  private supervisor$: Observable<string>;
  private supervisor: string;
  private title: string = '';
  private lawContact: string;
  private showTaig = false;
  private showLawContactMembership = false;
  private showComLawContact = false;
  private showRoleLawContact = false;
  private no: boolean = false;
  // private  dialog:  MatDialog;

  participationForm: FormGroup;
  roleCard: FormGroup;
  committeeCard: FormGroup;

  // Use with the generic validation message class
  displayMessage: { [key: string]: string } = {};
  private validationMessages: { [key: string]: { [key: string]: string } };
  // private genericValidator: GenericValidator;

  get roleCards(): FormArray {
    return <FormArray>this.participationForm.get('roleCards');
  }
  get committeeCards(): FormArray {
    return <FormArray>this.participationForm.get('committeeCards');
  }

  @Input() participation: Participation;
  @Output() submitted: EventEmitter<Participation>;

  constructor(
    private fb: FormBuilder,
    private svc: ParticipationsService,
    private store: Store<fromR.ParticipationState>,
    private dialog: MatDialog,
  ) { }

  ngOnDestroy() {
    this.rightNavSub.unsubscribe();
  }

  ngOnInit() {
    this.rightNavSub = this.svc.rightNavEvent.subscribe(
      (pencil: string) => {
        // pop up superviser picker
        this.dialog.open(SupervisorViewComponent, {
          height: '400px',
          width: '600px',
          hasBackdrop: false
        });

        // get superviser from store that was loaded by supervisor picker process
        this.supervisor$ = this.store.select(fromR.getSupervisor);
        this.supervisor$.subscribe(s => this.supervisor = s);
        // load new organizational tree based on the new supervisor
        this.store.dispatch(new fromA.LoadOrgTree(this.supervisor))
        // get organizational tree from store
        this.orgTree$ = this.store.select(fromR.getOrgTree) as Observable<OrgTree[]>;
        this.orgTree$.subscribe(tree => this.orgTree = tree);
        // throw organizational tree to right nav to display
        this.svc.updateOrgTree(this.orgTree);
      }
    );

    this.purposes$ = this.store.select(fromR.getPurposes) as Observable<string[]>;
    this.roles$ = this.store.select(fromR.getRoles) as Observable<string[]>;
    this.taigs$ = this.store.select(fromR.getTaigs) as Observable<Taig[]>;
    this.lawContactsMembership$ = this.store.select(fromR.getLawContacts) as Observable<string[]>;

    this.purposes$.subscribe(p => this.purposes = p);
    this.roles$.subscribe(r => this.roles = r);
    this.taigs$.subscribe(t => this.taigs = t);
    this.taigsList = this.taigs;
    this.lawContactsMembership$.subscribe(lm => this.lawContactsMembership = lm);
    //this.lawContactsMembershipList = this.lawContactsMembership;
    this.lawContactsMembership$.subscribe(cl => this.comLawContacts = cl);
    //this.comLawContactsList = this.comLawContacts;
    this.lawContactsMembership$.subscribe(rl => this.roleLawContacts = rl);
    //this.roleLawContactsList = this.roleLawContacts;

    this.orgTree$ = this.store.select(fromR.getOrgTree) as Observable<OrgTree[]>;
    this.orgTree$.subscribe(tree => this.orgTree = tree);
    this.svc.updateOrgTree(this.orgTree);

    this.participationForm = this.fb.group({
      taig: ['', [Validators.required, Validators.minLength(3), Validators.maxLength(50)]],
      title: ['', []],
      lawContact: ['', [Validators.required]],
      roleCards: this.fb.array([]),
      committeeCards: this.fb.array([])
    });

  }

  onChange(title: string) {
    if (!title) {
      this.taigsList = this.taigs;
      this.showTaig = false;
    } else {
      this.taig = this.taigs.find(t => t.title === title);
    }
  }

  onSetTaig(title: string) {
    this.title = title;
    this.taig = this.taigs.find(t => t.title === title);
    this.taigsList = [];
    this.showTaig = true;
  }

  onChangeLawContactMembership(lawcontact:string){
    if(!lawcontact){
      this.lawContactsMembershipList = this.lawContactsMembership;
      this.showLawContactMembership = false;
    } else{
      this.lawContactsMembershipList = this.lawContactsMembership;
      this.lawcontactmember = this.lawContactsMembership.find( value => value === lawcontact);
    }
  }

  onSetLawContactMembership(lawcontact:string){
    this.lawContactMembership = lawcontact;
    this.lawcontactmember = this.lawContactsMembership.find(value => value === lawcontact);
    this.lawContactsMembershipList = [];
    this.showLawContactMembership = true;
  }

  onChangeComLawContact(comlawcontact:string){
    if(!comlawcontact){
      this.comLawContactsList = this.comLawContacts;
      this.showComLawContact = false;
    } else{
      this.comLawContactsList = this.comLawContacts;
      this.comlawcontactmember = this.comLawContacts.find( value => value === comlawcontact);
    }
  }

  onSetComLawContact(comlawcontact:string){
    this.comLawContact = this.comLawContactsList.find(value => value === comlawcontact);
    this.comLawContactsList = [];
    this.showComLawContact = true;
  }

  onChangeRoleLawContact(rolelawcontact:string){
    if(!rolelawcontact){
      this.roleLawContactsList = this.roleLawContacts;
      this.showRoleLawContact = false;
    } else{
      this.roleLawContactsList = this.roleLawContacts;
      this.rolelawcontactmember = this.roleLawContacts.find( value => value === rolelawcontact);
    }
  }

  onSetRoleLawContact(rolelawcontact:string){
    this.lawContact = this.roleLawContactsList.find(value => value === rolelawcontact);
    this.roleLawContactsList = [];
    this.showRoleLawContact = true;
  }

  onAddRoleCard() {
    this.roleCards.push(this.createRoleCard());
  }

  createRoleCard(): FormGroup {
    return this.fb.group({
      role: ['', [Validators.required]],
      other: ['', [Validators.maxLength(35)]],
      //lawContact: ['', [Validators.required]],
      lawContact: new FormControl('')
    });
  }

  deleteRoleCard(index: number): void {
    this.roleCards.removeAt(index);
  }

  onAddCommitteeCard() {
    this.committeeCards.push(this.createCommitteeCard());
  }

  createCommitteeCard(): FormGroup {
    return this.fb.group({
      name: ['', [Validators.required]],
      purpose: ['', [Validators.required]],
      role: ['', [Validators.required]],
      lawContact: ['', [Validators.required]]
    });
  }

  deleteCommitteeCard(index: number): void {
    this.committeeCards.removeAt(index);
  }

  onSubmit(participation: Participation) {
    this.submitted.emit(participation);
  }

  onCancel() {
    this.store.dispatch(new fromApp.Go({ path: ['participations'] }));
  }
}
