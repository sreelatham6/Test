import { Component, OnInit, OnDestroy, ChangeDetectionStrategy, Input, Output, EventEmitter, OnChanges, SimpleChanges } from '@angular/core';
import { Store } from '@ngrx/store';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, FormGroupName, FormArray, FormControl, FormControlName, Validators } from '@angular/forms';
import { MatCard, MatDialog } from '@angular/material';

import { Subscription, Observable, Subject } from 'rxjs';
import { User, Participation, Purpose, Taig } from '../../models';
import { ParticipationsService } from '../../services';
import { SupervisorViewComponent } from '../supervisor-view/supervisor-view.component';
import { TaigTitlePipe, LawContactPipe, SupervisorPipe } from '../../shared/pipes';

import * as fromA from '../../store/actions/participations.actions';
import * as fromR from '../../store/reducers/participations.reducer';
import * as fromApp from '../../../store';
import { ValueTransformer } from '@angular/compiler/src/util';


@Component({
  selector: 'participation-view',
  templateUrl: './participation-view.component.html',
  styleUrls: ['./participation-view.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})

export class ParticipationViewComponent implements OnInit, OnDestroy {
  private rightNavSub: Subscription;
  private orgTreeSource = new Subject<User[]>();
  private orgTreeEvent: Observable<User[]>;
  private orgTree: User[];
  private orgTree$: Observable<User[]>;
  private purposes$: Observable<Purpose[]>;
  private purposes: Purpose[];
  private roles$: Observable<string[]>;
  private roles: string[];
  private taigs$: Observable<Taig[]>;
  private taigs: Taig[] = [];
  private taigsList: Taig[] = [];
  private taig: Taig;
  private lawContactsMembership$: Observable<User[]>;
  private lawContactsMembership: User[] = [];
  private lawContactsMembershipList: User[] = [];
  private lawcontacts: User[];
  private lawcontactmember: User;
  private lawContactMembership: string;
  private comLawContacts: User[] = [];
  private comLawContactsList: User[] = [];
  private comlawcontactmember: User;
  private comLawContact: string;
  private roleLawContacts: User[] = [];
  private roleLawContactsList: User[] = [];
  private rolelawcontactmember: User;
  private roleLawContact: string;
  private supervisor$: Observable<User>;
  private supervisor: User;
  private title: string = '';
  private lawContact: User;
  private showTaig = false;
  private showLawContactMembership = false;
  private showComLawContact = false;
  private showRoleLawContact = false;
  private no: boolean = false;
  private taigMessage: boolean = false;
  private localParticipation: Participation | null;

  errorMessage: string = '';
  componentActive = true;
  participationForm: FormGroup;
  roleCard: FormGroup;
  committeeCard: FormGroup;

  get roleCards(): FormArray {
    return <FormArray>this.participationForm.get('roleCards');
  }
  get committeeCards(): FormArray {
    return <FormArray>this.participationForm.get('committeeCards');
  }

  @Input() participation: Participation;
  @Output() submitted: EventEmitter<Participation>;

  constructor(
    private fb: FormBuilder,
    private svc: ParticipationsService,
    private store: Store<fromR.ParticipationState>,
    private dialog: MatDialog,
  ) {  }

  // displayParticipation(participation: Participation | null): void {
  //   // Set the local product property
  //   this.localParticipation = participation;

  //   if (this.localParticipation) {
  //     // Reset the form back to pristine
  //     this.participationForm.reset();

  //     // Update the data on the form
  //     this.participationForm.patchValue({
  //       lawContact: this.localParticipation.lawContact
  //     });
  //   }
  // }
  
  ngOnDestroy() {
    this.rightNavSub.unsubscribe();
  }
  
  ngOnInit() {
    
    this.rightNavSub = this.svc.rightNavEvent.subscribe(
      (pencil: string) => {
        // pop up superviser picker
        this.dialog.open(SupervisorViewComponent, {
          height: '300px',
          width: '500px',
          hasBackdrop: false,
          disableClose: false
        });
        
        // get superviser from store that was loaded by supervisor picker process
        this.supervisor$ = this.store.select(fromR.getSupervisor);
        this.supervisor$.subscribe(s => this.supervisor = s);
        // load new organizational tree based on the new supervisor
        this.store.dispatch(new fromA.LoadOrgTree(this.supervisor))
        // get organizational tree from store
        this.orgTree$ = this.store.select(fromR.getOrgTree) as Observable<User[]>;
        this.orgTree$.subscribe(tree => this.orgTree = tree);
        // throw organizational tree to right nav to display
        this.svc.updateOrgTree(this.orgTree);
      }
    );

    this.purposes$ = this.store.select(fromR.getPurposes) as Observable<Purpose[]>;
    this.roles$ = this.store.select(fromR.getRoles) as Observable<string[]>;
    this.taigs$ = this.store.select(fromR.getTaigs) as Observable<Taig[]>;
    this.lawContactsMembership$ = this.store.select(fromR.getLawContacts) as Observable<User[]>;

    this.purposes$.subscribe(p => this.purposes = p);
    this.roles$.subscribe(r => this.roles = r);
    this.taigs$.subscribe(t => this.taigs = t);
    this.taigsList = this.taigs;
    this.lawContactsMembership$.subscribe(lm => this.lawContactsMembership = lm);
    this.lawContactsMembership$.subscribe(cl => this.comLawContacts = cl);
    this.lawContactsMembership$.subscribe(rl => this.roleLawContacts = rl);

    this.orgTree$ = this.store.select(fromR.getOrgTree) as Observable<User[]>;
    this.orgTree$.subscribe(tree => this.orgTree = tree);
    this.svc.updateOrgTree(this.orgTree);

    this.participationForm = this.fb.group({
      taig: ['', [Validators.required, Validators.minLength(3), Validators.maxLength(50)]],
      title: ['', []],
      lawContact: ['', [Validators.required]],
      roleCards: this.fb.array([]),
      committeeCards: this.fb.array([])
    });
  }
  
  onChange(title: string) {
    if (!title) {
      this.taigsList = this.taigs;
      this.showTaig = false;
      this.taigMessage = true;
    } else {
      this.taigMessage = false;
      this.taig = this.taigs.find(t => t.title === title);
    }
  }
  
  onSetTaig(title: string) {
    this.title = title;
    this.taig = this.taigs.find(t => t.title === title);
    this.taigsList = [];
    this.showTaig = true;
  }

  onChangeLawContactMembership(lawcontact: string){
    if(!lawcontact){
      this.lawContactsMembershipList = this.lawContactsMembership;
      this.showLawContactMembership = false;
    } else{
      this.lawcontactmember = this.lawContactsMembership.find( value => value.name === lawcontact);
    }
  }

  onSetLawContactMembership(lawcontact: User){
    this.lawContactMembership = lawcontact.name;
    this.lawcontactmember = this.lawContactsMembership.find(value => value.name === lawcontact.name);
    this.lawContactsMembershipList = [];
    this.showLawContactMembership = true;
  }

  onChangeComLawContact(comlawcontact:string){
    if(!comlawcontact){
      this.comLawContactsList = this.comLawContacts;
      this.showComLawContact = false;
    } else{
      this.comlawcontactmember = this.comLawContacts.find( value => value.name === comlawcontact);
    }
  }

  onSetComLawContact(comlawcontact:User){
    this.comLawContact = comlawcontact.name;
    this.comlawcontactmember = this.comLawContactsList.find(value => value.name === comlawcontact.name);
    this.comLawContactsList = [];
    this.showComLawContact = true;
  }
  
  onChangeRoleLawContact(rolelawcontact:string){
    if(!rolelawcontact){
      this.roleLawContactsList = this.roleLawContacts;
      this.showRoleLawContact = false;
    } else{
      this.rolelawcontactmember = this.roleLawContacts.find( value => value.name === rolelawcontact);
    }
  }
  
  onSetRoleLawContact(rolelawcontact:User){
    this.roleLawContact = rolelawcontact.name;
    this.rolelawcontactmember = this.roleLawContactsList.find(value => value.name === rolelawcontact.name);
    this.roleLawContactsList = [];
    this.showRoleLawContact = true;
  }

  onAddRoleCard() {
    this.roleCards.push(this.createRoleCard());
  }

  createRoleCard(): FormGroup {
    return this.fb.group({
      role: ['', [Validators.required]],
      other: ['', [Validators.maxLength(35)]],
      lawContact: ['', [Validators.required]]
    });
  }

  deleteRoleCard(index: number): void {
    this.roleCards.removeAt(index);
  }

  onAddCommitteeCard() {
    this.committeeCards.push(this.createCommitteeCard());
  }

  createCommitteeCard(): FormGroup {
    return this.fb.group({
      name: ['', [Validators.required]],
      purpose: ['', [Validators.required]],
      role: ['', [Validators.required]],
      lawContact: ['', [Validators.required]]
    });
  }

  deleteCommitteeCard(index: number): void {
    this.committeeCards.removeAt(index);
  }

  onSubmit(participation: Participation): void {

    if (this.participationForm.valid) {
      if (this.participationForm.dirty) {

        const p = { ...this.localParticipation, ...this.participationForm.value };

        // if (p.id === 0) {
        //   this.create.emit(p);
        // } else {
        //   this.update.emit(p);
        // }
      }
    }
    this.submitted.emit(this.localParticipation);
  }

  onCancel() {
    this.store.dispatch(new fromApp.Go({ path: ['participations'] }));
  }
}
