import { Component, OnInit, OnDestroy, ChangeDetectionStrategy, Input, Output, EventEmitter, OnChanges, SimpleChanges, ElementRef, ViewChildren } from '@angular/core';
import { Store } from '@ngrx/store';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, FormGroupName, FormArray, FormControl, FormControlName, Validators } from '@angular/forms';
import { MatCard, MatDialog } from '@angular/material';
import { NgForm } from '@angular/forms';

import { Subscription, Observable, Subject } from 'rxjs';
import { Card, User, Participation, Purpose, Taig, RoleCard, CommitteeCard, SubmitCommittee, SubmitRole } from '../../models';
import { ParticipationsService } from '../../services';
import { SupervisorViewComponent } from '../supervisor-view/supervisor-view.component';
import { TaigTitlePipe, LawContactPipe, SupervisorPipe } from '../../shared/pipes';
import * as fromStore from '../../store';
import * as fromApp from '../../../store';

@Component({
  selector: 'participation-view',
  templateUrl: './participation-view.component.html',
  styleUrls: ['./participation-view.component.scss'],
  // changeDetection: ChangeDetectionStrategy.OnPush
})

export class ParticipationViewComponent implements OnInit, OnDestroy {
  rightNavSub: Subscription;
  SubLawContacts: Subscription;
  SubOrgTree: Subscription;
  SubPurposes: Subscription;
  SubRoles: Subscription;
  SubSupervisors: Subscription;
  SubTaigs: Subscription;
  SubUsers: Subscription;

  orgTreeSource = new Subject<User[]>();
  orgTreeEvent: Observable<User[]>;
  orgTree: User[];
  orgTree$: Observable<User[]>;
  purposes$: Observable<Purpose[]>;
  purposes: Purpose[];
  roles$: Observable<string[]>;
  roles: string[];
  taigs$: Observable<Taig[]>;
  taigs: Taig[] = [];
  taigsList: Taig[] = [];
  taig: Taig;
  user$: Observable<User>;
  user: User;

  lawContacts$: Observable<User[]>;
  lawContacts: User[] = [];
  lawContact: User;
  lawContactWork: User;
  lawMbrContactsList: User[] = [];
  
  lawCommitteeContactsList: User[] = [];
  lawRoleContactsList: User[] = [];
  
  c: number = 0;
  r: number = 0;
  
  supervisor$: Observable<User>;
  supervisor: User;
  
  showTaig = false;
  showMbrLawContact = false;
  no: boolean = false;
  localParticipation: Participation;

  mbrLawContact: string = '';
  title: string = '';

  committeePipeValue: string[] = [];
  committeeStop: string[] = [];
  rolePipeValue: string[] = [];
  roleStop: string[] = [];
  
  errorMessage: string = '';
  componentActive = true;
  roleCards: Card[] = [];
  committeeCards: Card[] = [];

  @Input() participation: Participation;
  @Output() submitted = new EventEmitter<Participation>();

  @ViewChildren(Input, { read: ElementRef }) Elements: ElementRef[];


  constructor(
    private fb: FormBuilder,
    private svc: ParticipationsService,
    private store: Store<fromStore.ParticipationState>,
    private dialog: MatDialog,
  ) { }

  
  ngOnInit() {
    
    this.rightNavSub = this.svc.rightNavEvent.subscribe(
      (pencil: string) => {
        // pop up superviser picker
        this.dialog.open(SupervisorViewComponent, {
          height: '400px',
          width: '600px',
          hasBackdrop: false
        });
        
        // get superviser from store that was loaded by supervisor picker process
        this.supervisor$ = this.store.select(fromStore.getSupervisor);
        this.SubSupervisors = this.supervisor$.subscribe(s => this.supervisor = s);
        // load new organizational tree based on the new supervisor
        this.store.dispatch(new fromStore.LoadOrgTree(this.supervisor))
        // get organizational tree from store
        this.orgTree$ = this.store.select(fromStore.getOrgTree) as Observable<User[]>;
        this.SubOrgTree = this.orgTree$.subscribe(tree => this.orgTree = tree);
        // throw organizational tree to right nav to display
        this.svc.updateOrgTree(this.orgTree);
      }
    );
    
    this.localParticipation = this.participation;
    
    this.lawContacts$ = this.store.select(fromStore.getLawContacts) as Observable<User[]>;
    this.purposes$ = this.store.select(fromStore.getPurposes) as Observable<Purpose[]>;
    this.roles$ = this.store.select(fromStore.getRoles) as Observable<string[]>;
    this.supervisor$ = this.store.select(fromStore.getSupervisor);
    this.taigs$ = this.store.select(fromStore.getTaigs) as Observable<Taig[]>;
    this.user$ = this.store.select(fromStore.getUser) as Observable<User>;
    
    
    this.SubLawContacts = this.lawContacts$.subscribe(lm => this.lawContacts = lm);
    this.SubPurposes = this.purposes$.subscribe(p => this.purposes = p);
    this.SubRoles = this.roles$.subscribe(r => this.roles = r);
    this.SubSupervisors = this.supervisor$.subscribe(s => this.supervisor = s);
    this.SubTaigs = this.taigs$.subscribe(t => this.taigs = t);
    this.SubUsers = this.user$.subscribe(u => this.user = u);

    this.taigsList = this.taigs;
    this.lawMbrContactsList = this.lawContacts;

    this.orgTree$ = this.store.select(fromStore.getOrgTree) as Observable<User[]>;
    this.SubOrgTree = this.orgTree$.subscribe(tree => this.orgTree = tree);
    this.svc.updateOrgTree(this.orgTree);

    this.localParticipation = 
    {
      'id': 0,
      'member': {'type': '', 'name':'', 'purpose': { 'id': 0, 'description':'' }, 'role':'', 'other':'',
      'lawContact': { 'lanId':'', 'domain':'', 'name': '', 'title': '', 'id': '0' },
      'supervisor': { 'lanId':'', 'domain':'', 'name': '', 'title': '', 'id': '0' },
      'user': { 'lanId':'', 'domain':'', 'name': '', 'title': '', 'id': '0' },
      'taig': { 'id': 0, 'title':'', 'description': '', 'active': '', 'flag':'', 'sponsoring':'', 'geographical':'', 'country':'', 'state':'', 'purpose': { 'id': 0, 'description':'' }, 'lastReviewed': null } },
      'roles': [],
      'committees':[]
    };
  }

  ngOnDestroy() {
    this.rightNavSub.unsubscribe();
    this.SubLawContacts.unsubscribe();
    this.SubPurposes.unsubscribe();
    this.SubRoles.unsubscribe();
    this.SubSupervisors.unsubscribe();
    this.SubTaigs.unsubscribe();
    this.SubUsers.unsubscribe();
  }

  onChangeTaig(title: string) {
    if (!title) {
      this.taigsList = this.taigs;
      this.showTaig = false;
    } else {
      this.taig = this.taigs.find(t => t.title === title);
    }
  }
  
  onSetTaig(title: string) {
    this.title = title;
    this.taig = this.taigs.find(t => t.title === title);
    this.taigsList = [];
    this.showTaig = true;
  }
  
  onChangeMbrLawContact(lawcontact: string) {
    if (!lawcontact) {
      this.lawMbrContactsList = this.lawContacts;
    } else {
      this.lawContact = this.lawContacts.find(value => value.name === lawcontact);
    }
  }
  
  onSetMbrLawContact(lawcontact: User) {
    this.mbrLawContact = lawcontact.name;
    this.lawContact = this.lawContacts.find(value => value.name === lawcontact.name);
    this.lawMbrContactsList = [];
  }

  onAddRoleCard() {
    this.roleCards.push({
      'type':'','name': '', 'purpose': { 'id': 0, 'description': '' }, 'role': '', 'other':'', 
      'lawContact': { 'lanId': '', 'domain': '', 'name': '', 'title': '', 'id': '0' }, 
      'supervisor': { 'lanId': '', 'domain': '', 'name': '', 'title': '', 'id': '0' }, 
      'user': { 'lanId': '', 'domain': '', 'name': '', 'title': '', 'id': '0' } ,
      'taig': { 'id': 0, 'title':'', 'description': '', 'active': '', 'flag':'', 'sponsoring':'', 'geographical':'', 'country':'', 'state':'', 'purpose':{ 'id': 0, 'description': '' }, 'lastReviewed': null }
    });
    this.roleCards[this.roleCards.length - 1].type = 'Role';
    this.roleCards[this.roleCards.length - 1].supervisor = this.supervisor;
    this.roleCards[this.roleCards.length - 1].taig = this.taig;
    this.roleCards[this.roleCards.length - 1].user = this.user;
    this.roleCards[this.roleCards.length - 1].name = '';
    this.roleCards[this.roleCards.length - 1].purpose = null;
    this.lawCommitteeContactsList = [];
    this.lawRoleContactsList = [];
    this.roleStop[this.roleCards.length - 1] = 'false';
  }
  
  onAddCommitteeCard() {
    this.committeeCards.push({
      'type':'','name': '', 'purpose': { 'id': 0, 'description': '' }, 'role': '', 'other':'', 
      'lawContact': { 'lanId': '', 'domain': '', 'name': '', 'title': '', 'id': '0' }, 
      'supervisor': { 'lanId': '', 'domain': '', 'name': '', 'title': '', 'id': '0' }, 
      'user': { 'lanId': '', 'domain': '', 'name': '', 'title': '', 'id': '0' } ,
      'taig': { 'id': 0, 'title':'', 'description': '', 'active': '', 'flag':'', 'sponsoring':'', 'geographical':'', 'country':'', 'state':'', 'purpose':{ 'id': 0, 'description': '' }, 'lastReviewed': null }
    });
    this.committeeCards[this.committeeCards.length - 1].type = 'Committee';
    this.committeeCards[this.committeeCards.length - 1].supervisor = this.supervisor;
    this.committeeCards[this.committeeCards.length - 1].taig = this.taig;
    this.committeeCards[this.committeeCards.length - 1].user = this.user;
    this.committeeCards[this.committeeCards.length - 1].other = '';
    this.lawCommitteeContactsList = [];
    this.lawRoleContactsList = [];
    this.committeeStop[this.committeeCards.length - 1] = 'false';
  }

  onDeleteCommittee(i:number) {
    this.committeeCards.splice(i, 1);
  }

  onDeleteRole(i:number) {
    this.roleCards.splice(i, 1);
  }

  onCommitteeModelChange(v: string, i: number) {
    this.committeePipeValue[i] = v;
    this.lawCommitteeContactsList = this.lawContacts;
    this.committeeStop[i] = 'false';
  }

  onRoleModelChange(v: string, i: number) {
    this.rolePipeValue[i] = v;
    this.lawRoleContactsList = this.lawContacts;
    this.roleStop[i] = 'false';
  }
  
  onSetRoleLawContact(lawcontact: User, r: number) {
    this.roleCards[r].lawContact = this.lawContacts.find(value => value.name === lawcontact.name);
    this.rolePipeValue[r] = lawcontact.name;
    this.lawRoleContactsList = [];
    this.roleStop[r] = 'true';
  }
  
  onSetCommitteeLawContact(lawcontact: User, c: number) {
    this.committeeCards[c].lawContact = this.lawContacts.find(value => value.name === lawcontact.name);
    this.committeePipeValue[c] = lawcontact.name;
    this.lawCommitteeContactsList = [];
    this.committeeStop[c] = 'true';
  }

  getCommitteeIsActive(length: number, i: number) {
    if ((length > 0) && (this.committeePipeValue[i] !== '') && (this.committeeStop[i] !== 'true')) {
      return { 'em-is-active': true };
    }
    return { 'em-is-active': false };
  }

  getRoleIsActive(length: number, i:number) {
    if ((length > 0) && (this.rolePipeValue[i] !== '') && (this.roleStop[i] !== 'true')) {
      return { 'em-is-active': true };
    }
    return { 'em-is-active': false };
  }

  onSubmit(): void {

    this.localParticipation.member.purpose = this.purposes.find(p => p.description === this.taig.purpose.description);
    this.lawContactWork = this.lawContacts.find(lc => lc.name === this.mbrLawContact);
    this.localParticipation.member.lawContact = this.lawContactWork;
    this.localParticipation.member.supervisor = this.supervisor;
    this.localParticipation.member.taig = this.taig;
    this.localParticipation.member.user = this.user;
    this.localParticipation.committees = this.committeeCards;
    this.localParticipation.roles = this.roleCards;

    this.submitted.emit(this.localParticipation);
  }

  onCancel() {
    this.store.dispatch(new fromApp.Go({ path: ['participations'] }));
  }
}
