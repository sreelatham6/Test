import { Component, OnInit, ChangeDetectionStrategy, Input } from '@angular/core';
import { Participation } from '../../models/participation';
import { Subscription, Observable, Subject } from 'rxjs';
import * as svc from '../../services';

@Component({
  selector: 'participation-view',
  templateUrl: './participation-view.component.html',
  styleUrls: ['./participation-view.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush

})
export class ParticipationViewComponent implements OnInit {

  private rightNavSub: Subscription;
  private orgTreeSource = new Subject<string[]>();
  private orgTreeEvent: Observable<string[]>;
  private orgTree: string[];

  @Input() participation: Participation;

  constructor(private svc: svc.ParticipationsService) { 
    this.rightNavSub = this.svc.rightNavEvent.subscribe(
      (pencil: string) => {
        // pop up superviser lookup
        // update superviser
        // get org tree for supervise
        // throw org to right menu
        this.orgTreeSource.next(this.orgTree);
      }
    );
  }

  ngOnInit() {
  }

}
