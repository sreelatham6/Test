import { Component, OnInit } from '@angular/core';
import { Subscription, Observable, Subject } from 'rxjs';
import * as svc from '../../services';
import * as mdl from '../../models';

@Component({
    selector: 'right-nav',
    templateUrl: './right-nav.component.html',
    styleUrls: ['./right-nav.component.scss']
})
export class RightNavComponent implements OnInit {

    public orgTreeSub: Subscription;
    public orgtree: mdl.OrgTree[]; 

    constructor(private svc: svc.ParticipationsService) {

        this.orgTreeSub = this.svc.orgTreeEvent
            .subscribe((orgTree: mdl.OrgTree[]) => {
                this.orgtree = orgTree;
            });
    }

    ngOnInit(): void { }

    onPencil() {
        this.svc.changeSuperviser();
    }
}
