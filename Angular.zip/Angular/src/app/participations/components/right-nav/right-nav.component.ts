import { Component, OnInit } from '@angular/core';
import { Subscription, Observable, Subject } from 'rxjs';
import { Store } from '@ngrx/store';
import * as svc from '../../services';

import { User } from '../../models';
import * as fromStore from '../../store';

@Component({
    selector: 'right-nav',
    templateUrl: './right-nav.component.html',
    styleUrls: ['./right-nav.component.scss']
})
export class RightNavComponent implements OnInit {

    public orgTreeSub: Subscription;
    public orgtree: User[]; 
    public str: string[];
    public firstname: string;

    constructor(private svc: svc.ParticipationsService,
        private store: Store<fromStore.ParticipationState>) {

        this.orgTreeSub = this.svc.orgTreeEvent
            .subscribe((orgTree: User[]) => {
                this.orgtree = orgTree;
            });
    }

    
        private user: User;
        private user$: Observable<User>;

    ngOnInit(): void { 

        this.user$ = this.store.select(fromStore.getUser) as Observable<User>;
        this.user$.subscribe((u: User) => this.user = u);

        this.str = this.user.name.split(' ');
        this.firstname = this.str[0];
    }
}
