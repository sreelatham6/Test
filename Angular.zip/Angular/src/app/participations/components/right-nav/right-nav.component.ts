import { Component, OnInit } from '@angular/core';
import { Subscription, Observable, Subject } from 'rxjs';
import { Store } from '@ngrx/store';
import * as svc from '../../services';
import * as mdl from '../../models';

import { OrgTree, User } from '../../models';
import * as fromR from '../../store/reducers/participations.reducer';

@Component({
    selector: 'right-nav',
    templateUrl: './right-nav.component.html',
    styleUrls: ['./right-nav.component.scss']
})
export class RightNavComponent implements OnInit {

    public orgTreeSub: Subscription;
    public orgtree: mdl.OrgTree[]; 
    public str: string[];
    public firstname: string;

    constructor(private svc: svc.ParticipationsService,
        private store: Store<fromR.ParticipationState>) {

        this.orgTreeSub = this.svc.orgTreeEvent
            .subscribe((orgTree: mdl.OrgTree[]) => {
                this.orgtree = orgTree;
            });
    }

    
        private user: User;
        private user$: Observable<User>;

    ngOnInit(): void { 

        this.user$ = this.store.select(fromR.getUser) as Observable<User>;
        this.user$.subscribe((u: User) => this.user = u);

        this.str = this.user.name.split(' ');
        this.firstname = this.str[0];
    }

    onPencil() {
        this.svc.changeSuperviser();
    }
}
