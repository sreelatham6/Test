import { Component, OnInit, Input, Output, EventEmitter, OnDestroy } from '@angular/core';
import { RoleCard, User, SubmitRole } from '../../models'

@Component({
    selector: 'role-card',
    templateUrl: './roleCard.component.html',
    styleUrls: ['./roleCard.component.scss']
})
export class RoleCardComponent implements OnInit, OnDestroy {
    private role: string = '';
    private other: string = '';
    private lawContact: string = '';
    private user: User;

    private lawContactsList: User[] = [];
    private parm: SubmitRole = { index: 0, roleCard: { role: this.role, other: '', lawContact: { 'lanId': '', 'domain': '', 'name': '', 'title': '', 'id': '0' } } };


    @Input() r: number;
    @Input() roleCard: RoleCard;
    @Input() roles: string[];
    @Input() lawContacts: User[];

    @Output() submit = new EventEmitter<SubmitRole>();
    @Output() delete = new EventEmitter<number>();

    constructor() { }

    ngOnInit(): void {
        this.lawContactsList = this.lawContacts;
        console.log('Role Card in ready.');
    }

    ngOnDestroy() { }

    onDelete() {
        this.delete.emit(this.r)
        this.ngOnDestroy();
    }

    onChangeOther(o: string, i: number) {
        this.parm.index = i;
        this.user = this.lawContacts.find(lc => lc.name === this.lawContact);
        this.parm.roleCard.role = this.role;
        this.parm.roleCard.other = o;
        this.parm.roleCard.lawContact = this.user;
        this.submit.emit(this.parm)
    }

    onChangeRole(r: string, i: number) {
        this.parm.index = i;
        this.user = this.lawContacts.find(lc => lc.name === this.lawContact);
        this.parm.roleCard.role = r;
        this.parm.roleCard.other = this.other;
        this.parm.roleCard.lawContact = this.user;
        this.submit.emit(this.parm);
    }

    onChangeLawContact(lc: string, i: number) {
        this.parm.index = i;
        this.user = this.lawContacts.find(l => l.name === lc);
        this.parm.roleCard.role = this.role;
        this.parm.roleCard.other = this.other;
        this.parm.roleCard.lawContact = this.user;
        this.submit.emit(this.parm)
    }

    onChangeRoleLawContact(lawcontact: string) {
        if (!lawcontact) {
            this.lawContactsList = this.lawContacts;
        } else {
            this.roleCard.lawContact = this.lawContacts.find(value => value.name === lawcontact);
        }
    }

    onSetRoleLawContact(lawContact: User) {
        this.roleCard.lawContact = lawContact;
        this.roleCard.lawContact = this.lawContactsList.find(value => value.name === lawContact.name);
        this.lawContactsList = [];
    }

}
