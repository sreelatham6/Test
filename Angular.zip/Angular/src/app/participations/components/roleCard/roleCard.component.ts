import { Component, OnInit, Input, Output, EventEmitter, OnDestroy } from '@angular/core';
import { RoleCard, User, SubmitRole } from '../../models'

@Component({
    selector: 'role-card',
    templateUrl: './roleCard.component.html',
    styleUrls: ['./roleCard.component.scss']
})
export class RoleCardComponent implements OnInit, OnDestroy {

    private lawContact: string = '';
    private lawContactsList: User[] = [];
    private other: string = '';
    private parm: SubmitRole = { index: 0, roleCard: { role: '', other: '', lawContact: { 'lanId': '', 'domain': '', 'name': '', 'title': '', 'id': '0' } }} ;
    private role: string = '';
    private user: User;

    @Input() lawContacts: User[];
    @Input() r: number;
    @Input() roleCard: RoleCard;
    @Input() roles: string[];

    @Output() delete = new EventEmitter<number>(true);
    @Output() submit = new EventEmitter<SubmitRole>();

    constructor() { }

    ngOnInit(): void { 
        this.lawContactsList = this.lawContacts;
        console.log('Role Card in ready.');
    }

    ngOnDestroy() { }

    onDelete() {
        this.delete.emit(this.r)
        this.ngOnDestroy();
    }

    onChangeRole(r: string) {
        this.parm.index = this.r;
        this.user = this.lawContacts.find(lc => lc.name === this.lawContact);
        this.parm.roleCard.role = r;
        this.parm.roleCard.other = this.other;
        this.parm.roleCard.lawContact = this.user;
        this.submit.emit(this.parm);
    }

    onChangeOther(o: string) {
        this.parm.index = this.r;
        this.user = this.lawContacts.find(lc => lc.name === this.lawContact);
        this.parm.roleCard.role = this.role;
        this.parm.roleCard.other = o;
        this.parm.roleCard.lawContact = this.user;
        this.submit.emit(this.parm);
    }

    onChangeLawContact(lc: string) {
        this.parm.index = this.r;
        this.user = this.lawContacts.find(l => l.name === lc);
        this.parm.roleCard.role = this.role;
        this.parm.roleCard.other = this.other;
        this.parm.roleCard.lawContact = this.user;
        this.submit.emit(this.parm);
    }

    onSetLawContact(lawcontact: User) {
        this.lawContact = lawcontact.name;
        this.roleCard.lawContact = lawcontact;
        this.roleCard.lawContact = this.lawContactsList.find(value => value.name === lawcontact.name);
        this.lawContactsList = [];
        // this.onChangeLawContact(lawcontact.name);
    }

}
