import { Component, OnInit } from "@angular/core";
import { Store } from '@ngrx/store';
import { FormBuilder, Validators, FormGroup } from "@angular/forms";
import { ParticipationViewComponent } from '../participation-view/participation-view.component';
import { MatCard, MatDialog, MatDialogConfig, MatDialogRef } from '@angular/material';
import { Observable } from "rxjs/Observable";

import { ParticipationsService } from '../../services';
import * as fromA from '../../store/actions/participations.actions';
import * as fromR from '../../store/reducers/participations.reducer';
import * as fromApp from '../../../store';
import { SupervisorPipe } from '../../shared/pipes';
import { User } from "../../models";


@Component({
    selector: 'supervisor-view',
    templateUrl: './supervisor-view.component.html',
    styleUrls: ['./supervisor-view.component.scss']
})

export class SupervisorViewComponent implements OnInit {

    private supervisors$: Observable<User[]>;
    private supervisors: User[];
    private super: User;
    private supervisor: string;
    private showSupervisor: boolean = false;
    private supervisorsList: User[] = [];
    private supervisormember: User;
    //private user: User;

    constructor(
        private store: Store<fromR.ParticipationState>,
        private svc: ParticipationsService
    ){}
    
    ngOnInit() {

        this.supervisors$ = this.store.select(fromR.getSupervisors)
        this.supervisors$.subscribe(s => this.supervisors = s)
    }


    onChangeSupervisor(sup: string){
    if(!sup){
      this.supervisorsList = this.supervisors;
      this.showSupervisor = false;
    } else{
        this.super = this.supervisors.find( value => value.name === sup);
    }
  }

  onSetSupervisor(sup: User){
    this.supervisor = sup.name;
    this.supervisormember = this.supervisors.find(value => value.name === sup.name);
    this.supervisorsList = [];
    this.showSupervisor = true;
  }

  deleteSupervisor(){
    window.close();
  }

  onSubmit(){
    this.store.dispatch(new fromA.SetSupervisor(this.supervisormember));
  }
}