import { Component, OnInit } from "@angular/core";
import { FormBuilder, Validators, FormGroup } from "@angular/forms";
import { ParticipationViewComponent } from '../participation-view/participation-view.component';
import { MatCard, MatDialog, MatDialogConfig, MatDialogRef } from '@angular/material';

@Component({
    selector: 'supervisor-view',
    templateUrl: './supervisor-view.component.html',
    styleUrls: ['./supervisor-view.component.scss']
})

export class SupervisorViewComponent {

    // constructor(public dialogRef: MatDialogRef<SupervisorViewComponent>) { }
    // // form: FormGroup;
    // ngOnInit() {

    // }
}