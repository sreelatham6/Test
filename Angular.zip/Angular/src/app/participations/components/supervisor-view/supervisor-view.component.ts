import { Component, OnInit } from "@angular/core";
import { Store } from '@ngrx/store';
import { FormBuilder, Validators, FormGroup } from "@angular/forms";
import { ParticipationViewComponent } from '../participation-view/participation-view.component';
import { MatCard, MatDialog, MatDialogConfig, MatDialogRef } from '@angular/material';
import { Observable } from "rxjs/Observable";

import { ParticipationsService } from '../../services';
import * as fromA from '../../store/actions/participations.actions';
import * as fromR from '../../store/reducers/participations.reducer';
import * as fromApp from '../../../store';
import { supervisorPipe } from '../../shared/pipes';


@Component({
    selector: 'supervisor-view',
    templateUrl: './supervisor-view.component.html',
    styleUrls: ['./supervisor-view.component.scss']
})

export class SupervisorViewComponent implements OnInit {

    private supervisors$: Observable<string[]>;
    private supervisors: string[];
    private super: string;
    private supervisor: string;
    private showSupervisor: boolean = false;
    private supervisorsList: string[] = [];
    private userSupervisors: string[] = [];

    constructor(
        private store: Store<fromR.ParticipationState>,
        private svc: ParticipationsService
    ){}
    
    ngOnInit() {

        this.supervisors$ = this.store.select(fromR.getSupervisors)
        this.supervisors$.subscribe(s => this.supervisors = s)
    }


    onChangeSupervisor(sup: string){
    if(!sup){
      this.supervisorsList = this.supervisors;
      this.showSupervisor = false;
    } else{
        this.supervisorsList = this.supervisors;
        this.super = this.supervisors.find( value => value === sup);
    }
  }

  onSetSupervisor(sup:string){
    this.supervisor = this.supervisors.find(value => value === sup);
    this.supervisorsList = [];
    this.showSupervisor = true;
  }

  onSubmit(){
    this.svc.getOrgTree(this.supervisor);
  }
}