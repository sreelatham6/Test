import { Component, OnInit } from "@angular/core";
import { Store } from '@ngrx/store';
import { FormBuilder, Validators, FormGroup } from "@angular/forms";
import { ParticipationViewComponent } from '../participation-view/participation-view.component';
import { MatCard, MatDialog, MatDialogConfig, MatDialogRef } from '@angular/material';
import { Observable } from "rxjs/Observable";

import { ParticipationsService } from '../../services';
import * as fromStore from '../../store';
import * as fromApp from '../../../store';
import { SupervisorPipe } from '../../shared/pipes';
import { User } from "../../models";


@Component({
    selector: 'supervisor-view',
    templateUrl: './supervisor-view.component.html',
    styleUrls: ['./supervisor-view.component.scss']
})

export class SupervisorViewComponent implements OnInit {

    supervisors$: Observable<User[]>;
    supervisors: User[];
    super: User;
    supervisor: string;
    showSupervisor: boolean = false;
    supervisorsList: User[] = [];
    supervisormember: User;
    //user: User;

    constructor(
        private store: Store<fromStore.ParticipationState>,
        private svc: ParticipationsService
    ){}
    
    ngOnInit() {

        this.supervisors$ = this.store.select(fromStore.getSupervisors)
        this.supervisors$.subscribe(s => this.supervisors = s)
    }


    onChangeSupervisor(sup: string){
    if(!sup){
      this.supervisorsList = this.supervisors;
      this.showSupervisor = false;
    } else{
        this.super = this.supervisors.find( value => value.name === sup);
    }
  }

  onSetSupervisor(sup: User){
    this.supervisor = sup.name;
    this.supervisormember = this.supervisors.find(value => value.name === sup.name);
    this.supervisorsList = [];
    this.showSupervisor = true;
  }

  deleteSupervisor(){
    window.close();
  }

  onSubmit(){
    this.store.dispatch(new fromStore.SetSupervisor(this.supervisormember));
  }
}