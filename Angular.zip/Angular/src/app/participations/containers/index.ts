import { ParticipationComponent } from './participation/participation.component';
import { ParticipationsComponent } from './participations/participations.component';

export const containers: any[] = [ParticipationComponent, ParticipationsComponent];

export * from './participation/participation.component';
export * from './participations/participations.component';
