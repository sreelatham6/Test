import { Component, OnInit, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, ActivatedRoute } from '@angular/router';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { Participation } from '../../models/participation';
import * as fromStore from '../../store';
import * as fromApp from '../../../../app/store';

@Component({
  selector: 'participation',
  templateUrl: './participation.component.html',
  styleUrls: ['./participation.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ParticipationComponent implements OnInit {

  participation$: Observable<Participation>;
  participation: Participation;
  descriptionFilter: string;
  nameFilter: string;
  errorMessage: string;
  private loaded = false;
  private count = 0;

  constructor(
    private store: Store<fromStore.ParticipationState>,
    private router: Router,
    private ar: ActivatedRoute
  ) {  }

  ngOnInit() {
    this.participation$ = this.store.select(fromStore.getParticipation) as Observable<Participation>;
  }

  onTransfer() {

  }

  onDelete() {

  }

  onKeep() {

  }

  onSubmitted(p: Participation) {
    this.store.dispatch(new fromStore.CreateParticipation(p));
    this.store.dispatch(new fromApp.Go({ path: ['participations'] }));
  }

}
