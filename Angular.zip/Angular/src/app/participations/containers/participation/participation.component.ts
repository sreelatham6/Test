import { Component, OnInit, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, ActivatedRoute } from '@angular/router';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import 'core-js/es7/reflect';
import { Participation } from '../../models/participation';
import * as fromR from '../../store/reducers/participations.reducer';
import * as fromApp from '../../../../app/store';

@Component({
  selector: 'participation',
  templateUrl: './participation.component.html',
  styleUrls: ['./participation.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ParticipationComponent implements OnInit {

  participation$: Observable<Participation>;
  participation: Participation;
  descriptionFilter: string;
  nameFilter: string;
  errorMessage: string;
  private loaded = false;
  private count = 0;

  constructor(
    private store: Store<fromR.ParticipationState>,
    private router: Router,
    private ar: ActivatedRoute
  ) {  }

  ngOnInit() {
    this.participation$ = this.store.select(fromR.getParticipation) as Observable<Participation>;
  }

  onParticipantion() {

  }

  onTransfer() {

  }

  onDelete() {

  }

  onKeep() {

  }

  onSubmitted(p: Participation) {
    console.log(p);
    this.store.dispatch(new fromApp.Go({ path: ['participations'] }));
  }

}
