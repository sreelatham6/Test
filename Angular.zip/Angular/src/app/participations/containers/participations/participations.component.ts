import { Component, ChangeDetectionStrategy, Input, Output, EventEmitter, OnInit  } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Participation }  from '../../models/participation';
import { Store, select } from '@ngrx/store';
import { Observable } from 'rxjs';
import 'core-js/es7/reflect';
import * as fromStore from '../../store';
import * as fromApp from '../../../store/actions';

@Component({
  selector: 'participations',
  templateUrl: './participations.component.html',
  styleUrls: ['./participations.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ParticipationsComponent implements OnInit {

  participations$: Observable<Participation[]>;
  selectedParticipation$: Observable<Participation>;
  errorMessage$: Observable<string>;
  count: Observable<number>;

  constructor(
    private store: Store<fromStore.ParticipationState>
  ) {}
  
  ngOnInit(): void {
    this.store.dispatch(new fromStore.LoadParticipations());
    this.participations$ = this.store.select(fromStore.getParticipations);
    this.errorMessage$ = this.store.select(fromStore.getError);
  }

  onCreate(): void {
    this.store.dispatch(new fromApp.Go({ path: ['participations', 0] }));
  }

  onEdit(participation: Participation): void {
    this.store.dispatch(new fromApp.Go({ path: ['participations', participation.id] }));
  }
}
