import { Component, ChangeDetectionStrategy, Input, Output, EventEmitter, OnInit  } from '@angular/core';
import { Participation }  from '../../models/participation';
import { Store, select } from '@ngrx/store';
import { Observable } from 'rxjs';
import * as fromA from '../../store/actions/participations.actions';
import * as fromR from '../../store/reducers/participations.reducer';
import * as fromApp from '../../../store/actions';

@Component({
  selector: 'participations',
  templateUrl: './participations.component.html',
  styleUrls: ['./participations.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ParticipationsComponent implements OnInit {

  participations$: Observable<Participation[]>;
  selectedParticipation$: Observable<Participation>;
  errorMessage$: Observable<string>;
  count: Observable<number>;

  constructor(
    private store: Store<fromR.ParticipationState>
  ) {}
  
  ngOnInit(): void {
    this.count = this.store.select(fromR.getParticipationsCount);
    console.log('Count: ', this.count);
    if (!this.count) {
      this.store.dispatch(new fromA.LoadParticipations());
    }
    this.store.dispatch(new fromA.LoadParticipations());
    this.participations$ = this.store.select(fromR.getParticipations);
    this.errorMessage$ = this.store.select(fromR.getError);
  }

  onCreate(): void {
    this.store.dispatch(new fromApp.Go({ path: ['participations', 0] }));
  }

  onEdit(participation: Participation): void {
    this.store.dispatch(new fromApp.Go({ path: ['participations', participation.id] }));
  }
}
