import { Purpose, Taig, User } from './';
export interface Card {
    type: string;
    name: string;
    purpose: Purpose;
    role: string;
    other: string;
    lawContact: User;
    supervisor: User;
    user: User;
    taig: Taig;
  }