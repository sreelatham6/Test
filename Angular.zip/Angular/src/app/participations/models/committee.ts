export interface Committee {
    name: string;
    purpose: string;
    role: string;
    lawContact: string;
  }