export interface CommitteeCard {
    name: string;
    purpose: string;
    role: string;
    lawContact: string;
  }