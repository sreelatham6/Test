export interface CommitteeCard {
    name: string;
    purposeId: number;
    purpose: string;
    role: string;
    lawContactId: number;
    lawContact: string;
  }