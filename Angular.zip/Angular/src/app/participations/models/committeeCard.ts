import { Purpose, User } from './';
export interface CommitteeCard {
    name: string;
    purpose: Purpose;
    role: string;
    lawContact: User;
  }