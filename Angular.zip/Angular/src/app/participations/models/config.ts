export interface Config {
    domain: string;
    api: string;
    email: string;
  }