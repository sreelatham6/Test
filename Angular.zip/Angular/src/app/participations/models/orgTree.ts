export interface OrgTree {
    lanId: string;
    name: string;
    title: string;
  }