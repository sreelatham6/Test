import { Committee, Role } from './';

export interface Participation {
    id: number;
    name: string;
    description: string;
    supervisor: string;
    lawContact: string;
    roles: Role[];
    committees: Committee[];
  }
