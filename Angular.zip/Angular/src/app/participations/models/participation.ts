import { CommitteeCard, RoleCard } from './';

export interface Participation {
    id: number;
    taigId: number;
    taig: string;
    userId: number;
    user: string;
    purposeId: number;
    purpose: string;
    supervisorId: number;
    supervisor: string;
    lawContactId: number;
    lawContact: string;
    roles: RoleCard[];
    committees: CommitteeCard[];
  }
