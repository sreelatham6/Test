import { Card } from './';

export interface Participation {
    id: number;
    member: Card;
    roles: Card[];
    committees: Card[];
  }
