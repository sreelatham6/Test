import { CommitteeCard, Purpose, RoleCard, Taig, User } from './';

export interface Participation {
    id: number;
    taig: Taig;
    user: User;
    purpose: Purpose;
    supervisor: User;
    lawContact: User;
    roles: RoleCard[];
    committees: CommitteeCard[];
  }
