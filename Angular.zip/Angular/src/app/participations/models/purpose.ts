export interface Purpose {
    id: number;
	description: string;
};
