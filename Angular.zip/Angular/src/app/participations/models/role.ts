export interface Role {
    role: string;
    purpose: string;
    lawContact: string;
  }
