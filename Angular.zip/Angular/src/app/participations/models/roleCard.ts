export interface RoleCard {
    role: string;
    other: string;
    lawContact: string;
  }
