import { User } from './';
export interface RoleCard {
    role: string;
    other: string;
    lawContact: User;
  }
