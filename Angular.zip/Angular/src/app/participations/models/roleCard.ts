export interface RoleCard {
    role: string;
    other: string;
    lawContactId: number;
    lawContact: string;
  }
