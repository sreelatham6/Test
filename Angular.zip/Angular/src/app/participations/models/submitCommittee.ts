import { CommitteeCard } from './';
export interface SubmitCommittee {
    index: number;
    committeeCard: CommitteeCard;
  }
