import { RoleCard } from './';
export interface SubmitRole {
    index: number;
    roleCard: RoleCard;
  }
