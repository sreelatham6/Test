export interface Taig {
    id: number;
    title: string;
    description: string,
    active: string,
    flag: string,
    sponsoring: string;
    geographical: string;
    country: string;
    state: string;
    purpose: string;
    lastReviewed: Date; 
}
