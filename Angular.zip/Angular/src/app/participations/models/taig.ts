import { Purpose } from './';
export interface Taig {
    id: number;
    title: string;
    description: string,
    active: string,
    flag: string,
    country: string;
    state: string;
    sponsoring: string;
    geographical: string;
    purpose: Purpose;
    lastReviewed: Date; 
}
