export interface User {
	LanId: string;
	UserDomain: string;
	Name: string;
	Title: string;
};
