export interface User {
	id: string;
	lanId: string;
	domain: string;
	name: string;
	title: string;
};
