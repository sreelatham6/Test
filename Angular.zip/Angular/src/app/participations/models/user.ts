export interface User {
	lanId: string;
	domain: string;
	name: string;
	title: string;
	code: string;
};
