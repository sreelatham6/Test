import { InMemoryDbService } from 'angular-in-memory-web-api';

import { Config, Participation, OrgTree, Taig } from '../participations/models';

export class ParticipationsData implements InMemoryDbService {

    createDb() {
        const participations: Participation[] = [
            {
                'id': 1,
                'taigId': 1,
                'taig': 'The very big associations',
                'userId': 1,
                'user': 'Alex Suarez',
                'purposeId': 1,
                'purpose': 'Purpose 1',
                'supervisorId': 1,
                'supervisor': 'Vincent Martinelle',
                'lawContactId': 1,
                'lawContact': 'Catherine',
                'roles': [],
                'committees':[]
            },
            {
                'id': 2,
                'taigId': 1,
                'taig': 'The very big associations',
                'userId': 1,
                'user': 'Alex Suarez',
                'purposeId': 1,
                'purpose': 'Purpose 1',
                'supervisorId': 1,
                'supervisor': 'Vincent Martinelle',
                'lawContactId': 1,
                'lawContact': 'Catherine',
                'roles': [],
                'committees':[]
            },
            {
                'id': 5,
                'taigId': 1,
                'taig': 'The very big associations',
                'userId': 1,
                'user': 'Alex Suarez',
                'purposeId': 1,
                'purpose': 'Purpose 1',
                'supervisorId': 1,
                'supervisor': 'Vincent Martinelle',
                'lawContactId': 1,
                'lawContact': 'Catherine',
                'roles': [],
                'committees':[]
            },
            {
                'id': 8,
                'taigId': 1,
                'taig': 'The very big associations',
                'userId': 1,
                'user': 'Alex Suarez',
                'purposeId': 1,
                'purpose': 'Purpose 1',
                'supervisorId': 1,
                'supervisor': 'Vincent Martinelle',
                'lawContactId': 1,
                'lawContact': 'Catherine',
                'roles': [],
                'committees':[]
            },
            {
                'id': 10,
                'taigId': 1,
                'taig': 'The very big associations',
                'userId': 1,
                'user': 'Alex Suarez',
                'purposeId': 1,
                'purpose': 'Purpose 1',
                'supervisorId': 1,
                'supervisor': 'Vincent Martinelle',
                'lawContactId': 1,
                'lawContact': 'Catherine',
                'roles': [],
                'committees':[]
            }
        ];

        const purposes: string[] = [
            'Advance CCS Public Policy', 
            'Advocacy', 
            'Benchmarking', 
            'Charitable/non-business expertise',
            'Exch knolwedge in Tech and SSH&E areas', 
            'Exch knowledge in Tech areas', 
            'Exch knowledge re: customs, supply chain tax and policy info', 
            'Exch knowledge related to LNG Tanker activities', 
            'Exch opportunities to save disposal cost', 
            'Exch Optimization w/Rig Operators', 
            'Exch. Chemical Innovcation Expertise', 
            'Exch. Industry & Commercial Development', 
            'Exch. SSH&E Expertise-no Commercial Subjects', 
            'Lobbying', 
            'Monitor and influence regulations in business', 
            'Networking', 
            'Provide expertise to committee', 
            'Standard Setting', 
            'Standard Setting - (Pipeline & Marine Loading)', 
            'Standard Setting - Tank Calibration', 
            'Task force dedicated to Life Cycle Assessment refresh', 
            'Understanding PRC Government Policy, regulation and participate in Advocacy as needed', 
            'Other'
        ];

        const roles: string[] = [
            'Member (Only valid for Membership)', 
            'Advisor/Reviewer', 
            'Alternate', 
            'Alternate Board Member', 
            'Alternate Chair', 
            'Alternate Director', 
            'Board Member of TAIG', 
            'Chair', 
            'Chair Elect', 
            'Committee Member (Only for committee)', 
            'Council Member (Only for Committee)', 
            'Editor/Communications', 
            'EM Representative', 
            'Executive Board Leader/Member', 
            'Governance Role', 
            'Leadership Role', 
            'Legal/Counsel', 
            'Other (Max length is 35 characters)'
        ];

        const supervisors: string[] = [
            'Vincent Martinelli', 
            'Juan Nallar', 
            'Catherine Braun', 
            'Sheila O', 
        ];

        const orgtree: OrgTree[] = [
            { 'lanId':'asuare6', 'domain':'na', 'name': 'Alex Suarez', 'title': 'Web Developer, Angular Developer, testing data', 'code':'' },
            { 'lanId':'smaila1', 'domain':'na', 'name': 'Sree Maila', 'title': 'Web Developer Angular Developer', 'code':'' },
            { 'lanId':'vamarti', 'domain':'na', 'name': 'Vincent Martinelli', 'title': 'Project Manager', 'code':'' },
            { 'lanId':'jmnalla', 'domain':'upstreamaccts', 'name': 'Juan Nallar', 'title': 'Application Architect', 'code':'' }
        ];

        const taigs: Taig[] = [
            { 'id': 1, 'title':'Taig 1', 'description': 'Taig One', 'active': 'Y', 'flag':'Green', 'sponsoring':'Sponsoring', 'geographical':'Geographical', 'country':'Country', 'state':'Texas', 'purpose':'Purpose', 'lastReviewed': null },
            { 'id': 2, 'title':'Taig 2', 'description': 'Taig Two', 'active': 'Y', 'flag':'Green', 'sponsoring':'Sponsoring', 'geographical':'Geographical', 'country':'Country', 'state':'Texas', 'purpose':'Purpose', 'lastReviewed': null },
            { 'id': 3, 'title':'Taig 3', 'description': 'Taig Three', 'active': 'Y', 'flag':'Green', 'sponsoring':'Sponsoring', 'geographical':'Geographical', 'country':'Country', 'state':'Texas', 'purpose':'Purpose', 'lastReviewed': null },
            { 'id': 4, 'title':'Taig 4', 'description': 'Taig Four', 'active': 'Y', 'flag':'Green', 'sponsoring':'Sponsoring', 'geographical':'Geographical', 'country':'Country', 'state':'Texas', 'purpose':'Purpose', 'lastReviewed': null },
            { 'id': 5, 'title':'Taig 5', 'description': 'Taig Five', 'active': 'Y', 'flag':'Green', 'sponsoring':'Sponsoring', 'geographical':'Geographical', 'country':'Country', 'state':'Texas', 'purpose':'Purpose', 'lastReviewed': null },
            { 'id': 6, 'title':'Taig 6', 'description': 'Taig Six', 'active': 'Y', 'flag':'Green', 'sponsoring':'Sponsoring', 'geographical':'Geographical', 'country':'Country', 'state':'Texas', 'purpose':'Purpose', 'lastReviewed': null },
        ];

        return { participations, purposes, orgtree, roles, supervisors, taigs };
    }
}