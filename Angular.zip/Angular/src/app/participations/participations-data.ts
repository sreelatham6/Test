import { InMemoryDbService } from 'angular-in-memory-web-api';

import { Participation } from '../participations/models/participation';

export class ParticipationsData implements InMemoryDbService {

    createDb() {
        const participations: Participation[] = [
            {
                'id': 1,
                'name': 'Leaf Rake',
                'description': 'Leaf rake with 48-inch wooden handle',
                'supervisor': 'Vincent Martinelle',
                'lawContact': 'Cat',
                'roles': [],
                'committees':[]
            },
            {
                'id': 2,
                'name': 'Garden Cart',
                'description': '15 gallon capacity rolling garden cart',
                'supervisor': 'Vincent Martinelle',
                'lawContact': 'Cat',
                'roles': [],
                'committees':[]
            },
            {
                'id': 5,
                'name': 'Hammer',
                'description': 'Curved claw steel hammer',
                'supervisor': 'Vincent Martinelle',
                'lawContact': 'Cat',
                'roles': [],
                'committees':[]
            },
            {
                'id': 8,
                'name': 'Saw',
                'description': '15-inch steel blade hand saw',
                'supervisor': 'Vincent Martinelle',
                'lawContact': 'Cat',
                'roles': [],
                'committees':[]
            },
            {
                'id': 10,
                'name': 'Video Game Controller',
                'description': 'Standard two-button video game controller',
                'supervisor': 'Vincent Martinelle',
                'lawContact': 'Cat',
                'roles': [],
                'committees':[]
            }
        ];
        return { participations };
    }
}