import { InMemoryDbService } from 'angular-in-memory-web-api';

import { Config, Participation, Taig, User, Purpose } from '../participations/models';

export class ParticipationsData implements InMemoryDbService {

    createDb() {
        const participations: Participation[] = [
            {
                'id': 1,
                'taigId': 1,
                'taig': 'The very big associations',
                'userId': 1,
                'user': 'Alex Suarez',
                'purposeId': 1,
                'purpose': 'Purpose 1',
                'supervisorId': 1,
                'supervisor': 'Vincent Martinelle',
                'lawContactId': 1,
                'lawContact': 'Catherine',
                'roles': [],
                'committees':[]
            },
            {
                'id': 2,
                'taigId': 1,
                'taig': 'The very big associations',
                'userId': 1,
                'user': 'Alex Suarez',
                'purposeId': 1,
                'purpose': 'Purpose 1',
                'supervisorId': 1,
                'supervisor': 'Vincent Martinelle',
                'lawContactId': 1,
                'lawContact': 'Catherine',
                'roles': [],
                'committees':[]
            },
            {
                'id': 5,
                'taigId': 1,
                'taig': 'The very big associations',
                'userId': 1,
                'user': 'Alex Suarez',
                'purposeId': 1,
                'purpose': 'Purpose 1',
                'supervisorId': 1,
                'supervisor': 'Vincent Martinelle',
                'lawContactId': 1,
                'lawContact': 'Catherine',
                'roles': [],
                'committees':[]
            },
            {
                'id': 8,
                'taigId': 1,
                'taig': 'The very big associations',
                'userId': 1,
                'user': 'Alex Suarez',
                'purposeId': 1,
                'purpose': 'Purpose 1',
                'supervisorId': 1,
                'supervisor': 'Vincent Martinelle',
                'lawContactId': 1,
                'lawContact': 'Catherine',
                'roles': [],
                'committees':[]
            },
            {
                'id': 10,
                'taigId': 1,
                'taig': 'The very big associations',
                'userId': 1,
                'user': 'Alex Suarez',
                'purposeId': 1,
                'purpose': 'Purpose 1',
                'supervisorId': 1,
                'supervisor': 'Vincent Martinelle',
                'lawContactId': 1,
                'lawContact': 'Catherine',
                'roles': [],
                'committees':[]
            }
        ];

        const purposes: Purpose[] = [
            { 'id': 1, 'description':'Advance CCS Public Policy' }, 
            { 'id': 2, 'description':'Advocacy' }, 
            { 'id': 3, 'description':'Benchmarking' }, 
            { 'id': 4, 'description':'Charitable/non-business expertise' } ,
            { 'id': 5, 'description':'Exch knolwedge in Tech and SSH&E areas' }, 
            { 'id': 6, 'description':'Exch knowledge in Tech areas' }, 
            { 'id': 7, 'description':'Exch knowledge re: customs, supply chain tax and policy info' }, 
            { 'id': 8, 'description':'Exch knowledge related to LNG Tanker activities' }, 
            { 'id': 9, 'description':'Exch opportunities to save disposal cost' }, 
            { 'id': 10, 'description':'Exch Optimization w/Rig Operators' }, 
            { 'id': 11, 'description':'Exch. Chemical Innovcation Expertise' }, 
            { 'id': 12, 'description':'Exch. Industry & Commercial Development' }, 
            { 'id': 13, 'description':'Exch. SSH&E Expertise-no Commercial Subjects' }, 
            { 'id': 14, 'description':'Lobbying' }, 
            { 'id': 15, 'description':'Monitor and influence regulations in business' }, 
            { 'id': 16, 'description':'Networking' }, 
            { 'id': 17, 'description':'Provide expertise to committee' }, 
            { 'id': 18, 'description':'Standard Setting' }, 
            { 'id': 19, 'description':'Standard Setting - (Pipeline & Marine Loading)' }, 
            { 'id': 20, 'description':'Standard Setting - Tank Calibration' }, 
            { 'id': 21, 'description':'Task force dedicated to Life Cycle Assessment refresh' }, 
            { 'id': 22, 'description':'Understanding PRC Government Policy, regulation and participate in Advocacy as needed' }, 
            { 'id': 23, 'description':'Other' }
        ];

        const roles: string[] = [
            'Member (Only valid for Membership)', 
            'Advisor/Reviewer', 
            'Alternate', 
            'Alternate Board Member', 
            'Alternate Chair', 
            'Alternate Director', 
            'Board Member of TAIG', 
            'Chair', 
            'Chair Elect', 
            'Committee Member (Only for committee)', 
            'Council Member (Only for Committee)', 
            'Editor/Communications', 
            'EM Representative', 
            'Executive Board Leader/Member', 
            'Governance Role', 
            'Leadership Role', 
            'Legal/Counsel', 
            'Other (Max length is 35 characters)'
        ];

        const supervisors: User[] = [
            { 'lanId':'asuare6', 'domain':'na', 'name': 'Vincent Martinelli', 'title': 'Supervisor', 'id': '1' },
            { 'lanId':'jmnalla', 'domain':'upstreamaccts', 'name': 'Juan M Nallar', 'title': 'Architech', 'id': '2' },
            { 'lanId':'cbraun', 'domain':'na', 'name': 'Catherine Braun', 'title': 'Business Owner', 'id': '3' },
            { 'lanId':'sheilao', 'domain':'na', 'name': 'Sheila O', 'title': 'Business User', 'id': '4' }
        ];

        const lawContacts: User[] = [
            { 'lanId':'asuare6', 'domain':'na', 'name': 'Vincent Martinelli', 'title': 'Supervisor', 'id': '1' },
            { 'lanId':'jmnalla', 'domain':'upstreamaccts', 'name': 'Juan M Nallar', 'title': 'Architech', 'id': '2' },
            { 'lanId':'cbraun', 'domain':'na', 'name': 'Catherine Braun', 'title': 'Business Owner', 'id': '3' },
            { 'lanId':'sheilao', 'domain':'na', 'name': 'Sheila O', 'title': 'Business User', 'id': '4' }
        ];

        const orgtree: User[] = [
            { 'lanId':'asuare6', 'domain':'na', 'name': 'Alex Suarez', 'title': 'Web Developer', 'id': '1' },
            { 'lanId':'smaila1', 'domain':'na', 'name': 'Sree Maila', 'title': 'Web Developer', 'id': '2' },
            { 'lanId':'vamarti', 'domain':'na', 'name': 'Vincent Martinelli', 'title': 'Project Manager', 'id': '3' },
            { 'lanId':'jmnallar', 'domain':'upstreamaccts', 'name': 'Juan Nallar', 'title': 'Application Architect', 'id': '4' }
        ];

        const taigs: Taig[] = [
            { 'id': 1, 'title':'Taig 1', 'description': 'Taig One', 'active': 'Y', 'flag':'Green', 'sponsoring':'Sponsoring', 'geographical':'Geographical', 'country':'Country', 'state':'Texas', 'purpose':'Purpose', 'lastReviewed': null },
            { 'id': 2, 'title':'Taig 2', 'description': 'Taig Two', 'active': 'Y', 'flag':'Green', 'sponsoring':'Sponsoring', 'geographical':'Geographical', 'country':'Country', 'state':'Texas', 'purpose':'Purpose', 'lastReviewed': null },
            { 'id': 3, 'title':'Taig 3', 'description': 'Taig Three', 'active': 'Y', 'flag':'Green', 'sponsoring':'Sponsoring', 'geographical':'Geographical', 'country':'Country', 'state':'Texas', 'purpose':'Purpose', 'lastReviewed': null },
            { 'id': 4, 'title':'Taig 4', 'description': 'Taig Four', 'active': 'Y', 'flag':'Green', 'sponsoring':'Sponsoring', 'geographical':'Geographical', 'country':'Country', 'state':'Texas', 'purpose':'Purpose', 'lastReviewed': null },
            { 'id': 5, 'title':'Taig 5', 'description': 'Taig Five', 'active': 'Y', 'flag':'Green', 'sponsoring':'Sponsoring', 'geographical':'Geographical', 'country':'Country', 'state':'Texas', 'purpose':'Purpose', 'lastReviewed': null },
            { 'id': 6, 'title':'Taig 6', 'description': 'Taig Six', 'active': 'Y', 'flag':'Green', 'sponsoring':'Sponsoring', 'geographical':'Geographical', 'country':'Country', 'state':'Texas', 'purpose':'Purpose', 'lastReviewed': null },
        ];

        return { lawContacts, participations, purposes, orgtree, roles, supervisors, taigs };
    }
}