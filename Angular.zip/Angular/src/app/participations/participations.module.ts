import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { StoreModule } from '@ngrx/store';
import { reducer } from './store/reducers/participations.reducer';
import { EffectsModule } from '@ngrx/effects';
import { ParticipationsEffects } from './store/effects/participations.effects';

import { components } from './components';
import { containers } from './containers';
import { services } from './services';

import { ParticipationsRoutingModule } from './participations.routing';
import { SharedModule } from './shared';

@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    ParticipationsRoutingModule,
    StoreModule.forFeature('participations', reducer),
    EffectsModule.forFeature([ ParticipationsEffects ]),
  ],
  declarations: [...containers, ...components],
  providers: [...services]
})
export class ParticipationsModule { }
