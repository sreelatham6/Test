import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { FlexLayoutModule } from '@angular/flex-layout';
import { AppMaterialModule } from '../app.material.module';

import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';
import { reducer } from './store/reducers/participations.reducer';
import { ParticipationsEffects } from './store/effects/participations.effects';

import { components } from './components';
import { containers } from './containers';
import { services } from './services';

import { ParticipationsRoutingModule } from './participations.routing';
import { SharedModule } from '../shared/shared.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    SharedModule,
    FlexLayoutModule,
    AppMaterialModule,
    ParticipationsRoutingModule,
    StoreModule.forFeature('participations', reducer),
    EffectsModule.forFeature([ ParticipationsEffects ]),
  ],
  declarations: [...containers, ...components],
  exports: [...containers, ...components],
  providers: [...services]
})
export class ParticipationsModule { }
