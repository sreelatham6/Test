import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import * as fromC from './containers';

const routes: Routes = [
      { path: '', component: fromC.ParticipationsComponent },
      { path: ':id', component: fromC.ParticipationComponent }
];

@NgModule({
      imports: [RouterModule.forChild(routes)],
      exports: [RouterModule]
})

export class ParticipationsRoutingModule { }
