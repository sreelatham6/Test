import { ParticipationsService } from './participations.service';

export const services: any[] = [ParticipationsService];

export * from './participations.service';