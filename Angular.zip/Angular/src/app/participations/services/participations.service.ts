import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpHeaderResponse, HttpRequest, HttpErrorResponse } from '@angular/common/http';
import { Observable, of, Subject } from 'rxjs';
import { catchError } from 'rxjs/operators';

import { Participation, OrgTree, Taig } from '../models';
import { ConfigService } from '../../services';

@Injectable()
export class ParticipationsService {
  private baseUrl: string;
  private httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
      withCredentials: 'true'
    })
  };

  private rightNavSource = new Subject<string>();
  public rightNavEvent: Observable<string>;
  private orgTreeSource = new Subject<OrgTree[]>();
  public orgTreeEvent: Observable<OrgTree[]>;

  private orgTree: OrgTree[];

  constructor(private hc: HttpClient, private cfg: ConfigService) {
    this.baseUrl = `${cfg.api}`;
    this.rightNavEvent = this.rightNavSource.asObservable();
    this.orgTreeEvent = this.orgTreeSource.asObservable();
  }

  changeSuperviser() {
    this.rightNavSource.next('true');
  }

  updateOrgTree(orgTree: OrgTree[]) {
    this.orgTreeSource.next(orgTree)
  }

  getParticipations(): Observable<Participation[]> {
    return this.hc.get<Participation[]>(`${this.baseUrl}participations`)
                  .pipe(
                    catchError((error: any) => Observable.throw(error.json()))
                  );

  }

  getParticipation(participation: Participation): Observable<Participation> {
    const id = participation.id;
    if (participation.id === 0) {
      return Observable.create({
        id: 0,
        name: null,
        title: null,
        supervisor: null,
        lawContact: null
      });
    }
    return this.hc.get<Participation>(`${this.baseUrl}participations/${id}`, { responseType: 'json' })
                  .pipe(
                    catchError((error: any) => Observable.throw(error.json()))
                  );
  }

  deleteParticipation(participation: Participation): Observable<Object> {
    return this.hc.delete(`${this.baseUrl}participations/${participation.id}`)
                  .pipe(
                    catchError((error: any) => Observable.throw(error.json()))
                  );
  }

  createParticipation(participation: Participation): Observable<Object> {
    participation.id = void 0;
    return this.hc.post(`${this.baseUrl}participations`, participation, this.httpOptions)
                  .pipe(
                    catchError((error: any) => Observable.throw(error.json()))
                  );
    }

  updateParticipation(participation: Participation): Observable<Object> {
    return this.hc.put(`${this.baseUrl}participations/${participation.id}`, participation, this.httpOptions)
                  .pipe(
                    catchError((error: any) => Observable.throw(error.json()))
                  );
  }

  getOrgTree(supervisor: string): Observable<OrgTree[]> {
    return this.hc.get<OrgTree[]>(`${this.baseUrl}orgtree`)
                  .pipe(
                    catchError((error: any) => Observable.throw(error.json()))
                  );

  }

  getPurposes(): Observable<string[]> {
    return this.hc.get<string[]>(`${this.baseUrl}purposes`)
                  .pipe(
                    catchError((error: any) => Observable.throw(error.json()))
                  );

  }

  getRoles(): Observable<string[]> {
    return this.hc.get<string[]>(`${this.baseUrl}roles`)
                  .pipe(
                    catchError((error: any) => Observable.throw(error.json()))
                  );
  }

  getTaigs(): Observable<Taig[]> {
    return this.hc.get<Taig[]>(`${this.baseUrl}taigs`)
                  .pipe(
                    catchError((error: any) => Observable.throw(error.json()))
                  );

  }

  getSupervisors(): Observable<string[]> {
    return this.hc.get<string[]>(`${this.baseUrl}supervisors`)
                  .pipe(
                    catchError((error: any) => Observable.throw(error.json()))
                  );
  }
}
