import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpHeaderResponse, HttpRequest, HttpErrorResponse } from '@angular/common/http';
import { Observable, of, Subject } from 'rxjs';
import { catchError } from 'rxjs/operators';

import { Participation, OrgTree } from '../models';

@Injectable()
export class ParticipationsService {
  private baseUrl = 'api/participations';
  private httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
      withCredentials: 'true'
    })
  };

  private rightNavSource = new Subject<string>();
  public rightNavEvent: Observable<string>;
  private orgTreeSource = new Subject<OrgTree[]>();
  public orgTreeEvent: Observable<OrgTree[]>;

  private orgTree: OrgTree[];

  constructor(private hc: HttpClient) {
    this.rightNavEvent = this.rightNavSource.asObservable();
    this.orgTreeEvent = this.orgTreeSource.asObservable();
  }

  changeSuperviser() {
    this.rightNavSource.next('true');
  }

  updateOrgTree(orgTree: OrgTree[]) {
    this.orgTreeSource.next(orgTree)
  }

  getParticipations(): Observable<Participation[]> {
    return this.hc.get<Participation[]>(this.baseUrl)
                  .pipe(
                    catchError((error: any) => Observable.throw(error.json()))
                  );

  }

  getParticipation(participation: Participation): Observable<Participation> {
    const id = participation.id;
    if (participation.id === 0) {
      return Observable.create({
        id: 0,
        name: null,
        title: null,
        supervisor: null,
        lawContact: null
      });
    }
    return this.hc.get<Participation>(`${this.baseUrl}/${id}`, { responseType: 'json' })
                  .pipe(
                    catchError((error: any) => Observable.throw(error.json()))
                  );
  }

  deleteParticipation(participation: Participation): Observable<Object> {
    return this.hc.delete(`${this.baseUrl}/${participation.id}`)
                  .pipe(
                    catchError((error: any) => Observable.throw(error.json()))
                  );
  }

  createParticipation(participation: Participation): Observable<Object> {
    participation.id = void 0;
    return this.hc.post(this.baseUrl, participation, this.httpOptions)
                  .pipe(
                    catchError((error: any) => Observable.throw(error.json()))
                  );
    }

  updateParticipation(participation: Participation): Observable<Object> {
    return this.hc.put(`${this.baseUrl}/${participation.id}`, participation, this.httpOptions)
                  .pipe(
                    catchError((error: any) => Observable.throw(error.json()))
                  );
  }

  getOrgTree(supervisor: string): Observable<OrgTree[]> {
    return of([
      { 'lanId':'na/asuare6', 'name': 'Alex Suarez', 'title': 'Web Developer' },
      { 'lanId':'na/smaila1', 'name': 'Sree Maila', 'title': 'Web Developer' },
      { 'lanId':'upstreamaccts/jmnallar', 'name': 'Juan Nallar', 'title': 'Application Architect' }    ]);
    // return this.hc.get<OrgTree[]>(this.baseUrl)
    //               .pipe(
    //                 catchError((error: any) => Observable.throw(error.json()))
    //               );

  }
}
