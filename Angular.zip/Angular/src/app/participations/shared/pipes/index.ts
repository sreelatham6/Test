import { TaigTitlePipe, LawContactPipe, comLawContactPipe, roleLawContactPipe, supervisorPipe } from './taig.pipe';

export const pipes: any[] = [TaigTitlePipe, LawContactPipe, comLawContactPipe, roleLawContactPipe, supervisorPipe];

export * from './taig.pipe';