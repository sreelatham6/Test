import { LawContactPipe } from './lawContact.pipe';
import { SupervisorPipe } from './supervisor.pipe';
import { TaigTitlePipe } from './taig.pipe';

export const pipes: any[] = [TaigTitlePipe, LawContactPipe, SupervisorPipe];

export * from './lawContact.pipe';
export * from './supervisor.pipe';
export * from './taig.pipe';