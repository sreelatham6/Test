import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'stringFilter'
})
export class StringFilterPipe implements PipeTransform {

  transform(value: any[], name: string): any[]{
      name = name ? name.toLocaleLowerCase() : null;
    return name ? value.filter(any) : value;

  }
//   transform(value: any[], nameBy: string): Taig[] {
         nameBy = nameBy ? nameBy.toLocaleLowerCase() : null;
     return nameBy ? value.filter((t: Taig) =>
         t.title.toLocaleLowerCase().indexOf(nameBy) !== -1) : value;
//   }
}
