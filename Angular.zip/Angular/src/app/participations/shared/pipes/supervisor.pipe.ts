import { Pipe, PipeTransform } from '@angular/core';
import { User } from '../../models';

@Pipe({
    name: 'supervisor'
  })
  export class SupervisorPipe implements PipeTransform {
  
    transform(value: User[], nameBy: string): User[] {
      nameBy = nameBy ? nameBy.toLocaleLowerCase() : null;
      return nameBy ? value.filter((l: User) =>
          l.name.toLocaleLowerCase().indexOf(nameBy) !== -1) : value;
    }
  }
  