import { Pipe, PipeTransform } from '@angular/core';
import { Taig } from '../../models';

@Pipe({
  name: 'taigTitle'
})
export class TaigTitlePipe implements PipeTransform {

  transform(value: Taig[], nameBy: string): Taig[] {
    nameBy = nameBy ? nameBy.toLocaleLowerCase() : null;
    return nameBy ? value.filter((t: Taig) =>
        t.title.toLocaleLowerCase().indexOf(nameBy) !== -1) : value;
  }
}

@Pipe({
  name: 'lawContactPipe'
})
export class LawContactPipe implements PipeTransform {

  transform(value: string[], nameBy: string): string[] {
    nameBy = nameBy ? nameBy.toLocaleLowerCase() : null;
    return nameBy ? value.filter((l: string) =>
        l.toLocaleLowerCase().indexOf(nameBy) !== -1) : value;
  }
}

@Pipe({
  name: 'comLawContactPipe'
})
export class comLawContactPipe implements PipeTransform {

  transform(value: string[], nameBy: string): string[] {
    nameBy = nameBy ? nameBy.toLocaleLowerCase() : null;
    return nameBy ? value.filter((lc: string) =>
        lc.toLocaleLowerCase().indexOf(nameBy) !== -1) : value;
  }
}

@Pipe({
  name: 'roleLawContactPipe'
})
export class roleLawContactPipe implements PipeTransform {

  transform(value: string[], nameBy: string): string[] {
    nameBy = nameBy ? nameBy.toLocaleLowerCase() : null;
    return nameBy ? value.filter((lc: string) =>
        lc.toLocaleLowerCase().indexOf(nameBy) !== -1) : value;
  }
}

@Pipe({
  name: 'supervisorPipe'
})
export class supervisorPipe implements PipeTransform {

  transform(value: string[], nameBy: string): string[] {
    nameBy = nameBy ? nameBy.toLocaleLowerCase() : null;
    return nameBy ? value.filter((lc: string) =>
        lc.toLocaleLowerCase().indexOf(nameBy) !== -1) : value;
  }
}