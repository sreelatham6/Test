import { Pipe, PipeTransform } from '@angular/core';
import { Taig } from '../../models';

@Pipe({
  name: 'taigTitle'
})
export class TaigTitlePipe implements PipeTransform {

  transform(value: Taig[], nameBy: string): Taig[] {
    nameBy = nameBy ? nameBy.toLocaleLowerCase() : null;
    return nameBy ? value.filter((t: Taig) =>
        t.title.toLocaleLowerCase().indexOf(nameBy) !== -1) : value;
  }
}
