import { Action } from '@ngrx/store';
import { Participation, OrgTree } from '../../models';

export enum ParticipationActionTypes {
  gotoParticipation = '[Participation] Goto Participation',
  SetCurrentParticipation = '[Participation] Set Current Participation',
  ClearCurrentParticipation = '[Participation] Clear Current Participation',
  InitializeCurrentParticipation = '[Participation] Initialize Current Participation',
  LoadOrgTree = '[Participation] Load OrgTree',
  LoadOrgTreeFail = '[Participation] Load OrgTree Fail',
  LoadOrgTreeSuccess = '[Participation] Load OrgTree Success',
  LoadParticipation = '[Participation] Load Participation',
  LoadParticipationFail = '[Participation] Load Participation Fail',
  LoadParticipationSuccess = '[Participation] Load Participation Success',
  LoadParticipations = '[Participation] Load Participations',
  LoadParticipationsFail = '[Participation] Load Participations Fail',
  LoadParticipationsSuccess = '[Participation] Load Participations Success',
  CreateParticipation = '[Participation] Create Participation',
  CreateParticipationSuccess = '[Participation] Create Participation Success',
  CreateParticipationFail = '[Participation] Create Participation Fail',
  DeleteParticipation = '[Participation] Delete Participation',
  DeleteParticipationSuccess = '[Participation] Delete Participation Success',
  DeleteParticipationFail = '[Participation] Delete Participation Fail',
  UpdateParticipation = '[Participation] Update Participation',
  UpdateParticipationSuccess = '[Participation] Update Participation Success',
  UpdateParticipationFail = '[Participation] Update Participation Fail'
}

export class GotoParticipation implements Action {
  readonly type = ParticipationActionTypes.gotoParticipation;
  constructor(public payload: number) {}
}
export class CreateParticipation implements Action {
  readonly type = ParticipationActionTypes.CreateParticipation;
  constructor(public payload: Participation) {}
}
export class CreateParticipationFail implements Action {
  readonly type = ParticipationActionTypes.CreateParticipationFail;
  constructor(public payload: any) {}
}
export class CreateParticipationSuccess implements Action {
  readonly type = ParticipationActionTypes.CreateParticipationSuccess;
  constructor(public payload: Participation) {}
}
export class DeleteParticipation implements Action {
  readonly type = ParticipationActionTypes.DeleteParticipation;
  constructor(public payload: Participation) {}
}
export class DeleteParticipationFail implements Action {
  readonly type = ParticipationActionTypes.DeleteParticipationFail;
  constructor(public payload: any) {}
}
export class DeleteParticipationSuccess implements Action {
  readonly type = ParticipationActionTypes.DeleteParticipationSuccess;
  constructor(public payload: Participation) {}
}
export class UpdateParticipation implements Action {
  readonly type = ParticipationActionTypes.UpdateParticipation;
  constructor(public payload: Participation) {}
}
export class UpdateParticipationFail implements Action {
  readonly type = ParticipationActionTypes.UpdateParticipationFail;
  constructor(public payload: any) {}
}
export class UpdateParticipationSuccess implements Action {
  readonly type = ParticipationActionTypes.UpdateParticipationSuccess;
  constructor(public payload: Participation) {}
}
export class LoadParticipations implements Action {
  readonly type = ParticipationActionTypes.LoadParticipations;
}
export class LoadParticipationsFail implements Action {
  readonly type = ParticipationActionTypes.LoadParticipationsFail;
  constructor(public payload: any) {}
}
export class LoadParticipationsSuccess implements Action {
  readonly type = ParticipationActionTypes.LoadParticipationsSuccess;
  constructor(public payload: Participation[]) {}
}
export class LoadParticipation implements Action {
  readonly type = ParticipationActionTypes.LoadParticipation;
  constructor(public payload: Participation) {}
}
export class LoadParticipationFail implements Action {
  readonly type = ParticipationActionTypes.LoadParticipationFail;
  constructor(public payload: any) {}
}
export class LoadParticipationSuccess implements Action {
  readonly type = ParticipationActionTypes.LoadParticipationSuccess;
  constructor(public payload: Participation) {}
}
export class ClearCurrentParticipation implements Action {
  readonly type = ParticipationActionTypes.ClearCurrentParticipation;
}
export class SetCurrentParticipation implements Action {
  readonly type = ParticipationActionTypes.SetCurrentParticipation;
  constructor(public payload: Participation) {}
}
export class InitializeCurrentParticipation implements Action {
  readonly type = ParticipationActionTypes.InitializeCurrentParticipation;
}
export class LoadOrgTree implements Action {
  readonly type = ParticipationActionTypes.LoadOrgTree;
  constructor(public payload: string) {}
}
export class LoadOrgTreeFail implements Action {
  readonly type = ParticipationActionTypes.LoadOrgTreeFail;
  constructor(public payload: any) {}
}
export class LoadOrgTreeSuccess implements Action {
  readonly type = ParticipationActionTypes.LoadOrgTreeSuccess;
  constructor(public payload: OrgTree[]) {}
}
export type ParticipationsActions =  CreateParticipation | CreateParticipationFail | CreateParticipationSuccess
                         | UpdateParticipation | UpdateParticipationFail | UpdateParticipationSuccess
                         | DeleteParticipation | DeleteParticipationFail | DeleteParticipationSuccess
                         | LoadParticipation | LoadParticipationFail | LoadParticipationSuccess
                         | LoadParticipations | LoadParticipationsFail | LoadParticipationsSuccess
                         | LoadOrgTree | LoadOrgTreeFail | LoadOrgTreeSuccess
                         | ClearCurrentParticipation | SetCurrentParticipation | InitializeCurrentParticipation;