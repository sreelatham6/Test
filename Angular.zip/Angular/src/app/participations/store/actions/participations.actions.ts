import { Action } from '@ngrx/store';
import { Participation, User, CommitteeCard, RoleCard, Taig, Purpose } from '../../models';

export enum ParticipationActionTypes {
  gotoParticipation = '[Participation] Goto Participation',
  SetUser = '[Participation] Set User',
  SetSupervisor = '[Participation] Set Supervisor',
  LoadCommittees = '[Participation] Load Committees',
  LoadCommitteesFail = '[Participation] Load Committees Fail',
  LoadCommitteesSuccess = '[Participation] Load Committees Success',
  LoadOrgTree = '[Participation] Load OrgTree',
  LoadOrgTreeFail = '[Participation] Load OrgTree Fail',
  LoadOrgTreeSuccess = '[Participation] Load OrgTree Success',
  LoadLawContacts = '[Participation] Load LawContacts',
  LoadLawContactsFail = '[Participation] Load LawContacts Fail',
  LoadLawContactsSuccess = '[Participation] Load LawContacts Success',
  LoadPurposes = '[Participation] Load Purposes',
  LoadPurposesFail = '[Participation] Load Purposes Fail',
  LoadPurposesSuccess = '[Participation] Load Purposes Success',
  LoadRoles = '[Participation] Load Roles',
  LoadRolesFail = '[Participation] Load Roles Fail',
  LoadRolesSuccess = '[Participation] Load Roles Success',
  LoadSupervisor = '[Participation] Load Supervisor',
  LoadSupervisorFail = '[Participation] Load Supervisor Fail',
  LoadSupervisorSuccess = '[Participation] Load Supervisor Success',
  LoadSupervisors = '[Participation] Load Supervisors',
  LoadSupervisorsFail = '[Participation] Load Supervisors Fail',
  LoadSupervisorsSuccess = '[Participation] Load Supervisors Success',
  LoadTaigs = '[Participation] Load Taigs',
  LoadTaigsFail = '[Participation] Load Taigs Fail',
  LoadTaigsSuccess = '[Participation] Load Taigs Success',
  LoadParticipation = '[Participation] Load Participation',
  LoadParticipationFail = '[Participation] Load Participation Fail',
  LoadParticipationSuccess = '[Participation] Load Participation Success',
  LoadParticipations = '[Participation] Load Participations',
  LoadParticipationsFail = '[Participation] Load Participations Fail',
  LoadParticipationsSuccess = '[Participation] Load Participations Success',
  CreateParticipation = '[Participation] Create Participation',
  CreateParticipationSuccess = '[Participation] Create Participation Success',
  CreateParticipationFail = '[Participation] Create Participation Fail',
  DeleteParticipation = '[Participation] Delete Participation',
  DeleteParticipationSuccess = '[Participation] Delete Participation Success',
  DeleteParticipationFail = '[Participation] Delete Participation Fail',
  UpdateParticipation = '[Participation] Update Participation',
  UpdateParticipationSuccess = '[Participation] Update Participation Success',
  UpdateParticipationFail = '[Participation] Update Participation Fail'
}

export class GotoParticipation implements Action {
  readonly type = ParticipationActionTypes.gotoParticipation;
  constructor(public payload: number) {}
}

export class CreateParticipation implements Action {
  readonly type = ParticipationActionTypes.CreateParticipation;
  constructor(public payload: Participation) {}
}
export class CreateParticipationFail implements Action {
  readonly type = ParticipationActionTypes.CreateParticipationFail;
  constructor(public payload: any) {}
}
export class CreateParticipationSuccess implements Action {
  readonly type = ParticipationActionTypes.CreateParticipationSuccess;
  constructor(public payload: Participation) {}
}
export class DeleteParticipation implements Action {
  readonly type = ParticipationActionTypes.DeleteParticipation;
  constructor(public payload: Participation) {}
}
export class DeleteParticipationFail implements Action {
  readonly type = ParticipationActionTypes.DeleteParticipationFail;
  constructor(public payload: any) {}
}
export class DeleteParticipationSuccess implements Action {
  readonly type = ParticipationActionTypes.DeleteParticipationSuccess;
  constructor(public payload: Participation) {}
}
export class UpdateParticipation implements Action {
  readonly type = ParticipationActionTypes.UpdateParticipation;
  constructor(public payload: Participation) {}
}
export class UpdateParticipationFail implements Action {
  readonly type = ParticipationActionTypes.UpdateParticipationFail;
  constructor(public payload: any) {}
}
export class UpdateParticipationSuccess implements Action {
  readonly type = ParticipationActionTypes.UpdateParticipationSuccess;
  constructor(public payload: Participation) {}
}
export class LoadParticipations implements Action {
  readonly type = ParticipationActionTypes.LoadParticipations;
}
export class LoadParticipationsFail implements Action {
  readonly type = ParticipationActionTypes.LoadParticipationsFail;
  constructor(public payload: any) {}
}
export class LoadParticipationsSuccess implements Action {
  readonly type = ParticipationActionTypes.LoadParticipationsSuccess;
  constructor(public payload: Participation[]) {}
}
export class LoadParticipation implements Action {
  readonly type = ParticipationActionTypes.LoadParticipation;
  constructor(public payload: Participation) {}
}
export class LoadParticipationFail implements Action {
  readonly type = ParticipationActionTypes.LoadParticipationFail;
  constructor(public payload: any) {}
}
export class LoadParticipationSuccess implements Action {
  readonly type = ParticipationActionTypes.LoadParticipationSuccess;
  constructor(public payload: Participation) {}
}
///////////////////////////////////////////////////////////////////////
export class LoadOrgTree implements Action {
  readonly type = ParticipationActionTypes.LoadOrgTree;
  constructor(public payload: User) {}
}
export class LoadOrgTreeFail implements Action {
  readonly type = ParticipationActionTypes.LoadOrgTreeFail;
  constructor(public payload: any) {}
}
export class LoadOrgTreeSuccess implements Action {
  readonly type = ParticipationActionTypes.LoadOrgTreeSuccess;
  constructor(public payload: User[]) {}
}
///////////////////////////////////////////////////////////////////////
export class SetUser implements Action {
  readonly type = ParticipationActionTypes.SetUser;
  constructor(public payload: User) {}
}
export class SetSupervisor implements Action {
  readonly type = ParticipationActionTypes.SetSupervisor;
  constructor(public payload: User) {}
}
///////////////////////////////////////////////////////////////////////
export class LoadLawContacts implements Action {
  readonly type = ParticipationActionTypes.LoadLawContacts;
}
export class LoadLawContactsFail implements Action {
  readonly type = ParticipationActionTypes.LoadLawContactsFail;
  constructor(public payload: any) {}
}
export class LoadLawContactsSuccess implements Action {
  readonly type = ParticipationActionTypes.LoadLawContactsSuccess;
  constructor(public payload: User[]) {}
}
///////////////////////////////////////////////////////////////////////
export class LoadPurposes implements Action {
  readonly type = ParticipationActionTypes.LoadPurposes;
}
export class LoadPurposesFail implements Action {
  readonly type = ParticipationActionTypes.LoadPurposesFail;
  constructor(public payload: any) {}
}
export class LoadPurposesSuccess implements Action {
  readonly type = ParticipationActionTypes.LoadPurposesSuccess;
  constructor(public payload: Purpose[]) {}
}
///////////////////////////////////////////////////////////////////////
export class LoadRoles implements Action {
  readonly type = ParticipationActionTypes.LoadRoles;
}
export class LoadRolesFail implements Action {
  readonly type = ParticipationActionTypes.LoadRolesFail;
  constructor(public payload: any) {}
}
export class LoadRolesSuccess implements Action {
  readonly type = ParticipationActionTypes.LoadRolesSuccess;
  constructor(public payload: string[]) {}
}
///////////////////////////////////////////////////////////////////////
export class LoadSupervisors implements Action {
  readonly type = ParticipationActionTypes.LoadSupervisors;
}
export class LoadSupervisorsFail implements Action {
  readonly type = ParticipationActionTypes.LoadSupervisorsFail;
  constructor(public payload: any) {}
}
export class LoadSupervisorsSuccess implements Action {
  readonly type = ParticipationActionTypes.LoadSupervisorsSuccess;
  constructor(public payload: User[]) {}
}
///////////////////////////////////////////////////////////////////////
export class LoadSupervisor implements Action {
  readonly type = ParticipationActionTypes.LoadSupervisor;
  constructor(public payload: User) {}
}
export class LoadSupervisorFail implements Action {
  readonly type = ParticipationActionTypes.LoadSupervisorFail;
  constructor(public payload: any) {}
}
export class LoadSupervisorSuccess implements Action {
  readonly type = ParticipationActionTypes.LoadSupervisorSuccess;
  constructor(public payload: User) {}
}
///////////////////////////////////////////////////////////////////////
export class LoadTaigs implements Action {
  readonly type = ParticipationActionTypes.LoadTaigs;
}
export class LoadTaigsFail implements Action {
  readonly type = ParticipationActionTypes.LoadTaigsFail;
  constructor(public payload: any) {}
}
export class LoadTaigsSuccess implements Action {
  readonly type = ParticipationActionTypes.LoadTaigsSuccess;
  constructor(public payload: Taig[]) {}
}

export type ParticipationsActions =  CreateParticipation | CreateParticipationFail | CreateParticipationSuccess
                         | UpdateParticipation | UpdateParticipationFail | UpdateParticipationSuccess
                         | DeleteParticipation | DeleteParticipationFail | DeleteParticipationSuccess
                         | LoadParticipation | LoadParticipationFail | LoadParticipationSuccess
                         | LoadParticipations | LoadParticipationsFail | LoadParticipationsSuccess
                         | LoadOrgTree | LoadOrgTreeFail | LoadOrgTreeSuccess
                         | LoadLawContacts | LoadLawContactsFail | LoadLawContactsSuccess
                         | LoadPurposes | LoadPurposesFail | LoadPurposesSuccess
                         | LoadRoles | LoadRolesFail | LoadRolesSuccess
                         | LoadSupervisor | LoadSupervisorFail | LoadSupervisorSuccess
                         | LoadSupervisors | LoadSupervisorsFail | LoadSupervisorsSuccess
                         | LoadTaigs | LoadTaigsFail | LoadTaigsSuccess
                         | SetUser | SetSupervisor;
