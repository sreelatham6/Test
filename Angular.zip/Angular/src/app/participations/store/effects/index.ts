import { ParticipationsEffects } from './participations.effects';

export const effects: any[] = [ParticipationsEffects];

export * from './participations.effects';