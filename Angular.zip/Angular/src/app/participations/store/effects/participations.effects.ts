import { Injectable } from '@angular/core';
import { Action } from '@ngrx/store';
import { Actions, Effect } from '@ngrx/effects';
import 'core-js/es7/reflect';
import { Observable } from 'rxjs';
import { of } from 'rxjs';
import { map, tap, exhaustMap, delay, catchError, pluck } from 'rxjs/operators';

import * as fromRoot from '../../../../app/store';
import * as fromServices from '../../services';
import * as fromActions from '../actions/participations.actions';
import { Participation, OrgTree, RoleCard, Taig } from '../../models';
@Injectable()
export class ParticipationsEffects {

  @Effect()
  loadParticipations$: Observable<Action> = this.actions$
    .ofType(fromActions.ParticipationActionTypes.LoadParticipations)
    .pipe(
      tap(action => console.log(`Received ${action.type}`)),
      exhaustMap(action =>
        this.participationsService
          .getParticipations()
          .pipe(
            tap(action => console.log(action)),
            map((participations: Participation[]) => new fromActions.LoadParticipationsSuccess(participations)),
            catchError(err => of(new fromActions.LoadParticipationsFail(err)))
          )
      )
    );

  @Effect()
  loadParticipation$: Observable<Action> = this.actions$
    .ofType(fromActions.ParticipationActionTypes.LoadParticipation)
    .pipe(
      tap(action => console.log(`Received ${action.type}`)),
      map((action: fromActions.LoadParticipation) => action.payload),
      exhaustMap((participation: Participation) =>
        this.participationsService
          .getParticipation(participation)
          .pipe(
            tap(action => console.log(action)),
            map((participation: Participation) => new fromActions.LoadParticipationSuccess(participation)),
            catchError(err => of(new fromActions.LoadParticipationsFail(err)))
          )
      )
    );

  @Effect()
  createParticipation$: Observable<Action> = this.actions$
    .ofType(fromActions.ParticipationActionTypes.CreateParticipation)
    .pipe(
      tap(action => console.log(`Received ${action.type}`)),
      map((action: fromActions.CreateParticipation) => action.payload),
      exhaustMap((participation: Participation) =>
        this.participationsService.createParticipation(participation)
          .pipe(
            tap(action => console.log(action)),
            map((participation: Participation) => new fromActions.CreateParticipationSuccess(participation)),
            catchError(err => of(new fromActions.CreateParticipationFail(err)))
          )
      )
    );

  @Effect()
  updateParticipation$: Observable<Action> = this.actions$
    .ofType(fromActions.ParticipationActionTypes.UpdateParticipation)
    .pipe(
      tap(action => console.log(`Received ${action.type}`)),
      map((action: fromActions.UpdateParticipation) => action.payload),
      exhaustMap((participation: Participation) =>
        this.participationsService.updateParticipation(participation)
          .pipe(
            tap(action => console.log(action)),
            map((participation: Participation) => new fromActions.UpdateParticipationSuccess(participation)),
            catchError(err => of(new fromActions.UpdateParticipationFail(err)))
          )
      )
    );

  @Effect()
  deleteParticipation$: Observable<Action> = this.actions$
    .ofType(fromActions.ParticipationActionTypes.DeleteParticipation)
    .pipe(
      tap(action => console.log(`Received ${action.type}`)),
      map((action: fromActions.DeleteParticipation) => action.payload),
      exhaustMap((participation: Participation) =>
        this.participationsService.deleteParticipation(participation)
          .pipe(
            tap(action => console.log(action)),
            map((participation: Participation) => new fromActions.DeleteParticipationSuccess(participation)),
            catchError(err => of(new fromActions.DeleteParticipationFail(err)))
          )
      )
    );

  @Effect()
  loadOrgTree$: Observable<Action> = this.actions$
    .ofType(fromActions.ParticipationActionTypes.LoadOrgTree)
    .pipe(
      tap(action => console.log(`Received ${action.type}`)),
      map((action: fromActions.LoadOrgTree) => action.payload),
      exhaustMap((supervisor: any) =>
        this.participationsService
          .getOrgTree(supervisor)
          .pipe(
            tap(action => console.log(action)),
            map((orgTree: OrgTree[]) => new fromActions.LoadOrgTreeSuccess(orgTree)),
            catchError(err => of(new fromActions.LoadOrgTreeFail(err)))
          )
      )
    );

  @Effect()
  loadPurposes$: Observable<Action> = this.actions$
    .ofType(fromActions.ParticipationActionTypes.LoadPurposes)
    .pipe(
      tap(action => console.log(`Received ${action.type}`)),
      exhaustMap((action: any) =>
        this.participationsService
          .getPurposes()
          .pipe(
            tap(action => console.log(action)),
            map((purposes: string[]) => new fromActions.LoadPurposesSuccess(purposes)),
            catchError(err => of(new fromActions.LoadPurposesFail(err)))
          )
      )
    );

  @Effect()
  loadRoles$: Observable<Action> = this.actions$
    .ofType(fromActions.ParticipationActionTypes.LoadRoles)
    .pipe(
      tap(action => console.log(`Received ${action.type}`)),
      exhaustMap((action: any) =>
        this.participationsService
          .getRoles()
          .pipe(
            tap(action => console.log(action)),
            map((roles: string[]) => new fromActions.LoadRolesSuccess(roles)),
            catchError(err => of(new fromActions.LoadRolesFail(err)))
          )
      )
    );

  @Effect()
  loadTaigs$: Observable<Action> = this.actions$
    .ofType(fromActions.ParticipationActionTypes.LoadTaigs)
    .pipe(
      tap(action => console.log(`Received ${action.type}`)),
      exhaustMap((action: any) =>
        this.participationsService
          .getTaigs()
          .pipe(
            tap(action => console.log(action)),
            map((taigs: Taig[]) => new fromActions.LoadTaigsSuccess(taigs)),
            catchError(err => of(new fromActions.LoadTaigsFail(err)))
          )
      )
    );

  @Effect()
  handleParticipationSuccess$ = this.actions$
    .ofType(
      fromActions.ParticipationActionTypes.CreateParticipationSuccess,
      fromActions.ParticipationActionTypes.UpdateParticipationSuccess
    )
    .pipe(
      tap(action => console.log(`Received ${action.type}`)),
      map(action => {
        return new fromRoot.Go({
          path: ['/participations']
        });
      })
    );

  @Effect()
  gotoParticipation$ = this.actions$
    .ofType(fromActions.ParticipationActionTypes.gotoParticipation)
    .pipe(
      tap(action => console.log(`Received ${action.type}`)),
      map((action: fromActions.GotoParticipation) => action.payload),
      map(id => {
        return new fromRoot.Go({
          path: ['/participations', id]
        });
      })
    );

  constructor(
    private actions$: Actions,
    private participationsService: fromServices.ParticipationsService
  ) { }

}