import { Injectable } from '@angular/core';
import { Action } from '@ngrx/store';
import { Actions, Effect } from '@ngrx/effects';
import 'core-js/es7/reflect';
import { Observable } from 'rxjs';
import { of } from 'rxjs';
import { map, tap, exhaustMap, delay, catchError, pluck } from 'rxjs/operators';

import * as fromRoot from '../../../../app/store';
import * as fromServices from '../../services';
import * as fromStore from '../';
import { Participation, User, Card, Taig, Purpose } from '../../models';
@Injectable()
export class ParticipationsEffects {

  @Effect()
  loadParticipations$: Observable<Action> = this.actions$
    .ofType(fromStore.ParticipationActionTypes.LoadParticipations)
    .pipe(
      tap(action => console.log(`Received ${action.type}`)),
      exhaustMap(action =>
        this.participationsService
          .getParticipations()
          .pipe(
            tap(participations => console.log(participations)),
            map((participations: Participation[]) => new fromStore.LoadParticipationsSuccess(participations)),
            catchError(err => of(new fromStore.LoadParticipationsFail(err)))
          )
      )
    );

  @Effect()
  loadParticipation$: Observable<Action> = this.actions$
    .ofType(fromStore.ParticipationActionTypes.LoadParticipation)
    .pipe(
      tap(action => console.log(`Received ${action.type}`)),
      map((action: fromStore.LoadParticipation) => action.payload),
      exhaustMap((participation: Participation) =>
        this.participationsService
          .getParticipation(participation)
          .pipe(
            tap(participation => console.log(participation)),
            map((participation: Participation) => new fromStore.LoadParticipationSuccess(participation)),
            catchError(err => of(new fromStore.LoadParticipationsFail(err)))
          )
      )
    );

  @Effect()
  createParticipation$: Observable<Action> = this.actions$
    .ofType(fromStore.ParticipationActionTypes.CreateParticipation)
    .pipe(
      tap(action => console.log(`Received ${action.type}`)),
      map((action: fromStore.CreateParticipation) => action.payload),
      exhaustMap((participation: Participation) =>
        this.participationsService.createParticipation(participation)
          .pipe(
            tap(participation => console.log(participation)),
            map((participation: Participation) => new fromStore.CreateParticipationSuccess(participation)),
            catchError(err => of(new fromStore.CreateParticipationFail(err)))
          )
      )
    );

  @Effect()
  updateParticipation$: Observable<Action> = this.actions$
    .ofType(fromStore.ParticipationActionTypes.UpdateParticipation)
    .pipe(
      tap(action => console.log(`Received ${action.type}`)),
      map((action: fromStore.UpdateParticipation) => action.payload),
      exhaustMap((participation: Participation) =>
        this.participationsService.updateParticipation(participation)
          .pipe(
            tap(participation => console.log(participation)),
            map((participation: Participation) => new fromStore.UpdateParticipationSuccess(participation)),
            catchError(err => of(new fromStore.UpdateParticipationFail(err)))
          )
      )
    );

  @Effect()
  deleteParticipation$: Observable<Action> = this.actions$
    .ofType(fromStore.ParticipationActionTypes.DeleteParticipation)
    .pipe(
      tap(action => console.log(`Received ${action.type}`)),
      map((action: fromStore.DeleteParticipation) => action.payload),
      exhaustMap((participation: Participation) =>
        this.participationsService.deleteParticipation(participation)
          .pipe(
            tap(participation => console.log(participation)),
            map((participation: Participation) => new fromStore.DeleteParticipationSuccess(participation)),
            catchError(err => of(new fromStore.DeleteParticipationFail(err)))
          )
      )
    );

  @Effect()
  loadOrgTree$: Observable<Action> = this.actions$
    .ofType(fromStore.ParticipationActionTypes.LoadOrgTree)
    .pipe(
      tap(action => console.log(`Received ${action.type}`)),
      map((action: fromStore.LoadOrgTree) => action.payload),
      exhaustMap((supervisor: any) =>
        this.participationsService
          .getOrgTree(supervisor)
          .pipe(
            tap(orgTree => console.log(orgTree)),
            map((orgTree: User[]) => new fromStore.LoadOrgTreeSuccess(orgTree)),
            catchError(err => of(new fromStore.LoadOrgTreeFail(err)))
          )
      )
    );

  @Effect()
  loadPurposes$: Observable<Action> = this.actions$
    .ofType(fromStore.ParticipationActionTypes.LoadPurposes)
    .pipe(
      tap(action => console.log(`Received ${action.type}`)),
      exhaustMap((action: any) =>
        this.participationsService
          .getPurposes()
          .pipe(
            tap(purposes => console.log(purposes)),
            map((purposes: Purpose[]) => new fromStore.LoadPurposesSuccess(purposes)),
            catchError(err => of(new fromStore.LoadPurposesFail(err)))
          )
      )
    );

  @Effect()
  loadRoles$: Observable<Action> = this.actions$
    .ofType(fromStore.ParticipationActionTypes.LoadRoles)
    .pipe(
      tap(action => console.log(`Received ${action.type}`)),
      exhaustMap((action: any) =>
        this.participationsService
          .getRoles()
          .pipe(
            tap(roles => console.log(roles)),
            map((roles: string[]) => new fromStore.LoadRolesSuccess(roles)),
            catchError(err => of(new fromStore.LoadRolesFail(err)))
          )
      )
    );

  @Effect()
  loadSupervisors$: Observable<Action> = this.actions$
    .ofType(fromStore.ParticipationActionTypes.LoadSupervisors)
    .pipe(
      tap(action => console.log(`Received ${action.type}`)),
      exhaustMap((action: any) =>
        this.participationsService
          .getSupervisors()
          .pipe(
            tap(supervisors => console.log(supervisors)),
            map((supervisors: User[]) => new fromStore.LoadSupervisorsSuccess(supervisors)),
            catchError(err => of(new fromStore.LoadSupervisorsFail(err)))
          )
      )
    );

    @Effect()
    loadLawContacts$: Observable<Action> = this.actions$
      .ofType(fromStore.ParticipationActionTypes.LoadLawContacts)
      .pipe(
        tap(action => console.log(`Received ${action.type}`)),
        exhaustMap((action: any) =>
          this.participationsService
            .getLawContacts()
            .pipe(
              tap(lawContacts => console.log(lawContacts)),
              map((lawContacts: User[]) => new fromStore.LoadLawContactsSuccess(lawContacts)),
              catchError(err => of(new fromStore.LoadLawContactsFail(err)))
            )
        )
      );
  
  @Effect()
  loadTaigs$: Observable<Action> = this.actions$
    .ofType(fromStore.ParticipationActionTypes.LoadTaigs)
    .pipe(
      tap(action => console.log(`Received ${action.type}`)),
      exhaustMap((action: any) =>
        this.participationsService
          .getTaigs()
          .pipe(
            tap(taigs => console.log(taigs)),
            map((taigs: Taig[]) => new fromStore.LoadTaigsSuccess(taigs)),
            catchError(err => of(new fromStore.LoadTaigsFail(err)))
          )
      )
    );

  @Effect()
  handleParticipationSuccess$ = this.actions$
    .ofType(
      fromStore.ParticipationActionTypes.CreateParticipationSuccess,
      fromStore.ParticipationActionTypes.UpdateParticipationSuccess
    )
    .pipe(
      tap(action => console.log(`Received ${action.type}`)),
      map(action => {
        return new fromRoot.Go({
          path: ['/participations']
        });
      })
    );

  @Effect()
  gotoParticipation$ = this.actions$
    .ofType(fromStore.ParticipationActionTypes.gotoParticipation)
    .pipe(
      tap(action => console.log(`Received ${action.type}`)),
      map((action: fromStore.GotoParticipation) => action.payload),
      map(id => {
        return new fromRoot.Go({
          path: ['/participations', id]
        });
      })
    );

  constructor(
    private actions$: Actions,
    private participationsService: fromServices.ParticipationsService
  ) { }

}