import { Injectable } from '@angular/core';
import { Action } from '@ngrx/store';
import { Actions, Effect } from '@ngrx/effects';
import { Observable } from 'rxjs';
import { of } from 'rxjs';
import { map, tap, switchMap, concatMap, exhaustMap, mergeMap, delay, catchError, pluck } from 'rxjs/operators';

import * as fromRoot from '../../../../app/store';
import * as fromServices from '../../services';
import * as fromParticipations from '../actions/participations.actions';
import { Participation } from '../../models/participation';
@Injectable()
export class ParticipationsEffects {

  @Effect()
  loadParticipations$: Observable<Action> = this.actions$
    .ofType(fromParticipations.ParticipationActionTypes.LoadParticipations)
    .pipe(
      tap(action => console.log(`Received ${action.type}`)),
      exhaustMap(action =>
        this.participationsService
          .getParticipations()
          .pipe(
            tap(action => console.log(action)),
            map((participations: Participation[]) => new fromParticipations.LoadParticipationsSuccess(participations)),
            catchError(err => of(new fromParticipations.LoadParticipationsFail(err)))
          )
      )
    );

  @Effect()
  loadParticipation$: Observable<Action> = this.actions$
    .ofType(fromParticipations.ParticipationActionTypes.LoadParticipation)
    .pipe(
      tap(action => console.log(`Received ${action.type}`)),
      map((action: fromParticipations.LoadParticipation) => action.payload),
      exhaustMap((participation: Participation) =>
        this.participationsService
          .getParticipation(participation)
          .pipe(
            tap(action => console.log(action)),
            map((participation: Participation) => new fromParticipations.LoadParticipationSuccess(participation)),
            catchError(err => of(new fromParticipations.LoadParticipationsFail(err)))
          )
      )
    );

  @Effect()
  createParticipation$: Observable<Action> = this.actions$
    .ofType(fromParticipations.ParticipationActionTypes.CreateParticipation)
    .pipe(
      tap(action => console.log(`Received ${action.type}`)),
      map((action: fromParticipations.CreateParticipation) => action.payload),
      exhaustMap((participation: Participation) =>
        this.participationsService.createParticipation(participation)
          .pipe(
            tap(action => console.log(action)),
            map((participation: Participation) => new fromParticipations.CreateParticipationSuccess(participation)),
            catchError(err => of(new fromParticipations.CreateParticipationFail(err)))
          )
      )
    );

  @Effect()
  updateParticipation$: Observable<Action> = this.actions$
    .ofType(fromParticipations.ParticipationActionTypes.UpdateParticipation)
    .pipe(
      tap(action => console.log(`Received ${action.type}`)),
      map((action: fromParticipations.UpdateParticipation) => action.payload),
      exhaustMap((participation: Participation) =>
        this.participationsService.updateParticipation(participation)
          .pipe(
            tap(action => console.log(action)),
            map((participation: Participation) => new fromParticipations.UpdateParticipationSuccess(participation)),
            catchError(err => of(new fromParticipations.UpdateParticipationFail(err)))
          )
      )
    );

  @Effect()
  deleteParticipation$: Observable<Action> = this.actions$
    .ofType(fromParticipations.ParticipationActionTypes.DeleteParticipation)
    .pipe(
      tap(action => console.log(`Received ${action.type}`)),
      map((action: fromParticipations.DeleteParticipation) => action.payload),
      exhaustMap((participation: Participation) =>
        this.participationsService.deleteParticipation(participation)
          .pipe(
            tap(action => console.log(action)),
            map((participation: Participation) => new fromParticipations.DeleteParticipationSuccess(participation)),
            catchError(err => of(new fromParticipations.DeleteParticipationFail(err)))
          )
      )
    );

    @Effect()
    handleParticipationSuccess$ = this.actions$
      .ofType(
        fromParticipations.ParticipationActionTypes.CreateParticipationSuccess,
        fromParticipations.ParticipationActionTypes.UpdateParticipationSuccess
      )
      .pipe(
        tap(action => console.log(`Received ${action.type}`)),
        map(action => {
          return new fromRoot.Go({
            path: ['/participations']
          });
        })
      );

      @Effect()
      gotoParticipation$ = this.actions$
        .ofType(fromParticipations.ParticipationActionTypes.gotoParticipation)
        .pipe(
          tap(action => console.log(`Received ${action.type}`)),
          map((action: fromParticipations.GotoParticipation) => action.payload),
          map(id => {
            return new fromRoot.Go({
              path: ['/participations', id ]
            });
          })
        );  

  constructor(
    private actions$: Actions,
    private participationsService: fromServices.ParticipationsService
  ) { }

}