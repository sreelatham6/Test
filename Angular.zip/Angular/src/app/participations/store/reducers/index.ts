// import { ActionReducerMap, createFeatureSelector } from '@ngrx/store';
// import * as fromParticipations from './participations.reducer';

// export interface ParticipationsState {
//   participations: fromParticipations.ParticipationState;
// }

// export const reducers: ActionReducerMap<ParticipationsState> = {
//   participations: fromParticipations.reducer
// };

// export const getParticipationsState = createFeatureSelector<ParticipationsState>('participations');