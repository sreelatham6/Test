import { createFeatureSelector, createSelector } from '@ngrx/store';
import { ParticipationsActions, ParticipationActionTypes } from '../actions/participations.actions';
import { Participation, OrgTree, Taig, User, CommitteeCard, RoleCard } from '../../models';
import * as fromApp from '../../../../app/store/reducers';

export interface ParticipationState {
  participations: Participation[];
  orgTree: OrgTree[];
  roles: string[],
  roleCards: RoleCard[];
  committeeCards: CommitteeCard[],
  purposes: string[];
  supervisors: string[];
  taigs: Taig[];
  user: User;
  supervisor: string;
  error: string;
  loading: boolean;
  loaded: boolean;
}

const initialState: ParticipationState = {
  participations: [],
  orgTree: [],
  roles: [],
  roleCards: [],
  committeeCards: [],
  purposes: [],
  supervisors: [],
  taigs: [],
  user: null,
  supervisor: null,
  error: null,
  loading: false,
  loaded: false
};

export const getParticipationState = createFeatureSelector<ParticipationState>('participations');

export const getParticipation = createSelector(
  getParticipationState,
  fromApp.getRouterState,
  (state, router) => {
    if (parseInt(router.state.params.id, 10) === 0) {
      return {
        id: 0,
        ParticipationName: '',
        description: ''
      };
    } else {
      return router.state.params.id ? state.participations.find(c => c.id === parseInt(router.state.params.id, 10)) : null;
    }
  }
);

export const getParticipations = createSelector(
  getParticipationState,
  state => state.participations
);

export const getOrgTree = createSelector(
  getParticipationState,
  state => state.orgTree
);

export const getPurposes = createSelector(
  getParticipationState,
  state => state.purposes
);

export const getRoles = createSelector(
  getParticipationState,
  state => state.roles
);

export const getSupervisors = createSelector(
  getParticipationState,
  state => state.supervisors
);

export const getTaigs = createSelector(
  getParticipationState,
  state => state.taigs
);

export const getRoleCards = createSelector(
  getParticipationState,
  state => state.roleCards
);

export const getCommitteeCards = createSelector(
  getParticipationState,
  state => state.committeeCards
);

export const getUser = createSelector(
  getParticipationState,
  state => state.user
);

export const getSupervisor = createSelector(
  getParticipationState,
  state => state.supervisor
);

export const getError = createSelector(
  getParticipationState,
  state => state.error
);

export const getParticipationLoading = createSelector(
  getParticipationState,
  state => state.loading
);

export const getParticipationLoaded = createSelector(
  getParticipationState,
  state => state.loaded
);

export const getParticipationsCount = createSelector(
  getParticipationState,
  state => state.participations.length
);

export const getLoads = (state: ParticipationState) => state.participations;
export const getLoading = (state: ParticipationState) => state.loading;
export const getLoaded = (state: ParticipationState) => state.loaded;

export function reducer(state = initialState, action: ParticipationsActions): ParticipationState {

  switch (action.type) {
    case ParticipationActionTypes.SetUser:
      return {
        ...state,
        user: action.payload
      };

    case ParticipationActionTypes.SetSupervisor:
      return {
        ...state,
        supervisor: action.payload
      };

    case ParticipationActionTypes.LoadParticipationsSuccess: {
      return {
        ...state,
        participations: [...action.payload],
        loading: false,
        loaded: true,
        error: ''
      };
    }

    case ParticipationActionTypes.LoadParticipationsFail: {
      return {
        ...state,
        participations: [],
        loading: false,
        loaded: false,
        error: action.payload
      };
    }

    case ParticipationActionTypes.LoadOrgTreeSuccess: {
      return {
        ...state,
        orgTree: [...action.payload],
        error: ''
      };
    }

    case ParticipationActionTypes.LoadOrgTreeFail: {
      return {
        ...state,
        orgTree: [],
        error: action.payload
      };
    }

    case ParticipationActionTypes.LoadPurposesSuccess: {
      return {
        ...state,
        purposes: [...action.payload],
        error: ''
      };
    }

    case ParticipationActionTypes.LoadPurposesFail: {
      return {
        ...state,
        purposes: [],
        error: action.payload
      };
    }

    case ParticipationActionTypes.LoadRolesSuccess: {
      return {
        ...state,
        roles: [...action.payload],
        error: ''
      };
    }

    case ParticipationActionTypes.LoadRolesFail: {
      return {
        ...state,
        roles: [],
        error: action.payload
      };
    }

    case ParticipationActionTypes.LoadSupervisorsSuccess: {
      return {
        ...state,
        supervisors: [...action.payload],
        error: ''
      };
    }

    case ParticipationActionTypes.LoadSupervisorsFail: {
      return {
        ...state,
        supervisors: [],
        error: action.payload
      };
    }

    case ParticipationActionTypes.LoadTaigsSuccess: {
      return {
        ...state,
        taigs: [...action.payload],
        error: ''
      };
    }

    case ParticipationActionTypes.LoadTaigsFail: {
      return {
        ...state,
        taigs: [],
        error: action.payload
      };
    }

    case ParticipationActionTypes.UpdateParticipationSuccess: {
      const updatedParticipations = state.participations.map(
        item => action.payload.id === item.id ? action.payload : item);
      return {
        ...state,
        participations: updatedParticipations,
        loading: false,
        loaded: true,
        error: ''
      };
    }

    case ParticipationActionTypes.UpdateParticipationFail: {
      return {
        ...state,
        loading: false,
        loaded: false,
        error: action.payload
      };
    }

    case ParticipationActionTypes.CreateParticipationSuccess: {
      return {
        ...state,
        participations: [...state.participations, action.payload],
        loading: false,
        loaded: true,
        error: ''
      };
    }

    case ParticipationActionTypes.CreateParticipationFail: {
      return {
        ...state,
        loading: false,
        loaded: false,
        error: action.payload
      };
    }

    case ParticipationActionTypes.DeleteParticipationSuccess: {
      return {
        ...state,
        participations: state.participations.filter(participation => participation.id !== action.payload.id),
        loading: false,
        loaded: true,
        error: ''
      };
    }

    case ParticipationActionTypes.DeleteParticipationFail: {
      return {
        ...state,
        loading: false,
        loaded: false,
        error: action.payload
      };
    }

    default:
      return state;
  }
}
