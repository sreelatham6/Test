import { createFeatureSelector, createSelector } from '@ngrx/store';
import { ParticipationsActions, ParticipationActionTypes } from '../actions/participations.actions';
import { Card, Participation, Purpose, Taig, User } from '../../models';
import * as fromApp from '../../../../app/store/reducers';

export interface ParticipationState {
  participations: Participation[];
  orgTree: User[];
  roles: string[],
  roleCards: Card[];
  committeeCards: Card[],
  purposes: Purpose[];
  supervisors: User[];
  lawContacts: User[];
  taigs: Taig[];
  user: User;
  supervisor: User;
  error: string;
  loading: boolean;
  loaded: boolean;
}

const initialState: ParticipationState = {
  participations: [] = [],
  orgTree: [] = [],
  roles: [] = [],
  roleCards: [] = [],
  committeeCards: [] = [],
  purposes: [] = [],
  supervisors: [] = [],
  lawContacts: [] = [],
  taigs: [] = [],
  user: { 'lanId': '', 'domain': '', 'name': '', 'title': '', 'id': '0' },
  supervisor:  { 'lanId': '', 'domain': '', 'name': '', 'title': '', 'id': '0' },
  error: '',
  loading: false,
  loaded: false
};

export const getParticipationState = createFeatureSelector<ParticipationState>('participations');

export const getLoads = (state: ParticipationState) => state.participations;
export const getLoading = (state: ParticipationState) => state.loading;
export const getLoaded = (state: ParticipationState) => state.loaded;

export function reducer(state = initialState, action: ParticipationsActions): ParticipationState {

  switch (action.type) {
    case ParticipationActionTypes.SetUser:
      return {
        ...state,
        user: action.payload
      };

    case ParticipationActionTypes.SetSupervisor:
      return {
        ...state,
        supervisor: action.payload
      };

    case ParticipationActionTypes.LoadParticipationsSuccess: {
      return {
        ...state,
        participations: [...action.payload],
        loading: false,
        loaded: true,
        error: ''
      };
    }

    case ParticipationActionTypes.LoadParticipationsFail: {
      return {
        ...state,
        participations: [],
        loading: false,
        loaded: false,
        error: action.payload
      };
    }

    case ParticipationActionTypes.LoadOrgTreeSuccess: {
      return {
        ...state,
        orgTree: [...action.payload],
        error: ''
      };
    }

    case ParticipationActionTypes.LoadOrgTreeFail: {
      return {
        ...state,
        orgTree: [],
        error: action.payload
      };
    }

    case ParticipationActionTypes.LoadPurposesSuccess: {
      return {
        ...state,
        purposes: [...action.payload],
        error: ''
      };
    }

    case ParticipationActionTypes.LoadPurposesFail: {
      return {
        ...state,
        purposes: [],
        error: action.payload
      };
    }

    case ParticipationActionTypes.LoadLawContactsSuccess: {
      return {
        ...state,
        lawContacts: [...action.payload],
        error: ''
      };
    }

    case ParticipationActionTypes.LoadLawContactsFail: {
      return {
        ...state,
        lawContacts: [],
        error: action.payload
      };
    }

    case ParticipationActionTypes.LoadRolesSuccess: {
      return {
        ...state,
        roles: [...action.payload],
        error: ''
      };
    }

    case ParticipationActionTypes.LoadRolesFail: {
      return {
        ...state,
        roles: [],
        error: action.payload
      };
    }

    case ParticipationActionTypes.LoadSupervisorsSuccess: {
      return {
        ...state,
        supervisors: [...action.payload],
        error: ''
      };
    }

    case ParticipationActionTypes.LoadSupervisorsFail: {
      return {
        ...state,
        supervisors: [],
        error: action.payload
      };
    }

    case ParticipationActionTypes.LoadTaigsSuccess: {
      return {
        ...state,
        taigs: [...action.payload],
        error: ''
      };
    }

    case ParticipationActionTypes.LoadTaigsFail: {
      return {
        ...state,
        taigs: [],
        error: action.payload
      };
    }

    case ParticipationActionTypes.UpdateParticipationSuccess: {
      const updatedParticipations = state.participations.map(
        item => action.payload.id === item.id ? action.payload : item);
      return {
        ...state,
        participations: updatedParticipations,
        loading: false,
        loaded: true,
        error: ''
      };
    }

    case ParticipationActionTypes.UpdateParticipationFail: {
      return {
        ...state,
        loading: false,
        loaded: false,
        error: action.payload
      };
    }

    case ParticipationActionTypes.CreateParticipationSuccess: {
      return {
        ...state,
        participations: [...state.participations, action.payload],
        loading: false,
        loaded: true,
        error: ''
      };
    }

    case ParticipationActionTypes.CreateParticipationFail: {
      return {
        ...state,
        loading: false,
        loaded: false,
        error: action.payload
      };
    }

    case ParticipationActionTypes.DeleteParticipationSuccess: {
      return {
        ...state,
        participations: state.participations.filter(participation => participation.id !== action.payload.id),
        loading: false,
        loaded: true,
        error: ''
      };
    }

    case ParticipationActionTypes.DeleteParticipationFail: {
      return {
        ...state,
        loading: false,
        loaded: false,
        error: action.payload
      };
    }

    default:
      return state;
  }
}
