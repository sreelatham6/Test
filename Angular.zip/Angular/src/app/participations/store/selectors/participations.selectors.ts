import { createSelector } from '@ngrx/store';
import * as fromRoot from '../../../../app/store';
// import * as fromIndex from '../reducers';
import * as fromR from '../reducers/participations.reducer';
import * as fromApp from '../../../store';
import { Participation } from '../../models/participation';
import { Observable } from 'rxjs';

export const getParticipation = createSelector(
    fromR.getParticipationState,
    fromApp.getRouterState,
    (state, router) => {
      if (parseInt(router.state.params.id, 10) === 0) {
        return {
          id: 0,
          ParticipationName: '',
          description: ''
        };
      } else {
        return router.state.params.id ? state.participations.find(c => c.id === parseInt(router.state.params.id, 10)) : null;
      }
    }
  );
  
  export const getParticipations = createSelector(
    fromR.getParticipationState,
    state => state.participations
  );
  
  export const getOrgTree = createSelector(
    fromR.getParticipationState,
    state => state.orgTree
  );
  
  export const getPurposes = createSelector(
    fromR.getParticipationState,
    state => state.purposes
  );
  
  export const getRoles = createSelector(
    fromR.getParticipationState,
    state => state.roles
  );
  
  export const getSupervisors = createSelector(
    fromR.getParticipationState,
    state => state.supervisors
  );
  
  export const getLawContacts = createSelector(
    fromR.getParticipationState,
    state => state.lawContacts
  );
  
  export const getTaigs = createSelector(
    fromR.getParticipationState,
    state => state.taigs
  );
  
  export const getRoleCards = createSelector(
    fromR.getParticipationState,
    state => state.roleCards
  );
  
  export const getCommitteeCards = createSelector(
    fromR.getParticipationState,
    state => state.committeeCards
  );
  
  export const getUser = createSelector(
    fromR.getParticipationState,
    state => state.user
  );
  
  export const getSupervisor = createSelector(
    fromR.getParticipationState,
    state => state.supervisor
  );
  
  export const getError = createSelector(
    fromR.getParticipationState,
    state => state.error
  );
  
  export const getParticipationLoading = createSelector(
    fromR.getParticipationState,
    state => state.loading
  );
  
  export const getParticipationLoaded = createSelector(
    fromR.getParticipationState,
    state => state.loaded
  );
  
  export const getParticipationsCount = createSelector(
    fromR.getParticipationState,
    state => state.participations.length
  );
  
