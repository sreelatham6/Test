import { createSelector } from '@ngrx/store';
import * as fromRoot from '../../../../app/store';
// import * as fromIndex from '../reducers';
import * as fromR from '../reducers/participations.reducer';
import { Participation } from '../../models/participation';
import { Observable } from 'rxjs';


// export const getParticipationState = createSelector(
//     fromR.getParticipationState,
//     (state: fromR.ParticipationState) => state.participations
// );

// export const getCurrentParticipationId = createSelector(
//   getParticipationState,
//   state => state.currentParticipationId
// );

// export const getParticipation = createSelector(
//   getParticipationState,
//   fromRoot.getRouterState,
//   (state, router): Participation => {
//     return router.state && state.find(c => c.id === router.state.params.id);
//   }
// );

// export const getCurrentParticipation = createSelector(
//   getParticipationState,
//   getCurrentParticipationId,
//   (state, currentParticipationId) => {
//     if (currentParticipationId === 0) {
//       return {
//         id: 0,
//         ParticipationName: '',
//         ParticipationCode: 'New',
//         description: '',
//         starRating: 0
//       };
//     } else {
//       return currentParticipationId ? state.participations.find(c => c.id === currentParticipationId) : null;
//     }
//   }
// );

// export const getError = createSelector(
//   getParticipationState,
//   state => state.error
// );

// export const getParticipationLoading = createSelector(
//   getParticipationState,
//   state => state.loading
// );

// export const getParticipationLoaded = createSelector(
//   getParticipationState,
//   state => state.loaded
// );
