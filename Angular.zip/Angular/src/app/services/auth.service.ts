import { Injectable } from '@angular/core';
import { HttpClient, HttpParams, HttpHeaders, HttpHeaderResponse, HttpRequest, HttpErrorResponse } from '@angular/common/http';
import { ConfigService } from './config.service';
import { OrgTree, User } from '../participations/models';

@Injectable()
export class AuthService {
	private _user: User = {
		lanId: 'asuare6',
		domain: 'na',
		name: 'Alex Suarez',
		title: 'Web Developer',
		code: 'xx'
	};
	
	private _orgTree: OrgTree[];

	public get user(): User {
		return this._user;
	}

	constructor(private http: HttpClient, private cfg: ConfigService) { }

	public getUser() {
		return this.http.get<User>(`${this.cfg.api}/user`).subscribe(
			response => this._user = response,
			error => console.log(error)
		);
	}

}