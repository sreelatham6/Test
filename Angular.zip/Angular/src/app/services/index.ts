import { AuthService } from './auth.service';
import { ConfigService } from './config.service';

export const services: any[] = [AuthService, ConfigService];

export * from './auth.service';
export * from './config.service';
