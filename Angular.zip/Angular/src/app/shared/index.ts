import { AuthService } from './services/auth.service';
import { ConfigService } from './services/config.service';
import { TaigPipe } from './pipes/taig.pipe';

export const services: any[] = [AuthService, ConfigService];
export const pipes: any[] = [TaigPipe];

export * from './services/auth.service';
export * from './services/config.service';
export * from './pipes/taig.pipe';