import { TaigPipe } from './taig.pipe';

export const pipes: any[] = [TaigPipe];

export * from './taig.pipe';