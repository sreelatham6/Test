import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'taig'
})
export class TaigPipe implements PipeTransform {

  transform(value: string[], nameBy: string): string[] {
    nameBy = nameBy ? nameBy.toLocaleLowerCase() : null;
    return nameBy ? value.filter((s: string) =>
        s.toLocaleLowerCase().indexOf(nameBy) !== -1) : value;
  }

}
