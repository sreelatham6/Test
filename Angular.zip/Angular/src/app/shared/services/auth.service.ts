import { Injectable } from '@angular/core';
import { HttpClient, HttpParams, HttpHeaders, HttpHeaderResponse, HttpRequest, HttpErrorResponse } from '@angular/common/http';
import { ConfigService } from './config.service';
import { OrgTree, User } from '../../participations/models';

@Injectable()
export class AuthService {
	private _user: User;
	private _orgTree: OrgTree[];

	public get lanId(): string {
		return this._user.LanId;
	}

	public get userDomain(): string {
		return this._user.UserDomain;
	}

	public get name(): string {
		//return this._user.Name;
		return "Sree";
	}

	public get title(): string {
		//return this._user.Title;
		return "Developer";
	}

	constructor(private http: HttpClient, private cfg: ConfigService) { }

	public getUser() {
		return this.http.get<User>(`${this.cfg.api}/user`).subscribe(
			response => this._user = response,
			error => console.log(error)
		);
	}

}