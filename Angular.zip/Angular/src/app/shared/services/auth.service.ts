import { Injectable } from '@angular/core';
import { HttpClient, HttpParams, HttpHeaders, HttpHeaderResponse, HttpRequest, HttpErrorResponse } from '@angular/common/http';
import { ConfigService } from './config.service';


export interface User {
	LanId: string;
	EmailID: string;
};
export interface OrgTree {
	LanId: string;
	EmailID: string;
};

@Injectable()
export class AuthService {
	private _user: User;
	private _orgTree: OrgTree[];

	public get lanId(): string {
		return this._user.LanId;
	}

	public get orgTree(): OrgTree[] {
		return this._orgTree;
	}

	constructor(private http: HttpClient, private cfg: ConfigService) { }

	public getUser() {
		return this.http.get<User>(`${this.cfg.api}/user`).subscribe(
			response => this._user = response,
			error => console.log(error)
		);
	}

	public getEmployeeOrgTree(user: string) {
		let headers = new HttpHeaders({ 'Content-Type': 'application/json' });
		let params = new HttpParams().set('LanId', this._user.LanId);
		return this.http.get<OrgTree[]>(`${this.cfg.api}/orgtree`, { headers: headers, params: params }).subscribe(
			response => this._orgTree = response,
			error => console.log(error)
		);
	}
}