import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Response } from '@angular/http';
import { Observable, Subscription } from 'rxjs';
import { catchError, map } from 'rxjs/operators';

export interface Configuration {
	Domain: string;
	Api: string;
	EmailId: string;
};

@Injectable()
export class ConfigService {
  // Set defaults
  _domain = 'http://localhost:4200';
  _api = 'http://localhost:4200/api/';
  _email = 'support@xom.com';

  constructor(private http: HttpClient) {}

  get domain() {
    return this._domain;
  }

  get api() {
    return this._api;
  }

  get email() {
    return this._email;
  }

  loadConfig() {
    this.http.get<Configuration>('/config.json').subscribe(data => {
      this._domain = data.Domain;
      this._api = data.Api;
      this._email = data.EmailId;
      console.log(data);
    });
  }}
