import { NgModule } from '@angular/core';
import { pipes } from './pipes';

@NgModule({
  declarations: [
    ...pipes
  ],
  exports: [
    ...pipes
  ],
  providers: []
})

export class SharedModule {}
