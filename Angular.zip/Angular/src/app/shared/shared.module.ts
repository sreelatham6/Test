import { NgModule } from '@angular/core';

@NgModule({
  declarations: [
  ],
  exports: [
  ],
  providers: []
})

export class SharedModule {}
