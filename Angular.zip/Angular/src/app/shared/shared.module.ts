import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { services, pipes } from './';

@NgModule({
  declarations: [
    ...pipes
  ],
  exports: [
    CommonModule,
    HttpClientModule
  ],
  providers: [...services]
})

export class SharedModule {}