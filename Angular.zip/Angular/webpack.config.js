const path = require('path');
const webpack = require('webpack');
const typescript = require('typescript');
const { AngularCompilerPlugin } = require('@ngtools/webpack');
const UglifyJsPlugin = require('uglifyjs-webpack-plugin');
const CleanWebpackPlugin = require('clean-webpack-plugin');

const rules = [{
  test: /\.html$/,
  loader: 'html-loader',
  options: {
    minimize: true,
    removeComments: true,
    collapseWhitespace: true,
    removeAttributeQuotes: false,
    keepClosingSlash: true,
    caseSensitive: true,
    conservativeCollapse: true,
  }
},
{
  test: /\.js$/,
  exclude: /node_modules/,
  loaders: ['babel-loader']
},
{
  test: /\.scss$/,
  loaders: ['raw-loader', 'css-loader', 'sass-loader']
},
{
  test: /\.css$/,
  loaders: ['raw-loader', 'css-loader']
},
{
  test: /\.(jpe?g|png|gif|svg|ico)$/i,
  loader: 'file-loader'
},
];

const plugins = [
  new webpack.DefinePlugin({
    'process.env': {
      NODE_ENV: JSON.stringify(process.env.NODE_ENV),
    },
  })
];

if (process.env.NODE_ENV === 'production') {
  rules.push({
    test: /\.ts$/,
    loaders: ['@ngtools/webpack'],
  });
  plugins.push(
    new CleanWebpackPlugin(['dist']),
    new AngularCompilerPlugin({
      tsConfigPath: './tsconfig.json',
      entryModule: 'src/app/app.module#AppModule',
      sourceMap: true
    }),
    new webpack.LoaderOptionsPlugin({
      minimize: true,
      debug: false,
    }),
    new UglifyJsPlugin({
      test: /\.js($|\?)/i,
      parallel: 4,
      sourceMap: true,
      uglifyOptions: {
        ecma: 8,
        warnings: false,
        output: {
          comments: false,
          beautify: false,
          ecma: 6,
        },
        toplevel: false,
        nameCache: null,
        ie8: false,
        keep_classnames: undefined,
        keep_fnames: false,
        safari10: false,
      }
    })
  );
} else {
  rules.push({
    test: /\.ts$/,
    loaders: [
      'awesome-typescript-loader',
      'angular-router-loader',
      'angular2-template-loader',
    ],
  });
  plugins.push(
    new webpack.NamedModulesPlugin(),
    new webpack.ContextReplacementPlugin(
      /angular(\\|\/)core(\\|\/)@angular/,
      path.resolve(__dirname, './notfound')
    )
  );
}

module.exports = {
  cache: true,
  context: path.resolve(__dirname),
  devServer: {
    contentBase: [path.join(__dirname, "src"), path.resolve(__dirname)],
    historyApiFallback: true,
    stats: {
      chunks: false,
      chunkModules: false,
      chunkOrigins: false,
      errors: true,
      errorDetails: false,
      hash: false,
      modules: false,
      timings: false,
      warnings: false
    },
    publicPath: '/dist/',
    port: 4200
  },
  devtool: 'sourcemap',
  entry: {
    app: ['zone.js/dist/zone', './src/main.ts']
  },
  optimization: {
    minimize: false,
    runtimeChunk: false,
    splitChunks: {
      chunks: "async",
      minSize: 30000,
      minChunks: 1,
      maxInitialRequests: 3,
      maxAsyncRequests: 5,
      name: true,
      cacheGroups: {
        commons: {
          minChunks: 2,
          priority: -20,
          chunks: "initial",
          reuseExistingChunk: true
        },
        vendor: {
          test: /[\\/]node_modules[\\/]/,
          name: 'vendor',
          chunks: "all",
          priority: -10,
          enforce: true
        }
      }
    }
  },
  output: {
    filename: '[name].js',
    chunkFilename: '[name]-chunk.js',
    path: path.resolve(__dirname, 'dist'),
    publicPath: '../dist/'
  },
  node: {
    console: false,
    global: true,
    process: true,
    Buffer: false,
    setImmediate: false,
  },
  module: {
    rules,
  },
  resolve: {
    extensions: ['.ts', '.js'],
    modules: ['src', 'node_modules'],
  },
  plugins,
};
