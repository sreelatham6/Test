﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using TAIGCommon;
using TAIGCommon.Model;
using TAIGCommon.Model.DTO;

namespace TAIGAPI.App_Start
{
    public class MappingProfile: Profile
    {
        public MappingProfile()
        {
            this.CreateMap<TAIG, TAIGDTO>();
            this.CreateMap<TAIGDTO, TAIG>();
            this.CreateMap<ParticipationDTO, Participation>();
            this.CreateMap<Participation, ParticipationDTO>();
            this.CreateMap<UserDTO, UserDTO>();
            this.CreateMap<UserDTO, UserDTO>();
        }
    }
}