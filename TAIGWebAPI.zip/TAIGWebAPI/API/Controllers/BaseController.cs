﻿using NLog;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Results;
using TAIGCommon.DAL;

namespace TAIGAPI.Controllers
{
    public class BaseController : ApiController
    {
        private NLog.Logger _logger;

        protected Logger logger
        {
            get
            {
                if (_logger == null)
                    _logger = LogManager.GetCurrentClassLogger();

                return _logger;
            }

            set
            {
                _logger = value;
            }
        }

        public BaseController()
        {
        }

        public ExceptionResult GetInternalServerError(Exception ex)
        {
            var stackTrace = " - STACKTRACE: " + ex.StackTrace;
            var sb = new StringBuilder("ERROR: " + ex.Message);
            while(ex.InnerException != null)
            {
                ex = ex.InnerException;
                sb.Append(" - " + ex.Message);
            } 
            sb.Append(stackTrace);
            string str = sb.ToString();
            logger.Log(LogLevel.Error, str);
            return InternalServerError(new Exception(str));

        }
        public string RequestortId
        {
            get
            {
                GRDBDAL grdbDAL;
                try
                {
                    grdbDAL = new GRDBDAL();
                    var lanId = this.RequestContext.Principal.Identity.Name;
                    return grdbDAL.GetUserByLandId(lanId).Result.UserGUID;
                }
                catch (Exception ex)
                {
                    InternalServerError(ex);
                    return string.Empty;
                }
            }
        }
    }
}
