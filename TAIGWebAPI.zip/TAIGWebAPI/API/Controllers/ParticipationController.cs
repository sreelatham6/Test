﻿using AutoMapper;
using NLog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using TAIGAPI.App_Start;
using TAIGCommon;
using TAIGCommon.BR;
using TAIGCommon.DAL;
using TAIGCommon.Model.DTO;

namespace TAIGAPI.Controllers
{
    public class ParticipationController : BaseController
    {
    
        public ParticipationController()
        {            
            //Mapper.Initialize(c => c.AddProfile<MappingProfile>());
        }

        [HttpGet]
        [Route("api/Participations/{userGUID}")]
        public async Task<IHttpActionResult> GetParticipations(string userGUID)
        {
            try
            {
                ParticipationBR participationBR = new ParticipationBR();
                var participations = await participationBR.GetParticipations(userGUID);
                return Ok(participations);
            }
            catch (Exception ex)
            {
                return GetInternalServerError(ex);
            }
        }

        [HttpGet]
        [Route("api/MyParticipations")]
        public async Task<IHttpActionResult> MyParticipations()
        {
            try
            {
                ParticipationBR participationBR = new ParticipationBR();
                var participations = await participationBR.GetMyParticipations();
                return Ok(participations);
            }
            catch (Exception ex)
            {
                return GetInternalServerError(ex);
            }
        }


        //[HttpPost]
        //[Route("api/Participation")]
        //public async Task<IHttpActionResult> Post([FromBody]ParticipationDTO participationDTO)
        //{
        //    try
        //    {
        //        ParticipationBR participationBR = new ParticipationBR();
        //        var response= await participationBR.RequestNewParticipationAsync(participationDTO);
        //        return Ok(response);
        //    }
        //    catch (Exception ex)
        //    {
        //        return GetInternalServerError(ex);
        //    }
        //}

        [HttpPost]
        [Route("api/Participation/Transfer")]
        public async Task<IHttpActionResult> RequestTransferParticipation([FromBody] ParticipationTransferDTO participationTransfer)
        {
            try
            {
                ParticipationBR participationBR = new ParticipationBR();
                var participationResponse = await participationBR.RequestTransferParticipation(participationTransfer);
                ///return Ok(Mapper.Map<Participation, ParticipationDTO>(participationResponse));
                return Ok(true);
            }
            catch (Exception ex)
            {
                return GetInternalServerError(ex);
            }

        }

        // PUT: api/Participation/5
        [HttpPut]
        [Route("api/participations/{id}")]
        public async Task<IHttpActionResult> Put(int id, [FromBody]ParticipationDTO participationDTO)
        {
            try
            {
                ParticipationBR participationBR = new ParticipationBR();
                var response = await participationBR.UpdateParticipationAsync(id, participationDTO);
                return Ok(response);

            }
            catch (Exception ex)
            {
                return GetInternalServerError(ex);
            }
        }

        [HttpPost]
        [Route("api/CancelParticipation/{id}")]
        public async Task<IHttpActionResult> CancelParticipation(int id)
        {
            try
            {
                ParticipationBR participationBR = new ParticipationBR();
                var response = await participationBR.CancelParticipation(id);
                return Ok(response);
            }
            catch (Exception ex)
            {
                return GetInternalServerError(ex);
            }
        }
        [HttpPost]
        [Route("api/RemoveParticipation/{id}")]
        public async Task<IHttpActionResult> RemoveParticipation(int id)
        {
            try
            {
                ParticipationBR participationBR = new ParticipationBR();
                var response = await participationBR.RemoveParticipation(id);
                return Ok(response);
            }
            catch (Exception ex)
            {
                return GetInternalServerError(ex);
            }
        }
    }
}
