﻿using AutoMapper;
using NLog;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Web.Http;
using TAIGCommon;
using TAIGCommon.BR;
using TAIGCommon.DAL;
using TAIGCommon.Model;
using TAIGCommon.Model.DTO;

namespace TAIGAPI.Controllers
{
    public class TAIGController : BaseController
    {

        [HttpGet]
        [Route("api/Taig/{descriptionPattern}")]
        public async Task<IHttpActionResult> GetTaig(string descriptionPattern)
        {
            try
            {
                TAIGBR taigBR = new TAIGBR();
                var response = await taigBR.GetActiveTAIGsByPatternName(descriptionPattern);
                return Ok(response);
            }
            catch (Exception ex)
            {
                return GetInternalServerError(ex);
            }
        }
        [HttpGet]
        [Route("api/Taigs")]
        public async Task<IHttpActionResult> GetTaigs()
        {
            try
            {
                TAIGBR taigBR = new TAIGBR();
                var response = await taigBR.GetTaigs();
                return Ok(response);
            }
            catch (Exception ex)
            {
                return GetInternalServerError(ex);
            }
        }

        [HttpGet]
        [Route("api/Taig/{id}")]
        public async Task<IHttpActionResult> GetTaig(int id)
        {
            try
            {
                TAIGBR taigBR = new TAIGBR();
                var response = await taigBR.GetTAIGById(id);
                return Ok(response);
            }
            catch (Exception ex)
            {
                return GetInternalServerError(ex);
            }
        }
      
        [HttpPost]
        [Route("api/Taig")]
        public async Task<IHttpActionResult> Post(TAIGDTO TaigDTO)
        {
            try
            {
                var response = Mapper.Map<TAIGDTO, TAIG>(TaigDTO);
                TAIGBR taigBR = new TAIGBR();
                var taigInDB = await taigBR.AddTaig(response);
                return Ok(taigInDB);
            }
            catch (Exception ex)
            {
                return GetInternalServerError(ex);
            }
        }
    }
}
