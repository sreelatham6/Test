﻿using AutoMapper;
using NLog;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;
using TAIGCommon.DAL;
using TAIGCommon.Helper;
using TAIGCommon.Model;
using TAIGCommon.Model.DTO;

namespace TAIGAPI.Controllers
{
    public class UserController : BaseController
    {              
        [HttpGet]
        [Route("api/Users/{userNamePattern}")]
        public async Task<IHttpActionResult> GetUsers(string userNamePattern)
        {
            try
            {
                //buscar en la br por display name or lan id
                //return codUserGUID displayname y lanId
                GRDBDAL grdbDAL = new GRDBDAL();
                var response = await grdbDAL.GetUsersByNamePatternAsync(userNamePattern);
                return Ok(response);
            }
            catch (Exception ex)
            {
                return InternalServerError(ex);
            }
        }
        [HttpGet]
        [Route("api/User")]
        public async Task<IHttpActionResult> GetUser()
        {
            try
            {
                return Ok(await SecurityHelper.GetLoggedUser());
            }
            catch (Exception ex)
            {
                logger.Log(LogLevel.Error, "Error:" + ex.Message + "; StackTrace=" + ex.StackTrace);
                return InternalServerError(ex);
            }
        }
        [HttpGet]
        [Route("api/User/{userGUID}")]
        public async Task<IHttpActionResult> GetUserByUserGuid(string userGUID)
        {
            try
            {
                GRDBDAL grdbDAL = new GRDBDAL();
                var response = await grdbDAL.GetUserByUserGuid(userGUID);
                return Ok(response);
            }
            catch (Exception ex)
            {
                return InternalServerError(ex);
            }
        }

        //TODO: Para que?
        //[HttpGet]
        //[Route("api/GetSupervisorBySupName")]
        //public async Task<IHttpActionResult> GetSupervisorBySupNameAsync(string userGUID)
        //{
        //    try
        //    {
        //        GRDBDAL grdbDAL = new GRDBDAL();
        //        var response = await grdbDAL.GetSupervisorBySupNameAsync(userGUID);
        //        return Ok(response);
        //    }
        //    catch (Exception ex)
        //    {
        //        return InternalServerError(ex);
        //    }
        //}
        [HttpGet]
        [Route("api/GetLevel3Organization")] 
        public async Task<IHttpActionResult> GetLevel3Organization()
        {
            try
            {
                GRDBDAL grdbDal = new GRDBDAL();
                var response = await grdbDal.GetLevel3Organization();
                return Ok(response);
            }
            catch (Exception ex)
            {
                return GetInternalServerError(ex);
            }
        }
        [HttpGet]
        [Route("api/OrgChart/{UserGuid}")]
        public async Task<IHttpActionResult> GetOrganizationHierarchy(string UserGuid)
        {
            try
            {
                GRDBDAL grdbDal = new GRDBDAL();
                var response = await grdbDal.GetOrganizationHierarchy(UserGuid);
                return Ok(response);
            }
            catch (Exception ex)
            {
                return GetInternalServerError(ex);
            }
        }

    }
}
