﻿using System.Net;
using System.Net.Http;
using System.Web.Http.Controllers;
using System.Web.Http.Filters;

namespace TAIGAPI.Handlers
{
    public class OnlyRolesAllowedAttribute : AuthorizationFilterAttribute
    {
        string[] _rolesAllowed;

        public OnlyRolesAllowedAttribute(params string[] roles)
        {
            _rolesAllowed = roles;

        }

        public override void OnAuthorization(HttpActionContext actionContext)
        {
            //if (!_rolesAllowed.Contains(LoggedUser.Instance.Role))
            //    actionContext.Response = new HttpResponseMessage(System.Net.HttpStatusCode.Forbidden);
        }

    }
}