﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TAIGAPI.DTO
{
    public class ParticipationDTO
    {
        public int ParticipationID { get; set; }
        public int TAIGID { get; set; }
        public int ParticipationStatusID { get; set; }
        public string OrganizationCode { get; set; }
        public Nullable<System.DateTime> DOAG3LastReviewDateTimeStamp { get; set; }
        public string MembershipType { get; set; }
        public string ComiteeName { get; set; }
        public int RoleID { get; set; }
        public string CurrentOrgPath { get; set; }
        public Nullable<int> PurposeID { get; set; }
        public string RequestorId { get; set; } 
        public string SupervisorId { get; set; }
        public string ContactLawId { get; set; }
        public IEnumerable<Role> Roles { get; set; }
    }
    

}