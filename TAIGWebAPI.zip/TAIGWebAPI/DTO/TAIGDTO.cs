﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using TAIGCommon;

namespace TAIGAPI.DTO
{
    public class TAIGDTO
    {
        public int TAIGID { get; set; }
        public string Title { get; set; }
        public bool Active { get; set; }
        public System.DateTime CreationDate { get; set; }
        public System.DateTime LastModified { get; set; }
        public Nullable<int> Flag { get; set; }
        public string CountryCode { get; set; }
        public string StateProvince { get; set; }
        public string GeographicScope { get; set; }
        public string Description { get; set; }
        public Nullable<System.DateTime> LastReviewDate { get; set; }
    }  
}