﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TAIGAPI.DTO
{
    public class UserDTO
    {
        public string UserGUID { get; set; }
        public string DisplayName { get; set; }
        public string LanId { get; set; }
        public string FunctionlOrganization { get; set; }
        public string FunctionalSupervisorUserCode { get; set; }
    }
}