﻿var app = angular.module("TAIG", ["ngRoute", "ngMaterial"])
.filter('employee', function(input, employees) {
    return function(input) {
      input = input || '';
      var out = '';
      input = input ? input.toLocaleLowerCase() : null;

      out += input ? employees.filter(e => e.toLocaleLowerCase().indexOf(input) !== -1) : value;

      return out;
    };
  })
//.config(function ($routeProvider, $locationProvider) {
//    $routeProvider
//     .when("/newParticipation", {
//         templateUrl: "/web/scripts/app/newParticipation/newParticipation.html"
//     })
//     .when("/myParticipations", {
//         templateUrl: "/web/scripts/app/myParticipations/myParticipations.html"
//     })
//    .otherwise({ redirectTo: '/newParticipation' });

    //$locationProvider.hashPrefix('');

//});

