﻿var app = angular.module("TAIG", ["ngRoute"])
//.config(function ($routeProvider, $locationProvider) {
//    $routeProvider
//     .when("/newParticipation", {
//         templateUrl: "/web/scripts/app/newParticipation/newParticipation.html"
//     })
//     .when("/myParticipations", {
//         templateUrl: "/web/scripts/app/myParticipations/myParticipations.html"
//     })
//    .otherwise({ redirectTo: '/newParticipation' });

    //$locationProvider.hashPrefix('');

//});
