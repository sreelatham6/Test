﻿app.controller('myEndorsements', function ($http, $scope) {
    var vm = this;
    vm.activeTab = 0;
    var dataFromAPI = [
       {
           "participationID": 1,
           "membershipType": "Membership",
           "statusId": 1,
           "status": "NotReviewed ",
           "taigId": 1,
           "taigName": "taig1",
           "userId": "47912524",
           "userName": "Nallar, Juan M",
           "submisionDate": "2018-07-02T10:03:18.337",
           "purposeId": 1,
           "purpose": "Advance CCS Public Policy",
           "role": null,
           "committeeName": null,
           "reviewRequests": [
              {
                  "reviewRequestId": 1,
                  "userGUID": "78793334",
                  "dateTime": "2018-07-02T10:03:18.337",
                  "reviewed": null,
                  "userName": "Nallar, Juan M",
                  "reviewerType": "Supervisor"
              },
              {
                  "reviewRequestId": 2,
                  "userGUID": "78793334",
                  "dateTime": "2018-07-02T10:03:18.337",
                  "reviewed": null,
                  "userName": "Nallar, Juan M",
                  "reviewerType": "Law Contact"
              }
           ],
           "actionsAllowed": [
              "Cancel"
           ]
       },
       {
           "participationID": 2,
           "membershipType": "Membership",
           "statusId": 2,
           "status": "Pending ",
           "taigId": 2,
           "taigName": "taig2",
           "userId": "47912524",
           "userName": "Nallar, Juan M",
           "submisionDate": "2018-07-02T10:03:30.67",
           "purposeId": 1,
           "purpose": "Advance CCS Public Policy",
           "role": null,
           "committeeName": null,
           "reviewRequests": [
              {
                  "reviewRequestId": 3,
                  "userGUID": "78793334",
                  "dateTime": "2018-07-02T10:03:30.67",
                  "reviewed": true,
                  "userName": "Nallar, Juan M",
                  "reviewerType": "Supervisor"
              },
              {
                  "reviewRequestId": 4,
                  "userGUID": "78793334",
                  "dateTime": "2018-07-02T10:03:30.67",
                  "reviewed": null,
                  "userName": "Nallar, Juan M",
                  "reviewerType": "Law Contact"
              }
           ],
           "actionsAllowed": [

           ]
       },
       {
           "participationID": 3,
           "membershipType": "Role",
           "statusId": 3,
           "status": "New ",
           "taigId": 2,
           "taigName": "taig2",
           "userId": "47912524",
           "userName": "Nallar, Juan M",
           "submisionDate": "2018-07-02T10:03:33.823",
           "purposeId": 1,
           "purpose": "Advance CCS Public Policy",
           "role": "Alternate",
           "committeeName": null,
           "reviewRequests": [
              {
                  "reviewRequestId": 5,
                  "userGUID": "78793334",
                  "dateTime": "2018-07-02T10:03:33.84",
                  "reviewed": true,
                  "userName": "Nallar, Juan M",
                  "reviewerType": "Supervisor"
              },
              {
                  "reviewRequestId": 6,
                  "userGUID": "78793334",
                  "dateTime": "2018-07-02T10:03:33.84",
                  "reviewed": true,
                  "userName": "Nallar, Juan M",
                  "reviewerType": "Law Contact"
              },
              {
                  "reviewRequestId": 7,
                  "userGUID": "78793334",
                  "dateTime": "2018-07-02T10:03:33.84",
                  "reviewed": true,
                  "userName": "Nallar, Juan M",
                  "reviewerType": "DOAG3+"
              }
           ],
           "actionsAllowed": [
              "Transfer",
              "Remove"
           ]
       },
       {
           "participationID": 4,
           "membershipType": "Committee",
           "statusId": 3,
           "status": "New ",
           "taigId": 2,
           "taigName": "taig2",
           "userId": "47912524",
           "userName": "Nallar, Juan M",
           "submisionDate": "2018-07-02T10:10:04.41",
           "purposeId": 1,
           "purpose": "Advance CCS Public Policy",
           "role": "Some other Role",
           "committeeName": "Committee 1",
           "reviewRequests": [
              {
                  "reviewRequestId": 8,
                  "userGUID": "78793334",
                  "dateTime": "2018-07-02T10:10:04.41",
                  "reviewed": true,
                  "userName": "Nallar, Juan M",
                  "reviewerType": "Supervisor"
              },
              {
                  "reviewRequestId": 9,
                  "userGUID": "78793334",
                  "dateTime": "2018-07-02T10:10:04.41",
                  "reviewed": true,
                  "userName": "Nallar, Juan M",
                  "reviewerType": "Law Contact"
              },
              {
                  "reviewRequestId": 10,
                  "userGUID": "78793334",
                  "dateTime": "2018-07-02T10:10:04.41",
                  "reviewed": true,
                  "userName": "Nallar, Juan M",
                  "reviewerType": "DOAG3+"
              }
           ],
           "actionsAllowed": [
              "Transfer",
              "Remove"
           ]
       }
    ];

    vm.lists = [
        { name: "Tab 1" },
        { name: "Tab 2" },
        { name: "Tab 3" },
        { name: "Tab 4" },
    ];
});