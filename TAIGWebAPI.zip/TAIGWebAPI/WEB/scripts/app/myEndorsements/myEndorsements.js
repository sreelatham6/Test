﻿app.controller('myEndorsements', function ($http, $window, $mdDialog) {
    var vm = this;
    vm.activeTab = 0;
    var dataFromAPI = [
        {
            "participationID": 1,
            "membershipType": "Membership",
            "statusId": 1,
            "status": "NotReviewed ",
            "taigId": 1,
            "taigName": "taig1",
            "userId": "47912524",
            "userName": "Nallar, Juan M",
            "submittedBy": "Cathrine Braun",
            "submisionDate": "2018-07-02T10:03:18.337",
            "purposeId": 1,
            "purpose": "Advance CCS Public Policy",
            "role": null,
            "committeeName": null,
            "reviewRequests": [
                {
                    "reviewRequestId": 1,
                    "userGUID": "78793334",
                    "dateTime": "2018-07-02T10:03:18.337",
                    "reviewed": null,
                    "userName": "Nallar, Juan M",
                    "reviewerType": "Supervisor"
                },
                {
                    "reviewRequestId": 2,
                    "userGUID": "78793334",
                    "dateTime": "2018-07-02T10:03:18.337",
                    "reviewed": null,
                    "userName": "Nallar, Juan M",
                    "reviewerType": "Law Contact"
                }
            ],
            "actionsAllowed": [
                "Reviewed",
                "Rejected"
            ]
        },
        {
            "participationID": 2,
            "membershipType": "Membership",
            "statusId": 2,
            "status": "Pending ",
            "taigId": 2,
            "taigName": "taig2",
            "userId": "47912524",
            "userName": "Nallar, Juan M",
            "submittedBy": "Cathrine Braun",
            "submisionDate": "2018-07-02T10:03:30.67",
            "purposeId": 1,
            "purpose": "Advance CCS Public Policy",
            "role": null,
            "committeeName": null,
            "reviewRequests": [
                {
                    "reviewRequestId": 3,
                    "userGUID": "78793334",
                    "dateTime": "2018-07-02T10:03:30.67",
                    "reviewed": true,
                    "userName": "Nallar, Juan M",
                    "reviewerType": "Supervisor"
                },
                {
                    "reviewRequestId": 4,
                    "userGUID": "78793334",
                    "dateTime": "2018-07-02T10:03:30.67",
                    "reviewed": null,
                    "userName": "Nallar, Juan M",
                    "reviewerType": "Law Contact"
                }
            ],
            "actionsAllowed": [

            ]
        },
        {
            "participationID": 3,
            "membershipType": "Role",
            "statusId": 3,
            "status": "New ",
            "taigId": 2,
            "taigName": "taig2",
            "userId": "47912524",
            "userName": "Nallar, Juan M",
            "submittedBy": "Cathrine Braun",
            "submisionDate": "2018-07-02T10:03:33.823",
            "purposeId": 1,
            "purpose": "Advance CCS Public Policy",
            "role": "Alternate",
            "committeeName": null,
            "reviewRequests": [
                {
                    "reviewRequestId": 5,
                    "userGUID": "78793334",
                    "dateTime": "2018-07-02T10:03:33.84",
                    "reviewed": true,
                    "userName": "Nallar, Juan M",
                    "reviewerType": "Supervisor"
                },
                {
                    "reviewRequestId": 6,
                    "userGUID": "78793334",
                    "dateTime": "2018-07-02T10:03:33.84",
                    "reviewed": true,
                    "userName": "Nallar, Juan M",
                    "reviewerType": "Law Contact"
                },
                {
                    "reviewRequestId": 7,
                    "userGUID": "78793334",
                    "dateTime": "2018-07-02T10:03:33.84",
                    "reviewed": true,
                    "userName": "Nallar, Juan M",
                    "reviewerType": "DOAG3+"
                }
            ],
            "actionsAllowed": [
                "Transfer",
                "Remove"
            ]
        },
        {
            "participationID": 4,
            "membershipType": "Committee",
            "statusId": 3,
            "status": "New ",
            "taigId": 2,
            "taigName": "taig2",
            "userId": "47912524",
            "userName": "Nallar, Juan M",
            "submittedBy": "Cathrine Braun",
            "submisionDate": "2018-07-02T10:10:04.41",
            "purposeId": 1,
            "purpose": "Advance CCS Public Policy",
            "role": "Some other Role",
            "committeeName": "Committee 1",
            "reviewRequests": [
                {
                    "reviewRequestId": 8,
                    "userGUID": "78793334",
                    "dateTime": "2018-07-02T10:10:04.41",
                    "reviewed": true,
                    "userName": "Nallar, Juan M",
                    "reviewerType": "Supervisor"
                },
                {
                    "reviewRequestId": 9,
                    "userGUID": "78793334",
                    "dateTime": "2018-07-02T10:10:04.41",
                    "reviewed": true,
                    "userName": "Nallar, Juan M",
                    "reviewerType": "Law Contact"
                },
                {
                    "reviewRequestId": 10,
                    "userGUID": "78793334",
                    "dateTime": "2018-07-02T10:10:04.41",
                    "reviewed": true,
                    "userName": "Nallar, Juan M",
                    "reviewerType": "DOAG3+"
                }
            ],
            "actionsAllowed": [
                "Transfer",
                "Remove"
            ]
        }
    ];
    
    vm.orgChart = [
        {
            "Code": "48346676",
            "LanId": "UPSTREAMACCTS\\LDUCHAR",
            "Level": { "-i:nil": "true" },
            "Name": "DuCharme, Linda D",
            "OrganizationCode": "90000386",
            "Position": "PRESIDENT GLOBAL SVCS CO"
        },
        {
            "Code": "41276403",
            "LanId": "NA\\MSBROWN",
            "Level": { "-i:nil": "true" },
            "Name": "Brown, Michael S",
            "OrganizationCode": "90000395",
            "Position": "VP GLOBAL INFORMATION TECHNOLOGY"
        },
        {
            "Code": "69641468",
            "LanId": "NA\\SRCHERE",
            "Level": { "-i:nil": "true" },
            "Name": "Cherek, Steve R",
            "OrganizationCode": "11002245",
            "Position": "MANAGER IS EXEC"
        },
        {
            "Code": "70374545",
            "LanId": "NA\\KJREDDIN",
            "Level": { "-i:nil": "true" },
            "Name": "Luddeke, Karen J",
            "OrganizationCode": "90551005",
            "Position": "MGR APPL FINANCIAL"
        },
        {
            "Code": "70374545",
            "LanId": "NA\\KJREDDIN",
            "Level": { "-i:nil": "true" },
            "Name": "Luddeke, Karen J",
            "OrganizationCode": "90551005",
            "Position": "SUPERVISOR IS SENIOR"
        },
        {
            "Code": "69641468",
            "LanId": "NA\\SRCHERE",
            "Level": { "-i:nil": "true" },
            "Name": "Cherek, Steve R",
            "OrganizationCode": "11002245",
            "Position": "SUPERVISOR IS SENIOR"
        },
        {
            "Code": "57587808",
            "LanId": "UPSTREAMACCTS\\EJMALVE",
            "Level": { "-i:nil": "true" },
            "Name": "Malveaux, Edrice J",
            "OrganizationCode": "90509000",
            "Position": "SUPERVISOR IS SENIOR"
        },
        {
            "Code": "47912524",
            "LanId": "UPSTREAMACCTS\\JMNALLA",
            "Level": { "-i:nil": "true" },
            "Name": "Nallar, Juan M",
            "OrganizationCode": "10890832",
            "Position": "SUPERVISOR"
        },
        {
            "Code": "78793334",
            "LanId": "SA\\NOMANA",
            "Level": { "-i:nil": "true" },
            "Name": "Omana, Nicolas",
            "OrganizationCode": "10890832",
            "Position": "SUPERVISOR"
        },
        {
            "Code": "48346676",
            "LanId": "UPSTREAMACCTS\\LDUCHAR",
            "Level": { "-i:nil": "true" },
            "Name": "DuCharme, Linda D",
            "OrganizationCode": "90000386",
            "Position": "CONTINGENCE WORKFORCE MANAGER"
        },
        {
            "Code": "48346676",
            "LanId": "UPSTREAMACCTS\\LDUCHAR",
            "Level": { "-i:nil": "true" },
            "Name": "DuCharme, Linda D",
            "OrganizationCode": "90000386",
            "Position": "ASST STAFF TO PRES"
        }
    ];

    vm.getOrgChart = function (tabToActivate) {
        $http({
            url: "api/OrgChart/47912524",
            method: 'GET',
            headers: { Accept: 'application/json' },
            paramSerializer: '$httpParamSerializerJQLike'
        }).then(function (response) {
            vm.orgChart = response.data;
        }).catch(function (e) {
            console.log("Error: " + e.status + " - " + e.statusText);
            alert("There were errors retrieving data. Please, retry and if the issue still ocurrs contact the IT analyst");
        });
    }

    vm.lists = [
        { name: "Action Needed", count: 0, taigs: [], memberships: 0, committees: 0, roles: 0 },
        { name: "Action Completed", count: 0, taigs: [], memberships: 0, committees: 0, roles: 0 },
    ];

    var processParticipations = function (participations) {
        var aux = dataFromAPI.filter(function (p) { return p.statusId == 1 });
        vm.lists[0].count = aux.length;
        vm.lists[0].taigs = groupByTAIG(aux);

        var aux = dataFromAPI.filter(function (p) { return p.statusId == 2 });
        vm.lists[1].count = aux.length;
        vm.lists[1].taigs = groupByTAIG(aux);

    }

    var groupByTAIG = function (participations) {
        var dictionary = {};

        for (var i = 0; i < participations.length; i++) {
            if (!dictionary[participations[i].taigName])
                dictionary[participations[i].taigName] = { participations: [] };
            dictionary[participations[i].taigName].participations.push(participations[i]);
        }

        var result = [];
        for (t in dictionary) {
            result.push({ 
                taigName: t, 
                participations: dictionary[t].participations,
                memberships: dictionary[t].participations.filter(function (p) { return p.membershipType == 'Membership'}).length,
                committees: dictionary[t].participations.filter(function (p) { return p.membershipType == 'Committee'}).length,
                roles: dictionary[t].participations.filter(function (p) { return p.membershipType == 'Role'}).length
            });
        }
        return result;
    }

    processParticipations(dataFromAPI);

    vm.button_set_all = function (ev) {
        var confirm = $mdDialog.confirm()
            .title('Would you like to set all participations to reviewed status?')
            .textContent('This process will loop through all the participations displayed and set the status to reviewed.')
            .ariaLabel('Lucky day')
            .targetEvent(ev)
            .cancel('No, Cancel')
            .ok('Yes, Continue!')
            .clickOutsideToClose(true);

        $mdDialog.show(confirm).then(function () {

            var x = [{ userId: 0, slider: '' }];
            vm.orgChart.forEach(e => {
                x.userId = e.userGUID,
                x.slider = e.slider
            });

            $http({
                url: "api/ReviewAllParticipation/",
                method: 'POST',
                data: x
            }).catch(function(e){
                console.log("Error: " + e.status + " - " + e.statusText);
                alert("There was an error setting all participations to reviewed!");
            })
        });
    }

    vm.button_handler = function (action, participationid, ev, taigName, membershipType) {
        switch (action) {
            case 'Cancel':

                var confirm = $mdDialog.confirm()
                    .title('Would you like to cancel ' + membershipType + ': ' + participationid +' from ' + taigName + ' ?')
                    .textContent('This process will delete the participation out of the system.')
                    .ariaLabel('Lucky day')
                    .targetEvent(ev)
                    .cancel('No, Cancel')
                    .ok('Yes, Continue!')
                    .clickOutsideToClose(true);

                $mdDialog.show(confirm).then(function(result) {
                    $http({
                        url: "api/CancelParticipation/" + participationid,
                        method: 'DELETE'
                    }).catch(function(e){
                        console.log("Error: " + e.status + " - " + e.statusText);
                        alert("There was an error deleting the participation!");
                    })
                });

                break;

            case 'Reviewed':

                var confirm = $mdDialog.confirm()
                    .title('Set ' + membershipType + ': ' + participationid + ' from ' + taigName + ' to reviewed?')
                    .textContent('This process will set the participation to reviewed status.')
                    .ariaLabel('Lucky day')
                    .targetEvent(ev)
                    .cancel('No, Cancel')
                    .ok('Yes, Continue!')
                    .clickOutsideToClose(true);

                $mdDialog.show(confirm).then(function(result) {
                    $http({
                        url: "api/ReviewedParticipation/" + participationid,
                        method: 'PUT'
                    }).catch(function(e){
                        console.log("Error: " + e.status + " - " + e.statusText);
                        alert("There was an error setting to reviewed!");
                    })
                });

                break;

            case 'Rejected':

                var confirm = $mdDialog.confirm()
                    .title('Set ' + membershipType + ': ' + participationid + ' from ' + taigName + ' to rejected?')
                    .textContent('This process will set the participation to rejected status.')
                    .ariaLabel('Lucky day')
                    .targetEvent(ev)
                    .cancel('No, Cancel')
                    .ok('Yes, Continue!')
                    .clickOutsideToClose(true);

                $mdDialog.show(confirm).then(function(result) {
                    $http({
                        url: "api/RejectedParticipation/" + participationid,
                        method: 'PUT'
                    }).catch(function(e){
                        console.log("Error: " + e.status + " - " + e.statusText);
                        alert("There was an error setting to rejected!");
                    })
                });

                break;

        }
    }

    //vm.activateTab = function(tab)
    //{
    //    vm.activeTab = tab;
    //    switch (tab) {
    //        case 0:
    //            vm.listToShow = ;
    //            vm.activeListLength = vm.listToShow.length;
    //            vm.title = vm.listToShow.taigName;
    //            break;
    //        case 1:
    //            vm.pendingListLength = vm.listToShow.length;
    //            break;
    //        case 2:
    //            vm.listToShow = vm.participations.filter(function (p) { return [3, 6, 7, 8].indexOf(p.statusId) > -1 });
    //            vm.actionListLength = vm.listToShow.length;
    //            break;
    //        case 3:
    //            vm.listToShow = vm.participations.filter(function (p) { return [4, 5].indexOf(p.statusId) > -1 });
    //            vm.archiveListLength = vm.listToShow.length;
    //            break;
    //    }
    //}

    vm.getParticipations = function (tabToActivate) {
        $http({
            url: "api/Participations/47912524",
            method: 'GET',
            headers: { Accept: 'application/json' },
            paramSerializer: '$httpParamSerializerJQLike'
        }).then(function (response) {
            processParticipations(response.data)
            if (tabToActivate != null)
                vm.activeTab = tabToActivate;
        }).catch(function (e) {
            console.log("Error: " + e.status + " - " + e.statusText);
            alert("There were errors retrieving data. Please, retry and if the issue still ocurrs contact the IT analyst");
        });
    }

    //vm.activateTab(0);
    //vm.getParticipations(0);
});