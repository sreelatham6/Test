﻿app.controller('myParticipations', function ($http, $window, $mdDialog) {
    var vm = this;
    vm.activeTab = 0;
    vm.employee = '';

    var dataFromAPI = [
        {
            "participationID": 1,
            "membershipType": "Membership",
            "statusId": 1,
            "status": "NotReviewed ",
            "taigId": 1,
            "taigName": "taig1",
            "userId": "47912524",
            "userName": "Nallar, Juan M",
            "submisionDate": "2018-07-02T10:03:18.337",
            "purposeId": 1,
            "purpose": "Advance CCS Public Policy",
            "role": null,
            "committeeName": null,
            "reviewRequests": [
                {
                    "reviewRequestId": 1,
                    "userGUID": "78793334",
                    "dateTime": "2018-07-02T10:03:18.337",
                    "reviewed": null,
                    "userName": "Nallar, Juan M",
                    "reviewerType": "Supervisor"
                },
                {
                    "reviewRequestId": 2,
                    "userGUID": "78793334",
                    "dateTime": "2018-07-02T10:03:18.337",
                    "reviewed": null,
                    "userName": "Nallar, Juan M",
                    "reviewerType": "Law Contact"
                }
            ],
            "actionsAllowed": [
                "Cancel"
            ]
        },
        {
            "participationID": 2,
            "membershipType": "Membership",
            "statusId": 2,
            "status": "Pending ",
            "taigId": 2,
            "taigName": "taig2",
            "userId": "47912524",
            "userName": "Nallar, Juan M",
            "submisionDate": "2018-07-02T10:03:30.67",
            "purposeId": 1,
            "purpose": "Advance CCS Public Policy",
            "role": null,
            "committeeName": null,
            "reviewRequests": [
                {
                    "reviewRequestId": 3,
                    "userGUID": "78793334",
                    "dateTime": "2018-07-02T10:03:30.67",
                    "reviewed": true,
                    "userName": "Nallar, Juan M",
                    "reviewerType": "Supervisor"
                },
                {
                    "reviewRequestId": 4,
                    "userGUID": "78793334",
                    "dateTime": "2018-07-02T10:03:30.67",
                    "reviewed": null,
                    "userName": "Nallar, Juan M",
                    "reviewerType": "Law Contact"
                }
            ],
            "actionsAllowed": [

            ]
        },
        {
            "participationID": 3,
            "membershipType": "Role",
            "statusId": 3,
            "status": "New ",
            "taigId": 2,
            "taigName": "taig2",
            "userId": "47912524",
            "userName": "Nallar, Juan M",
            "submisionDate": "2018-07-02T10:03:33.823",
            "purposeId": 1,
            "purpose": "Advance CCS Public Policy",
            "role": "Alternate",
            "committeeName": null,
            "reviewRequests": [
                {
                    "reviewRequestId": 5,
                    "userGUID": "78793334",
                    "dateTime": "2018-07-02T10:03:33.84",
                    "reviewed": true,
                    "userName": "Nallar, Juan M",
                    "reviewerType": "Supervisor"
                },
                {
                    "reviewRequestId": 6,
                    "userGUID": "78793334",
                    "dateTime": "2018-07-02T10:03:33.84",
                    "reviewed": true,
                    "userName": "Nallar, Juan M",
                    "reviewerType": "Law Contact"
                },
                {
                    "reviewRequestId": 7,
                    "userGUID": "78793334",
                    "dateTime": "2018-07-02T10:03:33.84",
                    "reviewed": true,
                    "userName": "Nallar, Juan M",
                    "reviewerType": "DOAG3+"
                }
            ],
            "actionsAllowed": [
                "Transfer",
                "Remove"
            ]
        },
        {
            "participationID": 4,
            "membershipType": "Committee",
            "statusId": 3,
            "status": "New ",
            "taigId": 2,
            "taigName": "taig2",
            "userId": "47912524",
            "userName": "Nallar, Juan M",
            "submisionDate": "2018-07-02T10:10:04.41",
            "purposeId": 1,
            "purpose": "Advance CCS Public Policy",
            "role": "Some other Role",
            "committeeName": "Committee 1",
            "reviewRequests": [
                {
                    "reviewRequestId": 8,
                    "userGUID": "78793334",
                    "dateTime": "2018-07-02T10:10:04.41",
                    "reviewed": true,
                    "userName": "Nallar, Juan M",
                    "reviewerType": "Supervisor"
                },
                {
                    "reviewRequestId": 9,
                    "userGUID": "78793334",
                    "dateTime": "2018-07-02T10:10:04.41",
                    "reviewed": true,
                    "userName": "Nallar, Juan M",
                    "reviewerType": "Law Contact"
                },
                {
                    "reviewRequestId": 10,
                    "userGUID": "78793334",
                    "dateTime": "2018-07-02T10:10:04.41",
                    "reviewed": true,
                    "userName": "Nallar, Juan M",
                    "reviewerType": "DOAG3+"
                }
            ],
            "actionsAllowed": [
                "Transfer",
                "Remove"
            ]
        }
    ];

    vm.lists = [
        { name: "Active" },
        { name: "Pending" },
        { name: "Action Needed" },
        { name: "Archive" },
    ];

    var processParticipations = function (participations) {
        var aux = dataFromAPI.filter(function (p) { return p.statusId == 1 });
        vm.lists[0].count = aux.length;
        vm.lists[0].taigs = groupByTAIG(aux);

        aux = dataFromAPI.filter(function (p) { return p.statusId == 2 });
        vm.lists[1].count = aux.length;
        vm.lists[1].taigs = groupByTAIG(aux);

        aux = dataFromAPI.filter(function (p) { return [3, 6, 7, 8].indexOf(p.statusId) > -1 });
        vm.lists[2].count = aux.length;
        vm.lists[2].taigs = groupByTAIG(aux);

        aux = dataFromAPI.filter(function (p) { return [4, 5].indexOf(p.statusId) > -1 });
        vm.lists[3].count = aux.length;
        vm.lists[3].taigs = groupByTAIG(aux);
    }


    var groupByTAIG = function (participations) {
        var dictionary = {};

        for (var i = 0; i < participations.length; i++) {
            if (!dictionary[participations[i].taigName])
                dictionary[participations[i].taigName] = { participations: [] };
            dictionary[participations[i].taigName].participations.push(participations[i]);
        }

        var result = [];
        for (t in dictionary) {
            result.push({ taigName: t, participations: dictionary[t].participations });
        }
        return result;
    }

    processParticipations(dataFromAPI);

    vm.button_handler = function (ev, userid, action, participationid, activetab, memebershiptype) {
        switch (action) {
            case 'Cancel':
                var confirm = $mdDialog.confirm()
                    .textContent("Would you like to cancel this " + memebershiptype + "?")
                    .targetEvent(ev)
                    .cancel('No')
                    .ok('Yes')
                    .clickOutsideToClose(false);

                $mdDialog.show(confirm).then(function () {
                    vm.cancelParticipation(ev, participationid, memebershiptype);
                    processParticipations(dataFromAPI);
                    //vm.activateTab(activetab);
                    //vm.getParticipations(activetab);
                }, function () {
                    return false;
                });

            case 'Keep':
                break;

            case 'Transfer':
                    $mdDialog.show({
                        locals: {
                            ev: ev,
                            participationid: participationid, 
                            activetab: activetab,
                            userid: userid
                        },
                    controller: vm.transferController,
                    template: `
                    <md-dialog>
                    <md-dialog-content>
                                <div class="em-c-field em-js-typeahead">
                                    <div class="em-c-field__body">
                                        <input type="text" id="employee" placeholder="Enter employee" class="em-c-input em-js-typeahead" ng-change="onChangeEmployee(employee)"
                                            ng-model="employee" />
                                        <div class="em-c-field__menu em-js-typeahead-menu" ng-class="{'em-is-active': employeelist.length > 0 && employee !== ''}">
                                            <ul class="em-c-typeahead-list" ng-repeat="emp in employeelist">
                                                <li class="em-c-typeahead-list__item" ng-click="onSetEmployee(emp)">
                                                    <span class="em-c-typeahead__suggestion">{{emp}}</span>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <md-dialog-actions>
                                <md-button ng-click="onTransfer(ev, participationid, employee)">Transfer</md-button>
                                <md-button ng-click="onClose()">Close</md-button>
                                </md-dialog-actions>
                            </md-dialog-content>
                        </md-dialog>
                  `,
                    parent: angular.element(document.body),
                    targetEvent: ev,
                    clickOutsideToClose: false,
                    bindToController: true,
                    autowrap: false,
                    fullscreen: vm.customFullscreen // Only for -xs, -sm breakpoints
                })
                    .then(function (answer) {
                        vm.status = 'You said the information was "' + answer + '".';
                    }, function () {
                        vm.status = 'You cancelled the dialog.';
                    });
                break;

            case 'Remove':
                var confirm = $mdDialog.confirm()
                    .textContent("Would you like to remove this " + memebershiptype + "?")
                    .targetEvent(ev)
                    .cancel('No')
                    .ok('Yes')
                    .clickOutsideToClose(false);

                $mdDialog.show(confirm).then(function () {
                    vm.removeParticipation(ev, participationid, memebershiptype);
                    processParticipations(dataFromAPI);
                    //vm.activateTab(activetab);
                    //vm.getParticipations(activetab);
                }, function () {
                    return false;
                });
        }
    }

    //vm.activateTab = function(tab)
    //{
    //    vm.activeTab = tab;
    //    switch (tab) {
    //        case 0:
    //            vm.listToShow = ;
    //            vm.activeListLength = vm.listToShow.length;
    //            vm.title = vm.listToShow.taigName;
    //            break;
    //        case 1:
    //            vm.pendingListLength = vm.listToShow.length;
    //            break;
    //        case 2:
    //            vm.listToShow = vm.participations.filter(function (p) { return [3, 6, 7, 8].indexOf(p.statusId) > -1 });
    //            vm.actionListLength = vm.listToShow.length;
    //            break;
    //        case 3:
    //            vm.listToShow = vm.participations.filter(function (p) { return [4, 5].indexOf(p.statusId) > -1 });
    //            vm.archiveListLength = vm.listToShow.length;
    //            break;
    //    }
    //}

    vm.getParticipations = function (tabToActivate) {
        $http({
            url: "api/Participations/47912524",
            method: 'GET',
            headers: { Accept: 'application/json' },
            paramSerializer: '$httpParamSerializerJQLike'
        }).then(function (response) {
            vm.processParticipations(response.data)
            if (tabToActivate != null)
                vm.activeTab = tabToActivate;
        }).catch(function (e) {
            console.log("Error: " + e.status + " - " + e.statusText);
            alert("There were errors retrieving data. Please, retry and if the issue still ocurrs contact the IT analyst");
        });
    }

    vm.cancelParticipation = function (ev, id, memebershiptype) {
        $http({
            url: "api/CancelParticipation/" + id,
            method: 'DELETE'
        }).then(function () {
            alert("Participation cancelled!");
        }).catch(function (e) {
            console.log("Error: " + e.status + " - " + e.statusText);
            $mdDialog.show(
                $mdDialog.alert()
                    .parent(angular.element(document.querySelector('#popupContainer')))
                    .clickOutsideToClose(false)
                    .textContent('There was an error completing this request!')
                    .ok('OK')
                    .targetEvent(ev)
            );
        })
    }

    vm.removeParticipation = function (ev, id, memebershiptype) {
        $http({
            url: "api/RemoveParticipation/" + id,
            method: 'DELETE'
        }).then(function () {
            alert("Participation removed!");
        }).catch(function (e) {
            console.log("Error: " + e.status + " - " + e.statusText);
            $mdDialog.show(
                $mdDialog.alert()
                    .parent(angular.element(document.querySelector('#popupContainer')))
                    .clickOutsideToClose(false)
                    .textContent('There was an error completing this request!')
                    .ok('OK')
                    .targetEvent(ev)
            );
        })
    }

    vm.transferParticipation = function (ev, participationid, employee) {
        $http({
            url: "api/TransferParticipation/" + participationid + "/" + employee,
            method: 'PUT'
        }).then(function () {
            alert("Participation transferred!");
        }).catch(function (e) {
            console.log("Error: " + e.status + " - " + e.statusText);
            $mdDialog.show(
                $mdDialog.alert()
                    .parent(angular.element(document.querySelector('#popupContainer')))
                    .clickOutsideToClose(false)
                    .textContent('There was an error completing this request!')
                    .ok('OK')
                    .targetEvent(ev)
            );
        })
    }

    //vm.activateTab(0);
    //vm.getParticipations(0);

    vm.orgChart = [
        {
            "Code": "48346676",
            "LanId": "UPSTREAMACCTS\\LDUCHAR",
            "Level": { "-i:nil": "true" },
            "Name": "DuCharme, Linda D",
            "OrganizationCode": "90000386",
            "Position": "PRESIDENT GLOBAL SVCS CO"
        },
        {
            "Code": "41276403",
            "LanId": "NA\\MSBROWN",
            "Level": { "-i:nil": "true" },
            "Name": "Brown, Michael S",
            "OrganizationCode": "90000395",
            "Position": "VP GLOBAL INFORMATION TECHNOLOGY"
        },
        {
            "Code": "69641468",
            "LanId": "NA\\SRCHERE",
            "Level": { "-i:nil": "true" },
            "Name": "Cherek, Steve R",
            "OrganizationCode": "11002245",
            "Position": "MANAGER IS EXEC"
        },
        {
            "Code": "70374545",
            "LanId": "NA\\KJREDDIN",
            "Level": { "-i:nil": "true" },
            "Name": "Luddeke, Karen J",
            "OrganizationCode": "90551005",
            "Position": "MGR APPL FINANCIAL"
        },
        {
            "Code": "70374545",
            "LanId": "NA\\KJREDDIN",
            "Level": { "-i:nil": "true" },
            "Name": "Luddeke, Karen J",
            "OrganizationCode": "90551005",
            "Position": "SUPERVISOR IS SENIOR"
        },
        {
            "Code": "69641468",
            "LanId": "NA\\SRCHERE",
            "Level": { "-i:nil": "true" },
            "Name": "Cherek, Steve R",
            "OrganizationCode": "11002245",
            "Position": "SUPERVISOR IS SENIOR"
        },
        {
            "Code": "57587808",
            "LanId": "UPSTREAMACCTS\\EJMALVE",
            "Level": { "-i:nil": "true" },
            "Name": "Malveaux, Edrice J",
            "OrganizationCode": "90509000",
            "Position": "SUPERVISOR IS SENIOR"
        },
        {
            "Code": "47912524",
            "LanId": "UPSTREAMACCTS\\JMNALLA",
            "Level": { "-i:nil": "true" },
            "Name": "Nallar, Juan M",
            "OrganizationCode": "10890832",
            "Position": "SUPERVISOR"
        },
        {
            "Code": "78793334",
            "LanId": "SA\\NOMANA",
            "Level": { "-i:nil": "true" },
            "Name": "Omana, Nicolas",
            "OrganizationCode": "10890832",
            "Position": "SUPERVISOR"
        },
        {
            "Code": "48346676",
            "LanId": "UPSTREAMACCTS\\LDUCHAR",
            "Level": { "-i:nil": "true" },
            "Name": "DuCharme, Linda D",
            "OrganizationCode": "90000386",
            "Position": "CONTINGENCE WORKFORCE MANAGER"
        },
        {
            "Code": "48346676",
            "LanId": "UPSTREAMACCTS\\LDUCHAR",
            "Level": { "-i:nil": "true" },
            "Name": "DuCharme, Linda D",
            "OrganizationCode": "90000386",
            "Position": "ASST STAFF TO PRES"
        }
    ];
    vm.getOrgChart = function (tabToActivate) {
        $http({
            url: "api/OrgChart/47912524",
            method: 'GET',
            headers: { Accept: 'application/json' },
            paramSerializer: '$httpParamSerializerJQLike'
        }).then(function (response) {
            vm.orgChart = response.data;
        }).catch(function (e) {
            console.log("Error: " + e.status + " - " + e.statusText);
            alert("There were errors retrieving data. Please, retry and if the issue still ocurrs contact the IT analyst");
        });
    }

    vm.getTransferEmployees = function (userid) {
        $http({
            url: "api/GetUserDTOEmployees/" + userid,
            method: 'GET',
            headers: { Accept: 'application/json' },
            paramSerializer: '$httpParamSerializerJQLike'
        }).then(function (response) {
            vm.tobeTransEmployees = response.data;
        }).catch(function (e) {
            console.log("Error: " + e.status + " - " + e.statusText);
            alert("There were errors retrieving data. Please, retry and if the issue still ocurrs contact the IT analyst");
        });
    }

    vm.getTransferredUserDTO = function (userid) {
        $http({
            url: "api/GetTransferUserDTO/" + userid,
            method: 'GET',
            headers: { Accept: 'application/json' },
            paramSerializer: '$httpParamSerializerJQLike'
        }).then(function (response) {
            vm.transferredUserDTO = response.data;
        }).catch(function (e) {
            console.log("Error: " + e.status + " - " + e.statusText);
            alert("There were errors retrieving data. Please, retry and if the issue still ocurrs contact the IT analyst");
        });
    }

    //transfer participation
    vm.transferController = function (ev, userid, activetab, participationid, $scope, $mdDialog) {

        //vm.getTransferEmployees(userid);
        vm.tobeTransEmployees = [
            {UserId: 1, Name:"Juan", OgL3Path: 10}, {UserId: 2, Name:"Vincent", OgL3Path: 20}
        ];

        $scope.employeelist = [];

        $scope.onChangeEmployee = function (emp) {
            for (var i = 0; i < vm.tobeTransEmployees.length; i++) {
                if (vm.tobeTransEmployees[i].Name.toLocaleLowerCase().indexOf(emp) > -1) 
                {
                    $scope.employeelist.push(vm.tobeTransEmployees[i].Name);
                }
            }
        }

        $scope.onSetEmployee = function (emp) {
            $scope.employee = emp;
            $scope.employeelist = [];

            //vm.getTransferredUserDTO(userid)
            vm.transferredUserDTO = [
                {UserId: 1, Name:"Alex", OgL3Path: 30}, {UserId: 2, Name:"Sree", OgL3Path: 20}
            ];


            $mdDialog.show({
                locals: {
                    ev: ev,
                    participationid: participationid, 
                    activetab: activetab
                },
            controller: function(ev, $mdDialog){
                this.click = function(){
                  $mdDialog.hide();
                }
            },
            template: `
            <md-dialog>
            <md-dialog-content>
                        <div class="em-c-field em-js-typeahead">
                            <div class="em-c-field__body">
                                <input type="text" id="employee" placeholder="Enter employee" class="em-c-input em-js-typeahead" ng-change="onChangeEmployee(employee)"
                                    ng-model="employee" />
                                <div class="em-c-field__menu em-js-typeahead-menu" ng-class="{'em-is-active': employeelist.length > 0 && employee !== ''}">
                                    <ul class="em-c-typeahead-list" ng-repeat="emp in employeelist">
                                        <li class="em-c-typeahead-list__item" ng-click="onSetEmployee(emp)">
                                            <span class="em-c-typeahead__suggestion">{{emp}}</span>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <md-dialog-actions>
                        <md-button ng-click="onTransfer(ev, participationid, employee)">Confirm</md-button>
                        <md-button ng-click="onClose()">Close</md-button>
                        </md-dialog-actions>
                    </md-dialog-content>
                </md-dialog>
          `,
            parent: angular.element(document.body),
            targetEvent: ev,
            clickOutsideToClose: false,
            fullscreen: vm.customFullscreen // Only for -xs, -sm breakpoints
            });
        }

        $scope.onClose = function(){
            $mdDialog.cancel();
        }

        $scope.onTransfer = function(ev, participationid, employee){
            $mdDialog.hide(employee);
            vm.transferParticipation(ev, participationid, employee);
            processParticipations(dataFromAPI);
        }
    }

});