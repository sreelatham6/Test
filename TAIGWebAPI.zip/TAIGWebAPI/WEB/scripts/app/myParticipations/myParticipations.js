﻿app.controller('myParticipations', function ($http, $window) {
    var vm = this;
    vm.activeTab = 0;

    var dataFromAPI = [
        {
            "participationID": 1,
            "membershipType": "Membership",
            "statusId": 1,
            "status": "NotReviewed ",
            "taigId": 1,
            "taigName": "taig1",
            "userId": "47912524",
            "userName": "Nallar, Juan M",
            "submisionDate": "2018-07-02T10:03:18.337",
            "purposeId": 1,
            "purpose": "Advance CCS Public Policy",
            "role": null,
            "committeeName": null,
            "reviewRequests": [
                {
                    "reviewRequestId": 1,
                    "userGUID": "78793334",
                    "dateTime": "2018-07-02T10:03:18.337",
                    "reviewed": null,
                    "userName": "Nallar, Juan M",
                    "reviewerType": "Supervisor"
                },
                {
                    "reviewRequestId": 2,
                    "userGUID": "78793334",
                    "dateTime": "2018-07-02T10:03:18.337",
                    "reviewed": null,
                    "userName": "Nallar, Juan M",
                    "reviewerType": "Law Contact"
                }
            ],
            "actionsAllowed": [
                "Cancel"
            ]
        },
        {
            "participationID": 2,
            "membershipType": "Membership",
            "statusId": 2,
            "status": "Pending ",
            "taigId": 2,
            "taigName": "taig2",
            "userId": "47912524",
            "userName": "Nallar, Juan M",
            "submisionDate": "2018-07-02T10:03:30.67",
            "purposeId": 1,
            "purpose": "Advance CCS Public Policy",
            "role": null,
            "committeeName": null,
            "reviewRequests": [
                {
                    "reviewRequestId": 3,
                    "userGUID": "78793334",
                    "dateTime": "2018-07-02T10:03:30.67",
                    "reviewed": true,
                    "userName": "Nallar, Juan M",
                    "reviewerType": "Supervisor"
                },
                {
                    "reviewRequestId": 4,
                    "userGUID": "78793334",
                    "dateTime": "2018-07-02T10:03:30.67",
                    "reviewed": null,
                    "userName": "Nallar, Juan M",
                    "reviewerType": "Law Contact"
                }
            ],
            "actionsAllowed": [

            ]
        },
        {
            "participationID": 3,
            "membershipType": "Role",
            "statusId": 3,
            "status": "New ",
            "taigId": 2,
            "taigName": "taig2",
            "userId": "47912524",
            "userName": "Nallar, Juan M",
            "submisionDate": "2018-07-02T10:03:33.823",
            "purposeId": 1,
            "purpose": "Advance CCS Public Policy",
            "role": "Alternate",
            "committeeName": null,
            "reviewRequests": [
                {
                    "reviewRequestId": 5,
                    "userGUID": "78793334",
                    "dateTime": "2018-07-02T10:03:33.84",
                    "reviewed": true,
                    "userName": "Nallar, Juan M",
                    "reviewerType": "Supervisor"
                },
                {
                    "reviewRequestId": 6,
                    "userGUID": "78793334",
                    "dateTime": "2018-07-02T10:03:33.84",
                    "reviewed": true,
                    "userName": "Nallar, Juan M",
                    "reviewerType": "Law Contact"
                },
                {
                    "reviewRequestId": 7,
                    "userGUID": "78793334",
                    "dateTime": "2018-07-02T10:03:33.84",
                    "reviewed": true,
                    "userName": "Nallar, Juan M",
                    "reviewerType": "DOAG3+"
                }
            ],
            "actionsAllowed": [
                "Transfer",
                "Remove"
            ]
        },
        {
            "participationID": 4,
            "membershipType": "Committee",
            "statusId": 3,
            "status": "New ",
            "taigId": 2,
            "taigName": "taig2",
            "userId": "47912524",
            "userName": "Nallar, Juan M",
            "submisionDate": "2018-07-02T10:10:04.41",
            "purposeId": 1,
            "purpose": "Advance CCS Public Policy",
            "role": "Some other Role",
            "committeeName": "Committee 1",
            "reviewRequests": [
                {
                    "reviewRequestId": 8,
                    "userGUID": "78793334",
                    "dateTime": "2018-07-02T10:10:04.41",
                    "reviewed": true,
                    "userName": "Nallar, Juan M",
                    "reviewerType": "Supervisor"
                },
                {
                    "reviewRequestId": 9,
                    "userGUID": "78793334",
                    "dateTime": "2018-07-02T10:10:04.41",
                    "reviewed": true,
                    "userName": "Nallar, Juan M",
                    "reviewerType": "Law Contact"
                },
                {
                    "reviewRequestId": 10,
                    "userGUID": "78793334",
                    "dateTime": "2018-07-02T10:10:04.41",
                    "reviewed": true,
                    "userName": "Nallar, Juan M",
                    "reviewerType": "DOAG3+"
                }
            ],
            "actionsAllowed": [
                "Transfer",
                "Remove"
            ]
        }
    ];

    vm.lists = [
        { name: "Active" },
        { name: "Pending" },
        { name: "Action Needed" },
        { name: "Archive" },
    ];

    var processParticipations = function (participations) {
        var aux = dataFromAPI.filter(function (p) { return p.statusId == 1 });
        vm.lists[0].count = aux.length;
        vm.lists[0].taigs = groupByTAIG(aux);

        aux = dataFromAPI.filter(function (p) { return p.statusId == 2 });
        vm.lists[1].count = aux.length;
        vm.lists[1].taigs = groupByTAIG(aux);

        aux = dataFromAPI.filter(function (p) { return [3, 6, 7, 8].indexOf(p.statusId) > -1 });
        vm.lists[2].count = aux.length;
        vm.lists[2].taigs = groupByTAIG(aux);

        aux = dataFromAPI.filter(function (p) { return [4, 5].indexOf(p.statusId) > -1 });
        vm.lists[3].count = aux.length;
        vm.lists[3].taigs = groupByTAIG(aux);
    }


    var groupByTAIG = function (participations) {
        var dictionary = {};

        for (var i = 0; i < participations.length; i++) {
            if (!dictionary[participations[i].taigName])
                dictionary[participations[i].taigName] = { participations: [] };
            dictionary[participations[i].taigName].participations.push(participations[i]);
        }

        var result = [];
        for (t in dictionary) {
            result.push({ taigName: t, participations: dictionary[t].participations });
        }
        return result;
    }

    processParticipations(dataFromAPI);

    vm.button_handler = function (action, participationid, activetab) {
        switch (action) {
            case 'Cancel':
                if ($window.confirm('You want to cancel the request?')) {
                    deleteParticipation(participationid);
                    processParticipations(dataFromAPI);
                    //vm.activateTab(activetab);
                    //vm.getParticipations(activetab);
                    break;
                }
                else {
                    return false;
                    break;
                }

            case 'Keep':
                break;

            case 'Transfer':
                break;

            case 'Remove':
                if ($window.confirm('You want to cancel the request?')) {
                    deleteParticipation(participationid);
                    processParticipations(dataFromAPI);
                    //vm.activateTab(activetab);
                    //vm.getParticipations(activetab);
                    break;
                }
                else {
                    return false;
                    break;
                }
        }
    }

    //vm.activateTab = function(tab)
    //{
    //    vm.activeTab = tab;
    //    switch (tab) {
    //        case 0:
    //            vm.listToShow = ;
    //            vm.activeListLength = vm.listToShow.length;
    //            vm.title = vm.listToShow.taigName;
    //            break;
    //        case 1:
    //            vm.pendingListLength = vm.listToShow.length;
    //            break;
    //        case 2:
    //            vm.listToShow = vm.participations.filter(function (p) { return [3, 6, 7, 8].indexOf(p.statusId) > -1 });
    //            vm.actionListLength = vm.listToShow.length;
    //            break;
    //        case 3:
    //            vm.listToShow = vm.participations.filter(function (p) { return [4, 5].indexOf(p.statusId) > -1 });
    //            vm.archiveListLength = vm.listToShow.length;
    //            break;
    //    }
    //}

    vm.getParticipations = function (tabToActivate) {
        $http({
            url: "api/Participations/47912524",
            method: 'GET',
            headers: { Accept: 'application/json' },
            paramSerializer: '$httpParamSerializerJQLike'
        }).then(function (response) {
            processParticipations(response.data)
            if (tabToActivate != null)
                vm.activeTab = tabToActivate;
        }).catch(function (e) {
            console.log("Error: " + e.status + " - " + e.statusText);
            alert("There were errors retrieving data. Please, retry and if the issue still ocurrs contact the IT analyst");
        });
    }

    vm.deleteParticipation = function(index){
        $http({
            url: "api/DeleteParticipation/" + index,
            method: 'DELETE'
        }).then(function (){
            alert("Participation deleted!");
        }).catch(function(e){
            console.log("Error: " + e.status + " - " + e.statusText);
            alert("There was an error deleting the data!");
        })

    }

    //vm.activateTab(0);
    //vm.getParticipations(0);
});