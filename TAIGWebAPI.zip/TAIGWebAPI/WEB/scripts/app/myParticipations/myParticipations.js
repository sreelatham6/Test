﻿app.controller('myParticipations', function ($http, $window, $mdDialog) {
    var vm = this;
    vm.activeTab = 0;
    vm.employee = '';

    var dataFromAPI = [
        {
            "participationID": 1,
            "membershipType": "Membership",
            "statusId": 1,
            "status": "NotReviewed ",
            "taigId": 1,
            "taigName": "taig1",
            "userId": "47912524",
            "userName": "Nallar, Juan M",
            "submisionDate": "2018-07-02T10:03:18.337",
            "purposeId": 1,
            "purpose": "Advance CCS Public Policy",
            "role": null,
            "committeeName": null,
            "reviewRequests": [
                {
                    "reviewRequestId": 1,
                    "userGUID": "78793334",
                    "dateTime": "2018-07-02T10:03:18.337",
                    "reviewed": null,
                    "userName": "Nallar, Juan M",
                    "reviewerType": "Supervisor"
                },
                {
                    "reviewRequestId": 2,
                    "userGUID": "78793334",
                    "dateTime": "2018-07-02T10:03:18.337",
                    "reviewed": null,
                    "userName": "Nallar, Juan M",
                    "reviewerType": "Law Contact"
                }
            ],
            "actionsAllowed": [
                "Cancel"
            ]
        },
        {
            "participationID": 2,
            "membershipType": "Membership",
            "statusId": 2,
            "status": "Pending ",
            "taigId": 2,
            "taigName": "taig2",
            "parentParticipationId": "1",
            "userId": "47912524",
            "userName": "Nallar, Juan M",
            "submisionDate": "2018-07-02T10:03:30.67",
            "purposeId": 1,
            "purpose": "Advance CCS Public Policy",
            "role": null,
            "committeeName": null,
            "reviewRequests": [
                {
                    "reviewRequestId": 3,
                    "userGUID": "78793334",
                    "dateTime": "2018-07-02T10:03:30.67",
                    "reviewed": true,
                    "userName": "Nallar, Juan M",
                    "reviewerType": "Supervisor"
                },
                {
                    "reviewRequestId": 4,
                    "userGUID": "78793334",
                    "dateTime": "2018-07-02T10:03:30.67",
                    "reviewed": null,
                    "userName": "Nallar, Juan M",
                    "reviewerType": "Law Contact"
                }
            ],
            "actionsAllowed": [
                "Keep", "Accept", "Reject"
            ]
        },
        {
            "participationID": 3,
            "membershipType": "Role",
            "statusId": 3,
            "status": "New ",
            "taigId": 2,
            "taigName": "taig2",
            "userId": "47912524",
            "userName": "Nallar, Juan M",
            "submisionDate": "2018-07-02T10:03:33.823",
            "purposeId": 1,
            "purpose": "Advance CCS Public Policy",
            "role": "Alternate",
            "committeeName": null,
            "reviewRequests": [
                {
                    "reviewRequestId": 5,
                    "userGUID": "78793334",
                    "dateTime": "2018-07-02T10:03:33.84",
                    "reviewed": true,
                    "userName": "Nallar, Juan M",
                    "reviewerType": "Supervisor"
                },
                {
                    "reviewRequestId": 6,
                    "userGUID": "78793334",
                    "dateTime": "2018-07-02T10:03:33.84",
                    "reviewed": true,
                    "userName": "Nallar, Juan M",
                    "reviewerType": "Law Contact"
                },
                {
                    "reviewRequestId": 7,
                    "userGUID": "78793334",
                    "dateTime": "2018-07-02T10:03:33.84",
                    "reviewed": true,
                    "userName": "Nallar, Juan M",
                    "reviewerType": "DOAG3+"
                }
            ],
            "actionsAllowed": [
                "Transfer",
                "Remove"
            ]
        },
        {
            "participationID": 4,
            "membershipType": "Committee",
            "statusId": 3,
            "status": "New ",
            "taigId": 2,
            "taigName": "taig2",
            "userId": "47912524",
            "userName": "Nallar, Juan M",
            "submisionDate": "2018-07-02T10:10:04.41",
            "purposeId": 1,
            "purpose": "Advance CCS Public Policy",
            "role": "Some other Role",
            "committeeName": "Committee 1",
            "reviewRequests": [
                {
                    "reviewRequestId": 8,
                    "userGUID": "78793334",
                    "dateTime": "2018-07-02T10:10:04.41",
                    "reviewed": true,
                    "userName": "Nallar, Juan M",
                    "reviewerType": "Supervisor"
                },
                {
                    "reviewRequestId": 9,
                    "userGUID": "78793334",
                    "dateTime": "2018-07-02T10:10:04.41",
                    "reviewed": true,
                    "userName": "Nallar, Juan M",
                    "reviewerType": "Law Contact"
                },
                {
                    "reviewRequestId": 10,
                    "userGUID": "78793334",
                    "dateTime": "2018-07-02T10:10:04.41",
                    "reviewed": true,
                    "userName": "Nallar, Juan M",
                    "reviewerType": "DOAG3+"
                }
            ],
            "actionsAllowed": [
                "Transfer",
                "Remove"
            ]
        }
    ];

    vm.orgChart = [
        {
            "Code": "48346676",
            "LanId": "UPSTREAMACCTS\\LDUCHAR",
            "Level": { "-i:nil": "true" },
            "Name": "DuCharme, Linda D",
            "OrganizationCode": "90000386",
            "Position": "PRESIDENT GLOBAL SVCS CO"
        },
        {
            "Code": "41276403",
            "LanId": "NA\\MSBROWN",
            "Level": { "-i:nil": "true" },
            "Name": "Brown, Michael S",
            "OrganizationCode": "90000395",
            "Position": "VP GLOBAL INFORMATION TECHNOLOGY"
        },
        {
            "Code": "69641468",
            "LanId": "NA\\SRCHERE",
            "Level": { "-i:nil": "true" },
            "Name": "Cherek, Steve R",
            "OrganizationCode": "11002245",
            "Position": "MANAGER IS EXEC"
        },
        {
            "Code": "70374545",
            "LanId": "NA\\KJREDDIN",
            "Level": { "-i:nil": "true" },
            "Name": "Luddeke, Karen J",
            "OrganizationCode": "90551005",
            "Position": "MGR APPL FINANCIAL"
        },
        {
            "Code": "70374545",
            "LanId": "NA\\KJREDDIN",
            "Level": { "-i:nil": "true" },
            "Name": "Luddeke, Karen J",
            "OrganizationCode": "90551005",
            "Position": "SUPERVISOR IS SENIOR"
        },
        {
            "Code": "69641468",
            "LanId": "NA\\SRCHERE",
            "Level": { "-i:nil": "true" },
            "Name": "Cherek, Steve R",
            "OrganizationCode": "11002245",
            "Position": "SUPERVISOR IS SENIOR"
        },
        {
            "Code": "57587808",
            "LanId": "UPSTREAMACCTS\\EJMALVE",
            "Level": { "-i:nil": "true" },
            "Name": "Malveaux, Edrice J",
            "OrganizationCode": "90509000",
            "Position": "SUPERVISOR IS SENIOR"
        },
        {
            "Code": "47912524",
            "LanId": "UPSTREAMACCTS\\JMNALLA",
            "Level": { "-i:nil": "true" },
            "Name": "Nallar, Juan M",
            "OrganizationCode": "10890832",
            "Position": "SUPERVISOR"
        },
        {
            "Code": "78793334",
            "LanId": "SA\\NOMANA",
            "Level": { "-i:nil": "true" },
            "Name": "Omana, Nicolas",
            "OrganizationCode": "10890832",
            "Position": "SUPERVISOR"
        },
        {
            "Code": "48346676",
            "LanId": "UPSTREAMACCTS\\LDUCHAR",
            "Level": { "-i:nil": "true" },
            "Name": "DuCharme, Linda D",
            "OrganizationCode": "90000386",
            "Position": "CONTINGENCE WORKFORCE MANAGER"
        },
        {
            "Code": "48346676",
            "LanId": "UPSTREAMACCTS\\LDUCHAR",
            "Level": { "-i:nil": "true" },
            "Name": "DuCharme, Linda D",
            "OrganizationCode": "90000386",
            "Position": "ASST STAFF TO PRES"
        }
    ];

    vm.lists = [
        { name: "Active" },
        { name: "Pending" },
        { name: "Action Needed" },
        { name: "Archive" },
    ];

    var processParticipations = function (participations) {
        var aux = dataFromAPI.filter(function (p) { return p.statusId == 1 });
        vm.lists[0].count = aux.length;
        vm.lists[0].taigs = groupByTAIG(aux);

        aux = dataFromAPI.filter(function (p) { return p.statusId == 2 });
        vm.lists[1].count = aux.length;
        vm.lists[1].taigs = groupByTAIG(aux);

        aux = dataFromAPI.filter(function (p) { return [3, 6, 7, 8].indexOf(p.statusId) > -1 });
        vm.lists[2].count = aux.length;
        vm.lists[2].taigs = groupByTAIG(aux);

        aux = dataFromAPI.filter(function (p) { return [4, 5].indexOf(p.statusId) > -1 });
        vm.lists[3].count = aux.length;
        vm.lists[3].taigs = groupByTAIG(aux);
    }


    var groupByTAIG = function (participations) {
        var dictionary = {};

        for (var i = 0; i < participations.length; i++) {
            if (!dictionary[participations[i].taigName])
                dictionary[participations[i].taigName] = { participations: [] };
            dictionary[participations[i].taigName].participations.push(participations[i]);
        }

        var result = [];
        for (t in dictionary) {
            result.push({ taigName: t, participations: dictionary[t].participations });
        }
        return result;
    }

    processParticipations(dataFromAPI);

    vm.button_handler = function (ev, action, participationid, activetab, memebershiptype, taigName, parentparticipationid, userguid) {
        switch (action) {
            case 'Cancel':
                var confirm = $mdDialog.confirm()
                    .textContent("Would you like to cancel this " + memebershiptype + "?")
                    .targetEvent(ev)
                    .cancel('No')
                    .ok('Yes')
                    .clickOutsideToClose(false);

                $mdDialog.show(confirm).then(function () {
                    vm.cancelParticipation(ev, participationid, memebershiptype);
                    processParticipations(dataFromAPI);
                    //vm.activateTab(activetab);
                    //vm.getParticipations(activetab);
                }, function () {
                    return false;
                });
                break;

            case 'Keep':
                var confirm = $mdDialog.confirm()
                    .textContent("Would you like to keep this " + memebershiptype + "?")
                    .targetEvent(ev)
                    .cancel('No')
                    .ok('Yes')
                    .clickOutsideToClose(false);

                $mdDialog.show(confirm).then(function () {
                    vm.keepParticipation(ev, participationid, memebershiptype);
                    processParticipations(dataFromAPI);
                    //vm.activateTab(activetab);
                    //vm.getParticipations(activetab);
                }, function () {
                    return false;
                });
                break;

            case 'Transfer':
                $mdDialog.show({
                    locals: {
                        ev: ev,
                        participationid: participationid,
                        activetab: activetab
                    },
                    controller: vm.transferController,
                    template: `
                    <md-dialog class="em-c-well">
                        <md-dialog-content style="height:300px; width:500px">
                            <h3>Transfer Participation</h3>
                            <div class="em-c-well">
                            <h4>Enter Transfer To Employee</h4>
                            <div class="em-c-field em-js-typeahead">
                                <div class="em-c-field__body">
                                    <input type="text" id="employee" placeholder="Enter employee" class="em-c-input em-js-typeahead" 
                                        ng-change="onChangeEmployee(employee)"
                                        ng-model="employee" />
                                    <div class="em-c-field__menu em-js-typeahead-menu" ng-class="{'em-is-active': employeelist.length > 0 && employee.length >= 3}">
                                        <ul class="em-c-typeahead-list" ng-repeat="emp in employeelist">
                                            <li class="em-c-typeahead-list__item" ng-click="onSetEmployee(emp)">
                                                <span class="em-c-typeahead__suggestion">{{emp.Name}}</span>
                                            </li>
                                        </ul>
                                    </div>
                                    <input type="text" id="employeeid" ng-model="employeeid" hidden />
                                </div>
                            </div>
                            </div>
                            <md-dialog-actions>
                            <md-button ng-click="onTransfer(ev, participationid, employeeid)">Transfer</md-button>
                                <md-button ng-click="onClose()">Close</md-button>
                            </md-dialog-actions>
                        </md-dialog-content>
                    </md-dialog>
                  `,
                    parent: angular.element(document.body),
                    targetEvent: ev,
                    clickOutsideToClose: false,
                    fullscreen: vm.customFullscreen // Only for -xs, -sm breakpoints
                })
                    .then(function (answer) {
                        vm.status = 'You said the information was "' + answer + '".';
                    }, function () {
                        vm.status = 'You cancelled the dialog.';
                    });
                break;

            case 'Remove':
                var confirm = $mdDialog.confirm()
                    .textContent("Would you like to remove this " + memebershiptype + "?")
                    .targetEvent(ev)
                    .cancel('No')
                    .ok('Yes')
                    .clickOutsideToClose(false);

                $mdDialog.show(confirm).then(function () {
                    vm.removeParticipation(ev, participationid, memebershiptype);
                    processParticipations(dataFromAPI);
                    //vm.activateTab(activetab);
                    //vm.getParticipations(activetab);
                }, function () {
                    return false;
                });
                break;

            case 'Accept':
                $mdDialog.show({
                    locals: {
                        ev: ev,
                        participationid: participationid,
                        activetab: activetab,
                        parentparticipationid: parentparticipationid
                    },
                    controller: vm.acceptTransferController,
                    template: `
                <md-dialog class="em-c-well">
                    <md-dialog-content style="height:300px; width:500px">
                        <h3>Accept Transfer Participation</h3>
                        <div class="em-c-well">
                        <h4>Enter Supervisor</h4>
                        <div class="em-c-field em-js-typeahead">
                            <div class="em-c-field__body">
                                <input type="text" id="supervisor" placeholder="Enter supervisor" class="em-c-input em-js-typeahead" 
                                    ng-change="onChangeSupervisor(supervisor)"
                                    ng-model="supervisor" />
                                <div class="em-c-field__menu em-js-typeahead-menu" ng-class="{'em-is-active': supervisorlist.length > 0 && supervisor.length >= 3}">
                                    <ul class="em-c-typeahead-list" ng-repeat="sup in supervisorlist">
                                        <li class="em-c-typeahead-list__item" ng-click="onSetSupervisor(sup)">
                                            <span class="em-c-typeahead__suggestion">{{sup.Name}}</span>
                                        </li>
                                    </ul>
                                </div>
                                <input type="text" id="supervisorid" ng-model="supervisorid" hidden />
                            </div>
                        </div>
                        </div>
                        <div class="em-c-well" ng-show = "showlawcontact">
                        <h4>Enter Law Contact</h4>
                        <div class="em-c-field em-js-typeahead">
                            <div class="em-c-field__body">
                                <input type="text" id="lawcontact" placeholder="Enter law contact" class="em-c-input em-js-typeahead" 
                                    ng-change="onChangeLawcontact(lawcontact)"
                                    ng-model="lawcontact" />
                                <div class="em-c-field__menu em-js-typeahead-menu" ng-class="{'em-is-active': lawcontactlist.length > 0 && lawcontact.length >= 3}">
                                    <ul class="em-c-typeahead-list" ng-repeat="lc in lawcontactlist">
                                        <li class="em-c-typeahead-list__item" ng-click="onSetLawcontact(lc)">
                                            <span class="em-c-typeahead__suggestion">{{lc.Name}}</span>
                                        </li>
                                    </ul>
                                </div>
                                <input type="text" id="lawcontactid" ng-model="lawcontactid" hidden />
                            </div>
                        </div>
                        </div>
                        <md-dialog-actions>
                            <md-button ng-click="onTransfer(ev, participationid, supervisorid, lawcontactid)">Transfer</md-button>
                            <md-button ng-click="onClose()">Close</md-button>
                        </md-dialog-actions>
                    </md-dialog-content>
                </md-dialog>
              `,
                    parent: angular.element(document.body),
                    targetEvent: ev,
                    clickOutsideToClose: false,
                    fullscreen: vm.customFullscreen // Only for -xs, -sm breakpoints
                })
                    .then(function (answer) {
                        vm.status = 'You said the information was "' + answer + '".';
                    }, function () {
                        vm.status = 'You cancelled the dialog.';
                    });
                break;

            case 'Reject':
                var confirm = $mdDialog.confirm()
                    .textContent('Set ' + memebershiptype + ' from ' + taigName + ' to rejected?')
                    .targetEvent(ev)
                    .cancel('No')
                    .ok('Yes')
                    .clickOutsideToClose(false);

                $mdDialog.show(confirm).then(function () {
                    vm.rejectParticipation(ev, participationid, memebershiptype);
                    processParticipations(dataFromAPI);
                    //vm.activateTab(activetab);
                    //vm.getParticipations(activetab);
                }, function () {
                    return false;
                });
                break;
        }
    }

    //transfer participation
    vm.transferController = function (ev, participationid, $scope, $mdDialog) {
        $scope.participationid = participationid;
        $scope.ev = ev;
        $scope.showlawcontact = false;

        //vm.getTransferEmployees();
        vm.tobeTransEmployees = [
            { UserId: 1, Name: "Juan" }, { UserId: 2, Name: "Vincent" }
        ];

        $scope.employeelist = [];

        $scope.onChangeEmployee = function (emp) {
            $scope.employeelist = [];
            for (var i = 0; i < vm.tobeTransEmployees.length; i++) {
                if (vm.tobeTransEmployees[i].Name.toLocaleLowerCase().indexOf(emp) > -1) {
                    $scope.employeelist.push(vm.tobeTransEmployees[i]);
                }
            }
        }

        $scope.onSetEmployee = function (emp) {
            $scope.employee = emp.Name;
            $scope.employeeid = emp.UserId;
            $scope.employeelist = [];
        }

        $scope.onClose = function () {
            $mdDialog.cancel();
        }

        $scope.onTransfer = function (ev, participationid, employeeid) {
            if ((employeeid != undefined)) {
                vm.transferParticipation(ev, participationid, employeeid);
                processParticipations(dataFromAPI);
            }
            else {
                alert = $mdDialog.alert({
                    title: 'Attention',
                    textContent: 'Transferred employee must be selected!',
                    ok: 'Close'
                });

                $mdDialog
                    .show(alert)
                    .finally(function () {
                        alert = undefined;
                    });
            }
            $mdDialog.hide(employeeid);
            //vm.activateTab(activetab);
        }
    }

    vm.acceptTransferController = function (ev, activetab, participationid, parentparticipationid, $scope, $mdDialog) {
        $scope.participationid = participationid;
        $scope.ev = ev;
        $scope.parentparticipationid = parentparticipationid;
        $scope.activetab = activetab;
        $scope.showlawcontact = false;

        //vm.getTransferEmployees();
        
        //get parent participation id
        //vm.getParentGUID(parentparticipationid);
        //get UserDTO for parent GUID
        //vm.getParentUserDTO(vm.parentGUID);

        vm.tobeTransEmployees = [
            { UserId: 1, Name: "Juan", OgL3Path: 10 }, { UserId: 2, Name: "Vincent", OgL3Path: 20 }
        ];

        vm.parentUserDTO =
            { UserId: 1, Name: "Juan", OgL3Path: 10 };

        vm.transferToEmp =
            { UserId: 2, Name: "Vincent", OgL3Path: 20 };
        //set supervisor

        $scope.supervisorlist = [];

        $scope.onChangeSupervisor = function (emp) {
            $scope.supervisorlist = [];
            for (var i = 0; i < vm.tobeTransEmployees.length; i++) {
                if (vm.tobeTransEmployees[i].Name.toLocaleLowerCase().indexOf(emp) > -1) {
                    $scope.supervisorlist.push(vm.tobeTransEmployees[i]);
                }
            }
        }

        $scope.onSetSupervisor = function (emp) {
            $scope.supervisor = emp.Name;
            $scope.supervisorid = emp.UserId;
            $scope.supervisorlist = [];

            //vm.getTransferEmployeeUserDTO(emp.UserId)

            if (vm.parentUserDTO.OgL3Path != vm.transferToEmp.OgL3Path) {
                $scope.showlawcontact = true;
            }
        }

        //set law contact
        $scope.lawcontactlist = [];

        $scope.onChangeLawcontact = function (emp) {
            $scope.lawcontactlist = [];
            for (var i = 0; i < vm.tobeTransEmployees.length; i++) {
                if (vm.tobeTransEmployees[i].Name.toLocaleLowerCase().indexOf(emp) > -1) {
                    $scope.lawcontactlist.push(vm.tobeTransEmployees[i]);
                }
            }
        }

        $scope.onSetLawcontact = function (lc) {
            $scope.lawcontact = lc.Name;
            $scope.lawcontactid = lc.UserId;
            $scope.lawcontactlist = [];
        }

        $scope.onClose = function () {
            $mdDialog.cancel();
        }

        $scope.onTransfer = function (ev, participationid, supervisorid, lawcontactid) {
            if ($scope.showlawcontact == true) {
                if ((supervisorid != undefined) && (lawcontactid != undefined)) {
                    vm.acceptTransferParticipation(ev, participationid, supervisorid, lawcontactid);
                    processParticipations(dataFromAPI);
                }
                else {
                    alert = $mdDialog.alert({
                        title: 'Attention',
                        textContent: 'Supervisor and Law Contact must be selected!',
                        ok: 'Close'
                    });

                    $mdDialog
                        .show(alert)
                        .finally(function () {
                            alert = undefined;
                        });
                }
            }
            $mdDialog.hide(supervisorid);
            //vm.activateTab(activetab);
        }
    }

    vm.getParticipations = function (tabToActivate) {
        $http({
            url: "api/Participations/" + userguid,
            method: 'GET',
            headers: { Accept: 'application/json' },
            paramSerializer: '$httpParamSerializerJQLike'
        }).then(function (response) {
            vm.processParticipations(response.data)
            if (tabToActivate != null)
                vm.activeTab = tabToActivate;
        }).catch(function (e) {
            console.log("Error: " + e.status + " - " + e.statusText);
            alert("There were errors retrieving data. Please, retry and if the issue still ocurrs contact the IT analyst");
        });
    }

    vm.cancelParticipation = function (ev, id, memebershiptype) {
        $http({
            url: "api/CancelParticipation/" + id,
            method: 'DELETE'
        }).then(function () {
            alert("Participation cancelled!");
        }).catch(function (e) {
            console.log("Error: " + e.status + " - " + e.statusText);
            $mdDialog.show(
                $mdDialog.alert()
                    .parent(angular.element(document.querySelector('#popupContainer')))
                    .clickOutsideToClose(false)
                    .textContent('There was an error completing this request!')
                    .ok('OK')
                    .targetEvent(ev)
            );
        })
    }

    vm.removeParticipation = function (ev, id, memebershiptype) {
        $http({
            url: "api/RemoveParticipation/" + id,
            method: 'DELETE'
        }).then(function () {
            alert("Participation removed!");
        }).catch(function (e) {
            console.log("Error: " + e.status + " - " + e.statusText);
            $mdDialog.show(
                $mdDialog.alert()
                    .parent(angular.element(document.querySelector('#popupContainer')))
                    .clickOutsideToClose(false)
                    .textContent('There was an error completing this request!')
                    .ok('OK')
                    .targetEvent(ev)
            );
        })
    }

    vm.keepParticipation = function (ev, id, memebershiptype) {
        $http({
            url: "api/KeepParticipation/" + id,
            method: 'POST'
        }).then(function () {
            alert("Participation Updated!");
        }).catch(function (e) {
            console.log("Error: " + e.status + " - " + e.statusText);
            $mdDialog.show(
                $mdDialog.alert()
                    .parent(angular.element(document.querySelector('#popupContainer')))
                    .clickOutsideToClose(false)
                    .textContent('There was an error completing this request!')
                    .ok('OK')
                    .targetEvent(ev)
            );
        })
    }

    vm.rejectParticipation = function (ev, id, memebershiptype) {
        $http({
            url: "api/RejectParticipation/" + id,
            method: 'POST'
        }).then(function () {
            alert("Participation Updated!");
        }).catch(function (e) {
            console.log("Error: " + e.status + " - " + e.statusText);
            $mdDialog.show(
                $mdDialog.alert()
                    .parent(angular.element(document.querySelector('#popupContainer')))
                    .clickOutsideToClose(false)
                    .textContent('There was an error completing this request!')
                    .ok('OK')
                    .targetEvent(ev)
            );
        })
    }

    vm.transferParticipation = function (ev, participationid, employeeid) {
        $http({
            url: "api/TransferOutParticipation/" + participationid + "/" + employeeid,
            method: 'POST'
        }).then(function () {
            alert("Participation transferred!");
        }).catch(function (e) {
            console.log("Error: " + e.status + " - " + e.statusText);
            $mdDialog.show(
                $mdDialog.alert()
                    .parent(angular.element(document.querySelector('#popupContainer')))
                    .clickOutsideToClose(false)
                    .textContent('There was an error completing this request!')
                    .ok('OK')
                    .targetEvent(ev)
            );
        })
    }

    vm.acceptTransferParticipation = function (ev, participationid, supervisorid, lawcontactid) {
        $http({
            url: "api/TransferOutParticipation/" + participationid + "/" + supervisorid + "/" + lawcontactid,
            method: 'POST'
        }).then(function () {
            alert("Participation transferred!");
        }).catch(function (e) {
            console.log("Error: " + e.status + " - " + e.statusText);
            $mdDialog.show(
                $mdDialog.alert()
                    .parent(angular.element(document.querySelector('#popupContainer')))
                    .clickOutsideToClose(false)
                    .textContent('There was an error completing this request!')
                    .ok('OK')
                    .targetEvent(ev)
            );
        })
    }

    vm.getOrgChart = function (tabToActivate) {
        $http({
            url: "api/OrgChart/47912524",
            method: 'GET',
            headers: { Accept: 'application/json' },
            paramSerializer: '$httpParamSerializerJQLike'
        }).then(function (response) {
            vm.orgChart = response.data;
        }).catch(function (e) {
            console.log("Error: " + e.status + " - " + e.statusText);
            alert("There were errors retrieving data. Please, retry and if the issue still ocurrs contact the IT analyst");
        });
    }

    vm.getTransferToEmployeeUserDTO = function (userid) {
        $http({
            url: "api/GetUserDTO/" + userid,
            method: 'GET',
            headers: { Accept: 'application/json' },
            paramSerializer: '$httpParamSerializerJQLike'
        }).then(function (response) {
            vm.transferToEmp = response.data;
        }).catch(function (e) {
            console.log("Error: " + e.status + " - " + e.statusText);
            alert("There were errors retrieving data. Please, retry and if the issue still ocurrs contact the IT analyst");
        });
    }

    vm.getTransferEmployees = function () {
        $http({
            url: "api/GetUserDTOEmployees/",
            method: 'GET',
            headers: { Accept: 'application/json' },
            paramSerializer: '$httpParamSerializerJQLike'
        }).then(function (response) {
            vm.tobeTransEmployees = response.data;
        }).catch(function (e) {
            console.log("Error: " + e.status + " - " + e.statusText);
            alert("There were errors retrieving data. Please, retry and if the issue still ocurrs contact the IT analyst");
        });
    }

    vm.getParentGUID = function(parentparticipationid)
    {
        $http({
            url: "api/GetParentGUID/" + parentparticipationid,
            method: 'GET',
            headers: { Accept: 'application/json' },
            paramSerializer: '$httpParamSerializerJQLike'
        }).then(function (response) {
            vm.parentGUID = response.data;
        }).catch(function (e) {
            console.log("Error: " + e.status + " - " + e.statusText);
            alert("There were errors retrieving data. Please, retry and if the issue still ocurrs contact the IT analyst");
        });
    }

    vm.getParentUserDTO = function(parentGUID)
    {
        $http({
            url: "api/GetParentUserDTO/" + parentGUID,
            method: 'GET',
            headers: { Accept: 'application/json' },
            paramSerializer: '$httpParamSerializerJQLike'
        }).then(function (response) {
            vm.parentUserDTO = response.data;
        }).catch(function (e) {
            console.log("Error: " + e.status + " - " + e.statusText);
            alert("There were errors retrieving data. Please, retry and if the issue still ocurrs contact the IT analyst");
        });
    }
});