﻿app.controller('newParticipation', function () {
    var vm = this;

    //----------Mocked data

    vm.taigs = [
    {title:"TAIG 1", id:1},
    { title: "TAIG 2", id: 2 },
    { title: "TAIG 3", id: 3 },
    {title:"TAIG 4", id:4},
    {title:"TAIG 5", id:5},
    {title:"TAIG 6", id:6},
    {title:"TAIG 7", id:7},
    {title:"TAIG 8", id:8},
    { title: "TAIG 9", id: 9 }];
    vm.contactLaws = [
        { id: 1, name: 'Juan' },
        { id: 2, name: 'Jose' },
        { id: 3, name: 'Maria' },
    ];
    vm.purposes = [
        { description: 'purpose 1', id: 1 },
        { description: 'purpose 2', id: 2 },
        { description: 'purpose 3', id: 3 },
        { description: 'purpose 4', id: 4 },
        { description: 'purpose 5', id: 5 },
        { description: 'purpose 6', id: 6 }
    ];
    vm.roles= [
        { description: 'role 1', id: 1 },
        { description: 'role 3', id: 3 },
        { description: 'role 2', id: 2 },
        { description: 'role 4', id: 4 },
        { description: 'role 5', id: 5 },
        { description: 'role 6', id: 6 }
    ];


    //----------TAIG typehead

    vm.typeaheadTaigs = [];

    vm.selectedTaig = { title: '', id: 0 };

    vm.taigTypeaheadChange = function () {
        vm.selectedTaig.id = 0;

        for (var i = 0; i < vm.taigs.length; i++) {
            if (vm.taigs[i].title == vm.selectedTaig.title) {
                vm.selectTaig(vm.taigs[i]);
                return;
            }

            if (vm.taigs[i].title.indexOf(vm.selectedTaig.title) > -1)
                vm.typeaheadTaigs.push(vm.taigs[i]);
        }
    }

    vm.selectTaig = function(taig)
    {
        vm.selectedTaig.title = taig.title;
        vm.selectedTaig.id = taig.id;
        vm.typeaheadTaigs.length = 0;
    }

    //----------CARDS

    vm.activeCard = 0;
    vm.filteredContactLaws = [];
    vm.filtercontactLaw = '';
    vm.filterContactLaws = function (index) {
        vm.activeCard = index;
        var card = vm.cards[index];
        vm.filteredContactLaws = [];
        if (card.contactLawName.length == 0)
            return;
        for (var i = 0; i < vm.contactLaws.length; i++) {
            if (vm.contactLaws[i].name.indexOf(card.contactLawName) > -1)
                vm.filteredContactLaws.push(vm.contactLaws[i]);
        }
    }

    vm.AddCard = function (type) {
        vm.cards.push({
            type: type,
            contactLawName: '',
            contactLawId: 0,
        });
    }

    vm.SetcontactLawToCard = function (contactLaw, card) {
        card.contactLawId = contactLaw.id;
        card.contactLawName = contactLaw.name;
        vm.filteredContactLaws = [];
        vm.filtercontactLaw = '';
    }
    vm.cards = [
        {
            type: 'Membership',
            contactLawName: '',
            contactLawId: 0,
        }
    ];




});