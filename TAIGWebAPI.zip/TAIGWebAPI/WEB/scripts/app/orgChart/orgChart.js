﻿app.component('orgChart', {
    templateUrl: 'orgChart',
    bindings: {
        currentUserGUID : '>',
        showChangeSupervisorButton: '>',
        showReviewButtons: '>',
        supervisor: '<',
        reviewers: '<'
    },
    controller: function () {
        var vm = this;

        
       vm.orgChart = [
       {
           "Code": "48346676",
           "LanId": "UPSTREAMACCTS\\LDUCHAR",
           "Level": { "-i:nil": "true" },
           "Name": "DuCharme, Linda D",
           "OrganizationCode": "90000386",
           "Position": "PRESIDENT GLOBAL SVCS CO"
       },
       {
           "Code": "41276403",
           "LanId": "NA\\MSBROWN",
           "Level": { "-i:nil": "true" },
           "Name": "Brown, Michael S",
           "OrganizationCode": "90000395",
           "Position": "VP GLOBAL INFORMATION TECHNOLOGY"
       },
       {
           "Code": "69641468",
           "LanId": "NA\\SRCHERE",
           "Level": { "-i:nil": "true" },
           "Name": "Cherek, Steve R",
           "OrganizationCode": "11002245",
           "Position": "MANAGER IS EXEC"
       },
       {
           "Code": "70374545",
           "LanId": "NA\\KJREDDIN",
           "Level": { "-i:nil": "true" },
           "Name": "Luddeke, Karen J",
           "OrganizationCode": "90551005",
           "Position": "MGR APPL FINANCIAL"
       },
       {
           "Code": "70374545",
           "LanId": "NA\\KJREDDIN",
           "Level": { "-i:nil": "true" },
           "Name": "Luddeke, Karen J",
           "OrganizationCode": "90551005",
           "Position": "SUPERVISOR IS SENIOR"
       },
       {
           "Code": "69641468",
           "LanId": "NA\\SRCHERE",
           "Level": { "-i:nil": "true" },
           "Name": "Cherek, Steve R",
           "OrganizationCode": "11002245",
           "Position": "SUPERVISOR IS SENIOR"
       },
       {
           "Code": "57587808",
           "LanId": "UPSTREAMACCTS\\EJMALVE",
           "Level": { "-i:nil": "true" },
           "Name": "Malveaux, Edrice J",
           "OrganizationCode": "90509000",
           "Position": "SUPERVISOR IS SENIOR"
       },
       {
           "Code": "47912524",
           "LanId": "UPSTREAMACCTS\\JMNALLA",
           "Level": { "-i:nil": "true" },
           "Name": "Nallar, Juan M",
           "OrganizationCode": "10890832",
           "Position": "SUPERVISOR"
       },
       {
           "Code": "78793334",
           "LanId": "SA\\NOMANA",
           "Level": { "-i:nil": "true" },
           "Name": "Omana, Nicolas",
           "OrganizationCode": "10890832",
           "Position": "SUPERVISOR"
       },
       {
           "Code": "48346676",
           "LanId": "UPSTREAMACCTS\\LDUCHAR",
           "Level": { "-i:nil": "true" },
           "Name": "DuCharme, Linda D",
           "OrganizationCode": "90000386",
           "Position": "CONTINGENCE WORKFORCE MANAGER"
       },
       {
           "Code": "48346676",
           "LanId": "UPSTREAMACCTS\\LDUCHAR",
           "Level": { "-i:nil": "true" },
           "Name": "DuCharme, Linda D",
           "OrganizationCode": "90000386",
           "Position": "ASST STAFF TO PRES"
       }
        ];
        vm.getOrgChart = function (tabToActivate) {
            $http({
                url: "api/OrgChart/47912524",
                method: 'GET',
                headers: { Accept: 'application/json' },
                paramSerializer: '$httpParamSerializerJQLike'
            }).then(function (response) {
                vm.orgChart = response.data;
            }).catch(function (e) {
                console.log("Error: " + e.status + " - " + e.statusText);
                alert("There were errors retrieving data. Please, retry and if the issue still ocurrs contact the IT analyst");
            });
        }
    }
})