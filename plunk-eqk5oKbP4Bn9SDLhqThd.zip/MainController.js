// Code goes here

var myApp = angular.module('myApp');
myApp.controller("MainController", ["$scope", "$http",'github' , "$interval", "$log", "$location", function($scope, $http,  github, $interval, $log, $location){
  
  var countDownVar = null;
  
  var decrementCountDown = function(){
    $scope.countDown -= 1;
    if($scope.countDown < 1)
    {
      $scope.search($scope.username);
    }
  }
  
  var startCountDown = function(){
    countDownVar = $interval(decrementCountDown, 1000, $scope.countDown);
  }
  
  $scope.search = function(username){
    if(countDownVar)
    {
      $interval.cancel(countDownVar);
      $scope.countDown = null;
    }
    $location.path("/user/" + username);
  }
  
   $scope.message = "Welcome";
   $scope.respSortOrder = "starguazers_count";
   $scope.countDown = 5;
   startCountDown();
}]);