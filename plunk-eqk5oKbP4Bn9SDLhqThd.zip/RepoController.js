var myapp = angular.module("myApp");

myapp.controller("RepoController", ["$scope", "$http", 'github', "$routeParams", function($scope, $http, github, $routeParams){
    
    var reponame = $routeParams.reponame;
    var username = $routeParams.username;
    
    var onRepoDetails = function(data){
      $scope.repo = data;
    }
    
    var onError = function(reason){
      $scope.error = reason;
    }
    
    github.getRepoDetails(reponame, username)
          .then(onRepoDetails, onError);
}]);