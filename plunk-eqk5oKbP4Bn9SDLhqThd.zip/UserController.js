// Code goes here

var myApp = angular.module('myApp');
myApp.controller("UserController", ["$scope", "$http",'github' , "$interval", "$log","$routeParams", function($scope, $http,  github, $interval, $log, $routeParams){
  
  var userinfo = function(data){
    $log.info("searching for " + data);
    $scope.user = data;
    github.getRepos($scope.user)
          .then(onRepos, onError);
  }
  
  var onRepos = function(data){
    $scope.repos = data;
  }
  
  var onError = function(reason){
    $scope.error = "Failed to load data";
  }
  
   $scope.username = $routeParams.username;
   $scope.message = "Welcome";
   $scope.respSortOrder = "starguazers_count";
   
   github.getUser($scope.username).then(userinfo, onError);
}]);