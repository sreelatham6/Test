var module = angular.module("myApp");
module.factory("github",  ['$http', function($http){
  
var github = {};

  github.getUser = function(username){
      return($http.get("https://api.github.com/users/" + username)
           .then(function(response){
             return response.data;
           }));
    };
    
    github.getRepos = function(user){
      return($http.get(user.repos_url)
           .then(function(response){
             return response.data
           }));
    };
    
    github.getRepoDetails = function(reponame, username){
      var repo;
      var repoUrl = "https://api.github.com/repos/" + username + "/" + reponame;
      
      return($http.get(repoUrl)
                  .then(function(response){
                    repo = response.data;
                    return $http.get(repoUrl + "/collaborators");
                  })
                  .then(function(response){
                    repo.collaborators = response.data;
                    return repo;
                  }));
    };
    
    return github;
    
}]);